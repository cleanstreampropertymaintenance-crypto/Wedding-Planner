const MenuPage = {
  async render(container) {
    container.innerHTML = `
      <div class="flex flex-between mb-lg">
        <h2>Menu & Catering</h2>
        <button class="btn btn-primary" id="btn-add-menu-item"><i data-lucide="plus"></i> Add Item</button>
      </div>
      <div class="grid grid-3 mb-lg" id="menu-grid">
        <div class="text-center col-span-3 text-muted">Loading...</div>
      </div>
    `;

    this.container = container;
    this.boundHandleClick = this.handleClick.bind(this);
    container.addEventListener('click', this.boundHandleClick);
    
    await this.loadData();
  },

  async loadData() {
    try {
      this.menuItems = await window.API.get('/api/menu') || [];
      this.renderList();
    } catch (err) {
      window.Toast.error('Failed to load menu items');
    }
  },

  renderList() {
    const grid = this.container.querySelector('#menu-grid');
    
    if (this.menuItems.length === 0) {
      grid.innerHTML = `<div class="text-center col-span-3 text-muted">No menu items added yet.</div>`;
      return;
    }

    grid.innerHTML = this.menuItems.map(item => `
      <div class="card card-glass card-hover" data-id="${item.id}">
        <div class="flex flex-between mb-sm">
          <span class="badge badge-info">${window.Helpers.escapeHtml(item.course || 'Appetizer')}</span>
          <div>
            <button class="btn btn-icon btn-sm edit-item"><i data-lucide="edit-2"></i></button>
            <button class="btn btn-icon btn-sm text-danger delete-item"><i data-lucide="trash-2"></i></button>
          </div>
        </div>
        <h3 class="mb-sm">${window.Helpers.escapeHtml(item.name)}</h3>
        <p class="text-muted text-sm mb-md">${window.Helpers.escapeHtml(item.description || '')}</p>
        ${item.dietary ? `<div class="text-sm"><strong>Dietary:</strong> ${window.Helpers.escapeHtml(item.dietary)}</div>` : ''}
      </div>
    `).join('');
  },

  handleClick(e) {
    if (e.target.closest('#btn-add-menu-item')) {
      this.showMenuForm();
    } else if (e.target.closest('.delete-item')) {
      const id = e.target.closest('.card').dataset.id;
      this.deleteItem(id);
    } else if (e.target.closest('.edit-item')) {
      const id = e.target.closest('.card').dataset.id;
      const item = this.menuItems.find(s => s.id === id);
      if (item) this.showMenuForm(item);
    }
  },

  showMenuForm(item = null) {
    const isEdit = !!item;
    window.Modal.show({
      title: isEdit ? 'Edit Menu Item' : 'Add Menu Item',
      content: `
        <form id="menu-form">
          <div class="form-group mb-md">
            <label class="form-label">Course</label>
            <select class="form-select" id="item-course">
              <option value="Hors d'oeuvres" ${item?.course === "Hors d'oeuvres" ? 'selected' : ''}>Hors d'oeuvres</option>
              <option value="Appetizer" ${item?.course === 'Appetizer' ? 'selected' : ''}>Appetizer</option>
              <option value="Main Course" ${item?.course === 'Main Course' ? 'selected' : ''}>Main Course</option>
              <option value="Side Dish" ${item?.course === 'Side Dish' ? 'selected' : ''}>Side Dish</option>
              <option value="Dessert" ${item?.course === 'Dessert' ? 'selected' : ''}>Dessert</option>
              <option value="Late Night Snack" ${item?.course === 'Late Night Snack' ? 'selected' : ''}>Late Night Snack</option>
            </select>
          </div>
          <div class="form-group mb-md">
            <label class="form-label">Name</label>
            <input type="text" class="form-input" id="item-name" required value="${item ? window.Helpers.escapeHtml(item.name) : ''}">
          </div>
          <div class="form-group mb-md">
            <label class="form-label">Description</label>
            <textarea class="form-textarea" id="item-description" rows="3">${item ? window.Helpers.escapeHtml(item.description || '') : ''}</textarea>
          </div>
          <div class="form-group mb-md">
            <label class="form-label">Dietary Restrictions (e.g. V, GF)</label>
            <input type="text" class="form-input" id="item-dietary" value="${item ? window.Helpers.escapeHtml(item.dietary || '') : ''}">
          </div>
          <div class="flex gap-sm" style="justify-content: flex-end;">
            <button type="submit" class="btn btn-primary">${isEdit ? 'Save Changes' : 'Add Item'}</button>
          </div>
        </form>
      `,
      onSubmit: async (modalEl) => {
        const course = modalEl.querySelector('#item-course').value;
        const name = modalEl.querySelector('#item-name').value.trim();
        const description = modalEl.querySelector('#item-description').value.trim();
        const dietary = modalEl.querySelector('#item-dietary').value.trim();
        
        if (!name) {
          window.Toast.warning('Please provide a name');
          return false;
        }

        const data = { course, name, description, dietary };

        try {
          if (isEdit) {
            await window.API.put('/api/menu/' + item.id, data);
            window.Toast.success('Menu item updated!');
          } else {
            await window.API.post('/api/menu', data);
            window.Toast.success('Menu item added!');
          }
          await this.loadData();
          window.Modal.close();
        } catch (err) {
          window.Toast.error('Failed to save menu item');
        }
      }
    });
  },

  deleteItem(id) {
    window.Modal.confirm({
      title: 'Delete Item?',
      message: 'Are you sure you want to remove this from the menu?',
      confirmText: 'Delete',
      confirmClass: 'btn-danger',
      onConfirm: async () => {
        try {
          await window.API.del('/api/menu/' + id);
          window.Toast.success('Item deleted');
          await this.loadData();
        } catch (err) {
          window.Toast.error('Failed to delete item');
        }
      }
    });
  },

  cleanup() {
    if (this.container) {
      this.container.removeEventListener('click', this.boundHandleClick);
    }
  }
};

window.MenuPage = MenuPage;
