const CommunicationsPage = {
  async render(container) {
    this.container = container;
    
    this.container.innerHTML = `
      <div class="communications-container">
        <header class="page-header flex-between mb-lg">
          <div>
            <h1>Communications</h1>
            <p class="text-muted">Manage SMS and Email updates for your guests.</p>
          </div>
          <button class="btn btn-primary" id="btn-compose">
            <i data-lucide="send"></i> Compose Message
          </button>
        </header>

        <div class="grid grid-3 gap-md">
          <div class="card card-glass col-span-1">
            <h3>Overview</h3>
            <div class="stat-card mt-md">
              <div class="stat-value" id="stat-sent">0</div>
              <div class="stat-label">Sent Messages</div>
            </div>
            <div class="stat-card mt-md">
              <div class="stat-value" id="stat-pending">0</div>
              <div class="stat-label">Pending Messages</div>
            </div>
          </div>
          
          <div class="card card-glass col-span-2">
            <div class="flex-between mb-md">
              <h3>Message History</h3>
              <div class="tabs">
                <button class="tab-btn active" data-filter="all">All</button>
                <button class="tab-btn" data-filter="pending">Pending</button>
                <button class="tab-btn" data-filter="sent">Sent</button>
              </div>
            </div>
            <div class="table-responsive">
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th>Type</th>
                    <th>To</th>
                    <th>Subject / Body</th>
                    <th>Scheduled For</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody id="comms-list">
                  <tr><td colspan="6" class="text-center">Loading...</td></tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    `;

    this.boundClickHandler = this.handleClicks.bind(this);
    this.container.addEventListener('click', this.boundClickHandler);
    
    await this.loadData();
  },

  async loadData() {
    try {
      this.comms = await window.API.get('/api/communications');
      this.households = await window.API.get('/api/households') || [];
      
      const activeTab = document.querySelector('.tab-btn.active');
      const filter = activeTab ? activeTab.dataset.filter : 'all';
      this.renderList(filter);
      this.updateStats();
      this.renderTargets();
    } catch (err) {
      window.Toast.error('Failed to load data');
    }
  },

  renderTargets() {
    const totalEmail = this.households.filter(h => h.email).length;
    const totalSms = this.households.filter(h => h.phone).length;
    
    const emailEl = document.getElementById('comm-targets-email');
    const smsEl = document.getElementById('comm-targets-sms');
    
    if (emailEl) emailEl.textContent = `${totalEmail} Households with Email`;
    if (smsEl) smsEl.textContent = `${totalSms} Households with Phone`;
  },

  updateStats() {
    if (!this.comms) return;
    const sent = this.comms.filter(c => c.status === 'sent').length;
    const pending = this.comms.filter(c => c.status === 'pending').length;
    
    const sentEl = document.getElementById('stat-sent');
    const pendingEl = document.getElementById('stat-pending');
    
    if (sentEl) sentEl.textContent = sent;
    if (pendingEl) pendingEl.textContent = pending;
  },

  renderList(filter) {
    const tbody = document.getElementById('comms-list');
    if (!tbody || !this.comms) return;
    
    let filtered = this.comms;
    if (filter !== 'all') {
      filtered = this.comms.filter(c => c.status === filter);
    }

    filtered.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));

    if (filtered.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted">No messages found.</td></tr>`;
      return;
    }

    tbody.innerHTML = filtered.map(c => `
      <tr>
        <td>
          <span class="badge badge-${c.type === 'email' ? 'primary' : 'info'}">
            <i data-lucide="${c.type === 'email' ? 'mail' : 'message-square'}"></i> ${c.type.toUpperCase()}
          </span>
        </td>
        <td>${window.Helpers.escapeHtml(c.to)}</td>
        <td class="truncate" style="max-width: 200px;" title="${window.Helpers.escapeHtml(c.subject || c.body)}">
          ${window.Helpers.escapeHtml(c.subject || c.body)}
        </td>
        <td>${window.Helpers.formatDate(c.scheduledFor)}</td>
        <td>
          <span class="badge badge-${this.getStatusBadgeColor(c.status)}">${c.status}</span>
        </td>
        <td>
          ${c.status === 'pending' ? `
            <button class="btn btn-sm btn-danger btn-icon btn-cancel" data-id="${c.id}" title="Cancel">
              <i data-lucide="x"></i>
            </button>
          ` : `
            <button class="btn btn-sm btn-icon btn-delete" data-id="${c.id}" title="Delete Record">
              <i data-lucide="trash-2"></i>
            </button>
          `}
        </td>
      </tr>
    `).join('');
  },

  getStatusBadgeColor(status) {
    if (status === 'sent') return 'success';
    if (status === 'pending') return 'warning';
    if (status === 'failed') return 'danger';
    if (status === 'cancelled') return 'info';
    return 'info';
  },

  async handleClicks(e) {
    if (e.target.closest('#btn-compose')) {
      this.showComposeModal();
    }

    const cancelBtn = e.target.closest('.btn-cancel');
    if (cancelBtn) {
      const id = cancelBtn.dataset.id;
      window.Modal.confirm({
        title: 'Cancel Message?',
        message: 'Are you sure you want to cancel this scheduled message?',
        confirmText: 'Yes, Cancel',
        confirmClass: 'btn-danger',
        onConfirm: () => this.cancelMessage(id)
      });
    }

    const deleteBtn = e.target.closest('.btn-delete');
    if (deleteBtn) {
      const id = deleteBtn.dataset.id;
      window.Modal.confirm({
        title: 'Delete Record?',
        message: 'Remove this message record from history?',
        confirmText: 'Delete',
        confirmClass: 'btn-danger',
        onConfirm: () => this.deleteMessage(id)
      });
    }

    const tabBtn = e.target.closest('.tab-btn');
    if (tabBtn) {
      document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
      tabBtn.classList.add('active');
      this.renderList(tabBtn.dataset.filter);
    }
  },

  showComposeModal() {
    window.Modal.show({
      title: 'Compose Message',
      content: `
        <form id="compose-form">
          <div class="form-group">
            <label class="form-label">Message Type</label>
            <select class="form-select" name="type" id="compose-type" required>
              <option value="email">Email</option>
              <option value="sms">SMS</option>
            </select>
          </div>
          
          <div class="form-group">
            <label class="form-label">Recipient Group</label>
            <select class="form-select" name="toGroup" id="compose-group" required>
              <option value="all">Everyone</option>
              <option value="Attending">Attending Guests</option>
              <option value="Declined">Declined Guests</option>
              <option value="Pending">Pending Guests</option>
            </select>
          </div>

          <div class="form-group" id="compose-subject-group">
            <label class="form-label">Subject</label>
            <input type="text" class="form-input" name="subject" id="compose-subject" placeholder="Wedding Update">
          </div>

          <div class="form-group">
            <label class="form-label">Message Body</label>
            <textarea class="form-textarea" name="body" rows="4" required placeholder="Type your message here..."></textarea>
          </div>

          <div class="form-group">
            <label class="form-label">Schedule For (Leave blank to send immediately)</label>
            <input type="datetime-local" class="form-input" name="scheduledFor">
          </div>
        </form>
      `,
      onSubmit: async (modalEl) => {
        const form = modalEl.querySelector('#compose-form');
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        
        if (data.type === 'sms') {
          delete data.subject;
        } else if (!data.subject) {
          data.subject = 'Wedding Update';
        }

        if (!data.scheduledFor) {
          delete data.scheduledFor;
        } else {
          data.scheduledFor = new Date(data.scheduledFor).toISOString();
        }

        // Resolve recipients based on group
        const group = data.toGroup;
        let targets = this.households;
        if (group !== 'all') {
          targets = targets.filter(h => h.status === group);
        }

        const recipients = targets
          .map(h => data.type === 'email' ? h.email : h.phone)
          .filter(val => val && val.trim() !== '');

        if (recipients.length === 0) {
          window.Toast.error(`No valid ${data.type} addresses found for ${group} guests.`);
          return;
        }

        data.recipients = recipients;
        data.to = `${recipients.length} Recipients (${group})`;
        delete data.toGroup;

        try {
          await window.API.post('/api/communications', data);
          window.Toast.success('Blast message scheduled successfully!');
          window.Modal.close();
          await this.loadData();
        } catch (err) {
          window.Toast.error('Failed to schedule blast');
        }
      }
    });

    // Add listener to hide subject field if SMS is selected
    const typeSelect = document.getElementById('compose-type');
    const subjectGroup = document.getElementById('compose-subject-group');
    const subjectInput = document.getElementById('compose-subject');
    
    typeSelect.addEventListener('change', (e) => {
      if (e.target.value === 'sms') {
        subjectGroup.style.display = 'none';
        subjectInput.removeAttribute('required');
      } else {
        subjectGroup.style.display = 'block';
      }
    });
  },

  async cancelMessage(id) {
    try {
      await window.API.put(`/api/communications/${id}`, { status: 'cancelled' });
      window.Toast.success('Message cancelled');
      await this.loadData();
    } catch (err) {
      window.Toast.error('Failed to cancel message');
    }
  },

  async deleteMessage(id) {
    try {
      await window.API.del(`/api/communications/${id}`);
      window.Toast.success('Record deleted');
      await this.loadData();
    } catch (err) {
      window.Toast.error('Failed to delete record');
    }
  },

  cleanup() {
    if (this.container && this.boundClickHandler) {
      this.container.removeEventListener('click', this.boundClickHandler);
    }
    this.container.innerHTML = '';
  }
};

window.CommunicationsPage = CommunicationsPage;
