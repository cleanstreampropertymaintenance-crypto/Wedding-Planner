# Ever After Wedding Planner

A full-stack Node.js wedding planner application with automated SMS/Email capabilities, custom RSVP forms, and a cloud-based Supabase backend.

## Local Development

If you are running this locally on your own machine:

1. Make sure you have Node.js installed.
2. Install dependencies:
   ```bash
   cd server
   npm install
   ```
3. Start the development server:
   ```bash
   npm run dev
   ```
4. Open your browser to `http://localhost:3000`.

## Deployment Guide

Your application is completely ready to be deployed to the internet! Because you are using a Supabase cloud database, your data is safe and will persist even when your host restarts.

### Option 1: Render.com (Recommended & Free)

1. Upload this entire project folder to a new repository on **GitHub**.
2. Create a free account at [Render.com](https://render.com/).
3. Click **New +** and select **Web Service**.
4. Connect your GitHub account and select your repository.
5. Configure the Web Service:
   - **Name:** Whatever you want (e.g., `ever-after-wedding`)
   - **Build Command:** `cd server && npm install`
   - **Start Command:** `cd server && npm start` (or `node index.js`)
6. **CRITICAL STEP:** Scroll down to the **Environment Variables** section and add the following keys exactly as they appear in your local `.env` file:
   - `SUPABASE_URL` = `https://uvrewfeilgwudjweogyf.supabase.co`
   - `SUPABASE_KEY` = `your_sb_secret_key`
   - *(Optional)* Add your `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM_NUMBER`, and `SENDGRID_API_KEY` here as well, or you can configure them directly in the app's UI Settings tab later!
7. Click **Create Web Service**.

Once Render finishes building, it will give you a live URL (e.g., `https://ever-after-wedding.onrender.com`). You can use this URL to safely send RSVP texts without the cellular carriers blocking your messages!

### Option 2: Heroku or Railway
The process is virtually identical: connect your GitHub, set your Build/Start commands to run out of the `server/` directory, and be sure to provide your `SUPABASE_URL` and `SUPABASE_KEY` environment variables in their dashboard settings!
