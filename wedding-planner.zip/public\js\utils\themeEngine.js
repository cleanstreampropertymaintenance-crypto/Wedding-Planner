/* ═══════════════════════════════════════
   Theme Engine — Dynamic theme switching
   ═══════════════════════════════════════ */
window.ThemeEngine = {
  currentTheme: 'midnight-garden',
  customStyles: null,

  async init() {
    try {
      const settings = await window.API.get('/api/settings');
      if (settings && settings.theme) {
        this.apply(settings.theme, settings.customTheme, false);
      }
      if (settings && settings.fontBody) {
        document.documentElement.style.setProperty('--font-body', settings.fontBody);
      }
      if (settings && settings.fontDisplay) {
        document.documentElement.style.setProperty('--font-display', settings.fontDisplay);
      }
      if (settings && settings.fontAccent) {
        document.documentElement.style.setProperty('--font-accent', settings.fontAccent);
      }
      if (settings && settings.backgroundImage) {
        document.body.style.backgroundImage = `url(${settings.backgroundImage})`;
        document.body.style.backgroundSize = 'cover';
        document.body.style.backgroundPosition = 'center';
        document.body.style.backgroundAttachment = 'fixed';
        if (settings.backgroundOpacity != null) {
          this._applyOverlay(settings.backgroundOpacity);
        }
      }
    } catch (e) {
      // Settings not loaded yet, use defaults
    }
  },

  apply(themeName, customOverrides, save = true) {
    document.documentElement.setAttribute('data-theme', themeName);
    this.currentTheme = themeName;

    // Remove custom style element if exists
    const existing = document.getElementById('custom-theme-styles');
    if (existing) existing.remove();

    // Apply custom overrides
    if (customOverrides && typeof customOverrides === 'object') {
      const style = document.createElement('style');
      style.id = 'custom-theme-styles';
      let css = ':root {\n';
      for (const [key, value] of Object.entries(customOverrides)) {
        if (value) css += `  --${key}: ${value};\n`;
      }
      css += '}';
      style.textContent = css;
      document.head.appendChild(style);
      this.customStyles = customOverrides;
    }

    if (save) {
      this._saveTheme(themeName, customOverrides);
    }
  },

  setFont(type, fontFamily) {
    const varName = type === 'body' ? '--font-body' : type === 'display' ? '--font-display' : '--font-accent';
    document.documentElement.style.setProperty(varName, fontFamily);
  },

  setBackground(imageUrl, opacity = 0.85) {
    if (imageUrl) {
      document.body.style.backgroundImage = `url(${imageUrl})`;
      document.body.style.backgroundSize = 'cover';
      document.body.style.backgroundPosition = 'center';
      document.body.style.backgroundAttachment = 'fixed';
      this._applyOverlay(opacity);
    } else {
      document.body.style.backgroundImage = 'none';
      this._removeOverlay();
    }
  },

  _applyOverlay(opacity) {
    this._removeOverlay();
    const overlay = document.createElement('div');
    overlay.id = 'bg-overlay';
    overlay.style.cssText = `position:fixed;inset:0;background:var(--bg-primary);opacity:${opacity};z-index:-1;pointer-events:none;`;
    document.body.appendChild(overlay);
  },

  _removeOverlay() {
    const overlay = document.getElementById('bg-overlay');
    if (overlay) overlay.remove();
  },

  async _saveTheme(themeName, customOverrides) {
    try {
      await window.API.put('/api/settings', { theme: themeName, customTheme: customOverrides || null });
    } catch (e) { /* ignore */ }
  },

  getThemes() {
    return [
      { id: 'midnight-garden', name: 'Midnight Garden', description: 'Deep purple elegance', preview: ['#0f1019','#8b7cf6','#171825'] },
      { id: 'romantic-blush', name: 'Romantic Blush', description: 'Soft pink romance', preview: ['#fdf2f4','#e8668a','#fff5f7'] },
      { id: 'classic-gold', name: 'Classic Gold', description: 'Timeless sophistication', preview: ['#1a1814','#d4a843','#242018'] },
      { id: 'ocean-breeze', name: 'Ocean Breeze', description: 'Coastal tranquility', preview: ['#0c1929','#22d3ee','#132238'] },
      { id: 'rustic-sage', name: 'Rustic Sage', description: 'Natural warmth', preview: ['#f5f0eb','#6b8a5e','#faf7f3'] },
      { id: 'modern-minimalist', name: 'Modern Minimalist', description: 'Clean & crisp', preview: ['#fafafa','#1a1a1a','#ffffff'] },
    ];
  },

  getFonts() {
    return {
      display: [
        "'Playfair Display', Georgia, serif",
        "'Cormorant Garamond', Georgia, serif",
        "'Lora', Georgia, serif",
        "'Dancing Script', cursive",
        "'Montserrat', sans-serif",
        "'Inter', sans-serif",
      ],
      body: [
        "'Inter', sans-serif",
        "'Montserrat', sans-serif",
        "'Lora', Georgia, serif",
        "'Cormorant Garamond', Georgia, serif",
      ],
      accent: [
        "'Dancing Script', cursive",
        "'Cormorant Garamond', Georgia, serif",
        "'Playfair Display', Georgia, serif",
        "'Lora', Georgia, serif",
      ],
    };
  }
};
