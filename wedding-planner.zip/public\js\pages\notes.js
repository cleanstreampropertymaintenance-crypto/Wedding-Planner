const NotesPage = {
  async render(container) {
    container.innerHTML = `
      <div class="flex flex-between mb-lg">
        <h2>Notes & Ideas</h2>
        <button class="btn btn-primary" id="btn-add-note"><i data-lucide="plus"></i> Add Note</button>
      </div>
      <div class="grid grid-3 gap-md" id="notes-grid">
        <div class="text-center col-span-3 text-muted">Loading...</div>
      </div>
    `;

    this.container = container;
    this.boundHandleClick = this.handleClick.bind(this);
    container.addEventListener('click', this.boundHandleClick);
    
    await this.loadData();
  },

  async loadData() {
    try {
      this.notes = await window.API.get('/api/notes') || [];
      this.renderList();
    } catch (err) {
      window.Toast.error('Failed to load notes');
    }
  },

  renderList() {
    const grid = this.container.querySelector('#notes-grid');
    
    if (this.notes.length === 0) {
      grid.innerHTML = `<div class="text-center col-span-3 text-muted">No notes yet. Start brainstorming!</div>`;
      return;
    }

    grid.innerHTML = this.notes.map(note => `
      <div class="card card-glass card-hover" style="display: flex; flex-direction: column;" data-id="${note.id}">
        <div class="flex flex-between mb-sm">
          <h3 class="text-lg">${window.Helpers.escapeHtml(note.title || 'Untitled Note')}</h3>
          <div>
            <button class="btn btn-icon btn-sm edit-note"><i data-lucide="edit-2"></i></button>
            <button class="btn btn-icon btn-sm text-danger delete-note"><i data-lucide="trash-2"></i></button>
          </div>
        </div>
        <div class="text-muted text-sm mb-md" style="flex-grow: 1; white-space: pre-wrap;">${window.Helpers.escapeHtml(note.content || '')}</div>
        <div class="text-sm text-muted" style="border-top: 1px solid rgba(255,255,255,0.1); padding-top: 0.5rem;">
          ${window.Helpers.formatDate(note.updatedAt || note.createdAt)}
        </div>
      </div>
    `).join('');
  },

  handleClick(e) {
    if (e.target.closest('#btn-add-note')) {
      this.showNoteForm();
    } else if (e.target.closest('.delete-note')) {
      const id = e.target.closest('.card').dataset.id;
      this.deleteNote(id);
    } else if (e.target.closest('.edit-note')) {
      const id = e.target.closest('.card').dataset.id;
      const note = this.notes.find(n => n.id === id);
      if (note) this.showNoteForm(note);
    }
  },

  showNoteForm(note = null) {
    const isEdit = !!note;
    window.Modal.show({
      title: isEdit ? 'Edit Note' : 'Add Note',
      content: `
        <form id="note-form">
          <div class="form-group mb-md">
            <label class="form-label">Title</label>
            <input type="text" class="form-input" id="note-title" required value="${note ? window.Helpers.escapeHtml(note.title) : ''}">
          </div>
          <div class="form-group mb-md">
            <label class="form-label">Content</label>
            <textarea class="form-textarea" id="note-content" rows="6" required>${note ? window.Helpers.escapeHtml(note.content) : ''}</textarea>
          </div>
          <div class="flex gap-sm" style="justify-content: flex-end;">
            <button type="submit" class="btn btn-primary">${isEdit ? 'Save Changes' : 'Save Note'}</button>
          </div>
        </form>
      `,
      onSubmit: async (modalEl) => {
        const title = modalEl.querySelector('#note-title').value.trim();
        const content = modalEl.querySelector('#note-content').value.trim();
        
        if (!title || !content) {
          window.Toast.warning('Please provide a title and content');
          return false;
        }

        const data = { title, content };

        try {
          if (isEdit) {
            await window.API.put('/api/notes/' + note.id, data);
            window.Toast.success('Note updated!');
          } else {
            await window.API.post('/api/notes', data);
            window.Toast.success('Note added!');
          }
          await this.loadData();
          window.Modal.close();
        } catch (err) {
          window.Toast.error('Failed to save note');
        }
      }
    });
  },

  deleteNote(id) {
    window.Modal.confirm({
      title: 'Delete Note?',
      message: 'Are you sure you want to delete this note?',
      confirmText: 'Delete',
      confirmClass: 'btn-danger',
      onConfirm: async () => {
        try {
          await window.API.del('/api/notes/' + id);
          window.Toast.success('Note deleted');
          await this.loadData();
        } catch (err) {
          window.Toast.error('Failed to delete note');
        }
      }
    });
  },

  cleanup() {
    if (this.container) {
      this.container.removeEventListener('click', this.boundHandleClick);
    }
  }
};

window.NotesPage = NotesPage;
