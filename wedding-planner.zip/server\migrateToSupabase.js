require('dotenv').config();
const fs = require('fs').promises;
const path = require('path');
const { createClient } = require('@supabase/supabase-js');

const DATA_DIR = path.join(__dirname, 'data');

async function migrate() {
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_KEY) {
    console.error('Missing SUPABASE_URL or SUPABASE_KEY in environment variables.');
    process.exit(1);
  }

  const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

  console.log('☁️  Connected to Supabase. Beginning migration...');

  try {
    const files = await fs.readdir(DATA_DIR);
    const jsonFiles = files.filter(f => f.endsWith('.json'));

    if (jsonFiles.length === 0) {
      console.log('No local data files found to migrate.');
      return;
    }

    for (const file of jsonFiles) {
      const collectionName = path.basename(file, '.json');
      const filePath = path.join(DATA_DIR, file);
      
      const rawData = await fs.readFile(filePath, 'utf-8');
      const data = JSON.parse(rawData);

      console.log(`Migrating collection '${collectionName}' (${Array.isArray(data) ? data.length : 1} records)...`);

      const { error } = await supabase
        .from('data_store')
        .upsert({ collection: collectionName, data: data });

      if (error) {
        console.error(`❌ Failed to migrate ${collectionName}:`, error.message);
      } else {
        console.log(`✅ Successfully migrated ${collectionName}`);
      }
    }

    console.log('🎉 Migration complete! Your data is now in the cloud.');
  } catch (err) {
    console.error('Migration failed:', err);
  }
}

migrate();
