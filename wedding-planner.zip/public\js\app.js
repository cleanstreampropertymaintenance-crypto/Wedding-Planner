/* ═══════════════════════════════════════
   App — Main SPA Router & Controller
   ═══════════════════════════════════════ */
(function() {
  const pages = {
    'dashboard': () => window.DashboardPage,
    'guests': () => window.GuestsPage,
    'guest-checklist': () => window.GuestChecklistPage,
    'wedding-party': () => window.WeddingPartyPage,
    'communications': () => window.CommunicationsPage,
    'budget': () => window.BudgetPage,
    'vendors': () => window.VendorsPage,
    'timeline': () => window.TimelinePage,
    'seating': () => window.SeatingPage,
    'music': () => window.MusicPage,
    'menu': () => window.MenuPage,
    'mood-board': () => window.MoodBoardPage,
    'gallery': () => window.GalleryPage,
    'registry': () => window.RegistryPage,
    'notes': () => window.NotesPage,
    'settings': () => window.SettingsPage,
    'rsvp-builder': () => window.RsvpBuilderPage,
  };

  let currentPage = null;
  let currentPageName = null;

  async function navigate(pageName) {
    if (currentPageName === pageName) return;

    const container = document.getElementById('main-content');

    // Cleanup current page
    if (currentPage && currentPage.cleanup) {
      currentPage.cleanup();
    }

    // Show loader
    container.innerHTML = '<div class="page-loader" id="page-loader"><div class="loader-spinner"></div><p>Loading...</p></div>';

    // Handle public RSVP route specially
    if (pageName === 'rsvp') {
      document.body.classList.add('public-view');
      document.getElementById('sidebar').style.display = 'none';
      container.style.marginLeft = '0';
      container.style.padding = '0';
      
      if (currentPage && currentPage.cleanup) currentPage.cleanup();
      container.innerHTML = '<div class="page-loader" id="page-loader"><div class="loader-spinner"></div><p>Loading RSVP Form...</p></div>';
      
      // We will define a public RSVP renderer directly here or in a separate file
      renderPublicRsvp(container);
      return;
    }

    // Get page module
    const pageGetter = pages[pageName];
    if (!pageGetter) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">🔍</div>
          <h3 class="empty-state-title">Page Not Found</h3>
          <p class="empty-state-text">The page "${pageName}" doesn't exist.</p>
          <a href="#dashboard" class="btn btn-primary">Go to Dashboard</a>
        </div>
      `;
      return;
    }

    const page = pageGetter();
    if (!page) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">🚧</div>
          <h3 class="empty-state-title">Loading Error</h3>
          <p class="empty-state-text">This page module hasn't loaded yet. Try refreshing.</p>
        </div>
      `;
      return;
    }

    currentPage = page;
    currentPageName = pageName;

    // Update sidebar
    window.Sidebar.setActive(pageName);

    // Render page
    try {
      container.innerHTML = '';
      await page.render(container);
      if (window.lucide) {
        window.lucide.createIcons();
      }
    } catch (err) {
      console.error(`Error rendering ${pageName}:`, err);
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">💥</div>
          <h3 class="empty-state-title">Something went wrong</h3>
          <p class="empty-state-text">${window.Helpers.escapeHtml(err.message)}</p>
          <button class="btn btn-primary" onclick="location.reload()">Reload</button>
        </div>
      `;
    }
  }

  function getPageFromHash() {
    let hash = window.location.hash.slice(1) || 'dashboard';
    if (hash.startsWith('/')) hash = hash.slice(1);
    return hash.split('?')[0];
  }

  // Hash change handler
  window.addEventListener('hashchange', () => {
    navigate(getPageFromHash());
  });

  // Init
  document.addEventListener('DOMContentLoaded', async () => {
    window.Sidebar.init();
    await window.ThemeEngine.init();
    navigate(getPageFromHash());
  });

  // --- Public RSVP Renderer ---
  async function renderPublicRsvp(container) {
    const params = new URLSearchParams(window.location.hash.split('?')[1]);
    const hhId = params.get('id');
    
    if (!hhId) {
      container.innerHTML = '<div class="empty-state"><h3 class="text-danger">Invalid Link</h3><p>No household ID provided in the link.</p></div>';
      return;
    }

    try {
      const data = await window.API.get(`/api/rsvp/public/${hhId}`);
      const hh = data.household;
      const config = data.config;
      
      // Apply styles
      const styles = config.styles || {
        bgColor: 'var(--surface-color)',
        textColor: 'var(--text-primary)',
        inputColor: 'rgba(0,0,0,0.05)',
        font: "'Inter', sans-serif"
      };

      // Check deadline
      if (config.deadline) {
        const today = new Date();
        today.setHours(0,0,0,0);
        const deadlineDate = new Date(config.deadline);
        // We consider it closed if today is STRICTLY after the deadline
        if (today > deadlineDate) {
          container.innerHTML = `
            <div style="background-color: ${styles.bgColor}; color: ${styles.textColor}; font-family: ${styles.font}; min-height: 100vh; display: flex; align-items: center; justify-content: center;">
              <div class="card p-xl text-center" style="max-width: 500px;">
                <h1 style="font-size: 2rem; margin-bottom: 1rem;">RSVP Closed</h1>
                <p>The deadline to RSVP for this event has passed. If you still need to respond, please contact the couple directly.</p>
              </div>
            </div>
          `;
          return;
        }
      }

      // Build form HTML
      let bgStyle = styles.bgImage ? `background-image: url('${window.Helpers.escapeHtml(styles.bgImage)}'); background-size: cover; background-position: center; background-attachment: fixed;` : `background-color: ${styles.bgColor};`;
      let formHtml = `
        <div style="${bgStyle} color: ${styles.textColor}; font-family: ${styles.font}; min-height: 100vh; width: 100vw; position: absolute; top: 0; left: 0; overflow-y: auto;">
          <div style="max-width: 600px; margin: 40px auto; padding: 20px;">
            <div class="card p-xl" style="background: ${styles.bgImage ? `rgba(${styles.bgColor.match(/\\w\\w/g)?.map(x=>parseInt(x,16)).join(',')||'255,255,255'}, 0.85)` : 'transparent'}; backdrop-filter: blur(10px); box-shadow: none; border: none;">
              <div class="text-center mb-xl">
                <h1 class="logo-title" style="font-size: 2.5rem; margin-bottom: 0.5rem; color: ${styles.textColor};">${window.Helpers.escapeHtml(hh.householdName || 'Guest')} RSVP</h1>
                <p style="opacity: 0.8;">You're invited to celebrate with us!</p>
              </div>
              <form id="public-rsvp-form" class="flex flex-col gap-lg">
      `;
      
      config.blocks.forEach((b, idx) => {
        if (b.type === 'header') {
          formHtml += `<div class="rsvp-field-block p-md" style="text-align: center;">
            <h2 style="color: ${styles.textColor}; font-size: 1.8rem; border-bottom: 2px solid rgba(0,0,0,0.1); padding-bottom: 0.5rem; margin-bottom: 0;">${window.Helpers.escapeHtml(b.label)}</h2>
          </div>`;
          return;
        } else if (b.type === 'paragraph') {
          formHtml += `<div class="rsvp-field-block p-md" style="text-align: center;">
            <p style="color: ${styles.textColor}; font-size: 1.1rem; opacity: 0.9;">${window.Helpers.escapeHtml(b.label).replace(/\\n/g, '<br>')}</p>
          </div>`;
          return;
        } else if (b.type === 'image') {
          formHtml += `<div class="rsvp-field-block p-md" style="text-align: center;">
            <img src="${window.Helpers.escapeHtml(b.label)}" style="max-width: 100%; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);" alt="Form Image" onerror="this.style.display='none'">
          </div>`;
          return;
        }

        formHtml += `<div class="rsvp-field-block p-md" style="background: ${styles.inputColor}; border-radius: 8px;">
          <label class="form-label text-md fw-bold mb-sm" style="color: ${styles.textColor};">${window.Helpers.escapeHtml(b.label)}</label>`;
          
        if (b.type === 'attendance') {
          formHtml += `<p class="text-sm text-muted mb-md">Please confirm attendance for each member of your party.</p>`;
          if (hh.members && hh.members.length > 0) {
            hh.members.forEach((m, mIdx) => {
              formHtml += `
                <div class="flex flex-between mb-sm p-sm" style="background: ${styles.inputColor}; border-radius: 4px; border: 1px solid rgba(0,0,0,0.1);">
                  <span>${window.Helpers.escapeHtml(m.firstName)} ${window.Helpers.escapeHtml(m.lastName || '')}</span>
                  <label class="flex flex-center gap-xs" style="cursor: pointer;">
                    <input type="checkbox" name="att_${m.id}" value="true" ${m.isAttending !== false ? 'checked' : ''} style="width: 20px; height: 20px;">
                    <span>Attending</span>
                  </label>
                </div>
              `;
            });
          } else {
             formHtml += `<p class="text-danger text-sm">No members found in this household.</p>`;
          }
        } else if (b.type === 'plus_one') {
          formHtml += `
            <div id="plus-one-container"></div>
            <button type="button" class="btn btn-sm btn-ghost mt-sm" onclick="window.addPlusOne()">+ Add Plus One</button>
          `;
        } else if (b.type === 'radio') {
          b.options.forEach((opt, optIdx) => {
            formHtml += `
              <label class="flex flex-center gap-sm mb-xs" style="cursor: pointer;">
                <input type="radio" name="ans_${b.id}" value="${window.Helpers.escapeHtml(opt)}" ${hh.rsvpResponses && hh.rsvpResponses[b.id] === opt ? 'checked' : ''} required>
                <span>${window.Helpers.escapeHtml(opt)}</span>
              </label>
            `;
          });
        } else if (b.type === 'address') {
          const existingAddr = hh.address ? window.Helpers.escapeHtml(hh.address) : '';
          formHtml += `<input type="text" class="form-input" name="hh_address" value="${existingAddr}" placeholder="123 Main St, City, ST 12345" style="background: ${styles.bgColor}; color: ${styles.textColor}; border: 1px solid rgba(0,0,0,0.2);">`;
        } else if (b.type === 'email') {
          const existingEmail = hh.email ? window.Helpers.escapeHtml(hh.email) : '';
          formHtml += `<input type="email" class="form-input" name="hh_email" value="${existingEmail}" placeholder="your@email.com" style="background: ${styles.bgColor}; color: ${styles.textColor}; border: 1px solid rgba(0,0,0,0.2);">`;
        } else {
          // text
          const existingText = hh.rsvpResponses && hh.rsvpResponses[b.id] ? window.Helpers.escapeHtml(hh.rsvpResponses[b.id]) : '';
          formHtml += `<textarea class="form-input" name="ans_${b.id}" rows="2" placeholder="Your answer..." style="background: ${styles.bgColor}; color: ${styles.textColor}; border: 1px solid rgba(0,0,0,0.2);">${existingText}</textarea>`;
        }
        formHtml += `</div>`;
      });
      
      formHtml += `
              <div class="mt-lg">
                <button type="submit" class="btn w-100" style="padding: 15px; font-size: 1.1rem; background: ${styles.textColor}; color: ${styles.bgColor}; border: none;">Submit RSVP</button>
              </div>
            </form>
          </div>
        </div>
        </div>
      `;

      container.innerHTML = formHtml;
      
      window.addPlusOne = () => {
        const poContainer = document.getElementById('plus-one-container');
        const div = document.createElement('div');
        div.className = 'flex gap-sm mb-sm p-sm plus-one-entry';
        div.style.background = styles.inputColor;
        div.style.borderRadius = '4px';
        div.innerHTML = `
          <input type="text" class="form-input po-first" placeholder="First Name" required style="background: ${styles.bgColor}; color: ${styles.textColor}; border: 1px solid rgba(0,0,0,0.2);">
          <input type="text" class="form-input po-last" placeholder="Last Name" style="background: ${styles.bgColor}; color: ${styles.textColor}; border: 1px solid rgba(0,0,0,0.2);">
          <button type="button" class="btn btn-icon btn-sm" style="color: ${styles.textColor}; opacity: 0.7;" onclick="this.parentElement.remove()"><i data-lucide="trash-2"></i></button>
        `;
        poContainer.appendChild(div);
        if (window.lucide) window.lucide.createIcons();
      };

      const form = document.getElementById('public-rsvp-form');
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(form);
        
        const payload = {
          members: [],
          plusOnes: [],
          responses: {},
          address: formData.get('hh_address') || '',
          email: formData.get('hh_email') || ''
        };

        // Parse attendance
        if (hh.members) {
          hh.members.forEach(m => {
            const val = formData.get('att_' + m.id);
            payload.members.push({ id: m.id, isAttending: val === 'true' });
          });
        }

        // Parse plus ones
        document.querySelectorAll('.plus-one-entry').forEach(el => {
          payload.plusOnes.push({
            firstName: el.querySelector('.po-first').value.trim(),
            lastName: el.querySelector('.po-last').value.trim(),
            relation: 'Plus One'
          });
        });

        // Parse arbitrary answers
        config.blocks.forEach(b => {
          if (b.type === 'text' || b.type === 'radio') {
            payload.responses[b.id] = formData.get('ans_' + b.id) || '';
          }
        });

        try {
          const btn = form.querySelector('button[type="submit"]');
          btn.disabled = true;
          btn.textContent = 'Submitting...';
          await window.API.post(`/api/rsvp/public/${hhId}`, payload);
          
          container.innerHTML = `
            <div style="max-width: 600px; margin: 40px auto; padding: 20px;">
              <div class="card p-xl text-center" style="background: var(--surface-color);">
                <i data-lucide="check-circle" class="text-success mb-md" style="width:64px;height:64px;margin: 0 auto;"></i>
                <h2 class="mb-sm">Thank You!</h2>
                <p class="text-muted">Your RSVP has been successfully recorded.</p>
              </div>
            </div>
          `;
          if (window.lucide) window.lucide.createIcons();
        } catch (err) {
          window.Toast.error('Failed to submit RSVP. Please try again.');
          form.querySelector('button[type="submit"]').disabled = false;
        }
      });

      if (window.lucide) window.lucide.createIcons();
    } catch (err) {
      container.innerHTML = '<div class="empty-state"><h3 class="text-danger">Error</h3><p>Could not load the RSVP form. It may have been removed.</p></div>';
    }
  }

})();
