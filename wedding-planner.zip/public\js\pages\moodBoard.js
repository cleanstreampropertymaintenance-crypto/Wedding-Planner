const MoodBoardPage = {
  async render(container) {
    container.innerHTML = `
      <div class="flex flex-between mb-lg">
        <h2>Mood Board</h2>
        <button class="btn btn-primary" id="btn-add-pin"><i data-lucide="plus"></i> Add Pin</button>
      </div>
      <div class="grid grid-4 gap-md" id="mood-board-grid">
        <div class="text-center col-span-4 text-muted">Loading...</div>
      </div>
    `;

    this.container = container;
    this.boundHandleClick = this.handleClick.bind(this);
    container.addEventListener('click', this.boundHandleClick);
    
    await this.loadData();
  },

  async loadData() {
    try {
      this.pins = await window.API.get('/api/mood-board') || [];
      this.renderList();
    } catch (err) {
      window.Toast.error('Failed to load mood board');
    }
  },

  renderList() {
    const grid = this.container.querySelector('#mood-board-grid');
    
    if (this.pins.length === 0) {
      grid.innerHTML = `<div class="text-center col-span-4 text-muted">No pins yet. Add your inspiration!</div>`;
      return;
    }

    // A simple masonry-like or grid layout for images
    grid.innerHTML = this.pins.map(pin => `
      <div class="card card-glass card-hover" style="padding: 0; overflow: hidden;" data-id="${pin.id}">
        <img src="${pin.imageUrl}" alt="Pin" style="width: 100%; height: 200px; object-fit: cover; display: block;">
        <div class="p-sm flex flex-between">
          <span class="text-sm font-semibold">${window.Helpers.escapeHtml(pin.title || 'Inspiration')}</span>
          <button class="btn btn-icon btn-sm text-danger delete-pin"><i data-lucide="trash-2"></i></button>
        </div>
      </div>
    `).join('');
  },

  handleClick(e) {
    if (e.target.closest('#btn-add-pin')) {
      this.showPinForm();
    } else if (e.target.closest('.delete-pin')) {
      const id = e.target.closest('.card').dataset.id;
      this.deletePin(id);
    }
  },

  showPinForm() {
    window.Modal.show({
      title: 'Add Inspiration Pin',
      content: `
        <form id="pin-form">
          <div class="form-group mb-md">
            <label class="form-label">Title / Note</label>
            <input type="text" class="form-input" id="pin-title" placeholder="e.g. Floral Arch">
          </div>
          <div class="form-group mb-md">
            <label class="form-label">Image URL</label>
            <input type="url" class="form-input" id="pin-url" placeholder="https://example.com/image.jpg">
          </div>
          <div class="form-group mb-md">
            <label class="form-label">Or Upload an Image</label>
            <input type="file" class="form-input" id="pin-file" accept="image/*">
          </div>
          <div class="flex gap-sm" style="justify-content: flex-end;">
            <button type="submit" class="btn btn-primary" id="btn-submit-pin">Add Pin</button>
          </div>
        </form>
      `,
      onSubmit: async (modalEl) => {
        const title = modalEl.querySelector('#pin-title').value.trim();
        let imageUrl = modalEl.querySelector('#pin-url').value.trim();
        const fileInput = modalEl.querySelector('#pin-file');
        const submitBtn = modalEl.querySelector('#btn-submit-pin');
        
        if (!imageUrl && (!fileInput.files || fileInput.files.length === 0)) {
          window.Toast.warning('Please provide an image URL or upload a file');
          return false;
        }

        submitBtn.disabled = true;
        submitBtn.textContent = 'Uploading...';

        try {
          if (fileInput.files && fileInput.files.length > 0) {
            const formData = new FormData();
            formData.append('file', fileInput.files[0]);
            
            const uploadRes = await fetch('/api/uploads', {
              method: 'POST',
              body: formData
            });
            const uploadData = await uploadRes.json();
            if (uploadData.url) {
              imageUrl = uploadData.url;
            } else {
              throw new Error('Upload failed');
            }
          }

          await window.API.post('/api/mood-board', { title, imageUrl });
          window.Toast.success('Pin added!');
          await this.loadData();
          window.Modal.close();
        } catch (err) {
          window.Toast.error('Failed to add pin');
        } finally {
          submitBtn.disabled = false;
          submitBtn.textContent = 'Add Pin';
        }
      }
    });
  },

  deletePin(id) {
    window.Modal.confirm({
      title: 'Delete Pin?',
      message: 'Remove this inspiration image?',
      confirmText: 'Delete',
      confirmClass: 'btn-danger',
      onConfirm: async () => {
        try {
          await window.API.del('/api/mood-board/' + id);
          window.Toast.success('Pin deleted');
          await this.loadData();
        } catch (err) {
          window.Toast.error('Failed to delete pin');
        }
      }
    });
  },

  cleanup() {
    if (this.container) {
      this.container.removeEventListener('click', this.boundHandleClick);
    }
  }
};

window.MoodBoardPage = MoodBoardPage;
