require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true }));

// Serve static files
app.use(express.static(path.join(__dirname, '..', 'public')));

// Serve uploaded files
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

// API Routes
app.use('/api/households', require('./routes/guests'));
app.use('/api/guests', require('./routes/guests'));
app.use('/api/budget', require('./routes/budget'));
app.use('/api/vendors', require('./routes/vendors'));
app.use('/api/wedding-party', require('./routes/wedding-party'));
app.use('/api/timeline', require('./routes/timeline'));
app.use('/api/communications', require('./routes/communications'));
app.use('/api/seating', require('./routes/seating'));
app.use('/api/music', require('./routes/music'));
app.use('/api/menu', require('./routes/menu'));
app.use('/api/registry', require('./routes/registry'));
app.use('/api/notes', require('./routes/notes'));
app.use('/api/mood-board', require('./routes/mood-board'));
app.use('/api/gallery', require('./routes/gallery'));
app.use('/api/settings', require('./routes/settings'));
app.use('/api/uploads', require('./routes/uploads'));
app.use('/api/rsvp', require('./routes/rsvp'));

// Initialize scheduler on startup
const scheduler = require('./services/scheduler');
scheduler.loadPendingJobs();

// SPA fallback — serve index.html for all non-API routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// Error handler
app.use((err, req, res, next) => {
  console.error('Server error:', err.stack);
  res.status(500).json({ error: 'Internal server error', message: err.message });
});

app.listen(PORT, () => {
  console.log(`\n  ✨ Ever After Wedding Planner`);
  console.log(`  🌐 Running at http://localhost:${PORT}`);
  console.log(`  📁 Data stored in server/data/`);
  console.log(`  🎨 Open your browser to start planning!\n`);
});
