const DashboardPage = {
  async render(container) {
    container.innerHTML = `
      <div class="flex flex-between mb-lg">
        <div>
          <h2 id="dash-greeting">Welcome!</h2>
          <p class="text-muted" id="dash-date-countdown">Let's plan your perfect day.</p>
        </div>
        <button class="btn btn-primary" id="btn-quick-task"><i data-lucide="plus"></i> Quick Task</button>
      </div>

      <div class="grid grid-4 gap-md mb-lg">
        <div class="stat-card card card-glass">
          <div class="stat-label">Total Guests</div>
          <div class="stat-value" id="stat-guests">-</div>
          <p class="text-sm text-muted mt-sm" id="stat-rsvps">Loading...</p>
        </div>
        <div class="stat-card card card-glass">
          <div class="stat-label">Budget Used</div>
          <div class="stat-value" id="stat-budget">-</div>
          <p class="text-sm text-muted mt-sm" id="stat-budget-total">Loading...</p>
        </div>
        <div class="stat-card card card-glass">
          <div class="stat-label">Tasks Pending</div>
          <div class="stat-value" id="stat-tasks">-</div>
          <p class="text-sm text-muted mt-sm">Needs attention</p>
        </div>
        <div class="stat-card card card-glass">
          <div class="stat-label">Days to Go</div>
          <div class="stat-value" id="stat-days">-</div>
          <p class="text-sm text-muted mt-sm">Getting closer!</p>
        </div>
      </div>

      <div class="grid grid-2 gap-lg">
        <div class="card card-glass">
          <h3 class="mb-md">Upcoming Tasks</h3>
          <ul id="dash-tasks-list" class="flex flex-col gap-sm" style="list-style: none; padding: 0;">
            <li class="text-center text-muted p-sm">Loading...</li>
          </ul>
        </div>
        
        <div class="card card-glass">
          <h3 class="mb-md">Budget Overview</h3>
          <canvas id="budgetChart" width="400" height="200"></canvas>
        </div>
      </div>
    `;

    this.container = container;
    this.boundHandleClick = this.handleClick.bind(this);
    container.addEventListener('click', this.boundHandleClick);
    
    await this.loadData();
  },

  async loadData() {
    try {
      const [settings, guests, budget, tasks] = await Promise.all([
        window.API.get('/api/settings').catch(() => ({})),
        window.API.get('/api/guests').catch(() => []),
        window.API.get('/api/budget').catch(() => []),
        window.API.get('/api/tasks').catch(() => [])
      ]);

      // Update Header
      if (settings.names) {
        this.container.querySelector('#dash-greeting').textContent = `Welcome back, ${settings.names}!`;
      }
      
      // Calculate Days
      if (settings.date) {
        const weddingDate = new Date(settings.date);
        const today = new Date();
        const diffTime = weddingDate - today;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        this.container.querySelector('#stat-days').textContent = diffDays > 0 ? diffDays : 0;
        this.container.querySelector('#dash-date-countdown').textContent = `${window.Helpers.formatDate(settings.date)} • ${diffDays > 0 ? diffDays + ' days left' : 'Today is the day!'}`;
      } else {
        this.container.querySelector('#stat-days').textContent = 'N/A';
        this.container.querySelector('#dash-date-countdown').textContent = 'Set your wedding date in Settings';
      }

      // Guest Stats
      this.container.querySelector('#stat-guests').textContent = guests.length;
      const attending = guests.filter(g => g.status === 'attending').length;
      this.container.querySelector('#stat-rsvps').textContent = `${attending} confirmed attending`;

      // Budget Stats
      const totalBudget = settings.budget || 0;
      const spent = budget.reduce((sum, item) => sum + (item.paid || 0), 0);
      const estimated = budget.reduce((sum, item) => sum + (item.estimated || 0), 0);
      
      this.container.querySelector('#stat-budget').textContent = window.Helpers.formatCurrency(spent);
      this.container.querySelector('#stat-budget-total').textContent = `of ${window.Helpers.formatCurrency(totalBudget)} total`;

      // Tasks Stats
      const pendingTasks = tasks.filter(t => t.status !== 'completed');
      this.container.querySelector('#stat-tasks').textContent = pendingTasks.length;

      this.renderTasks(pendingTasks);
      this.renderChart(spent, estimated, totalBudget);

    } catch (err) {
      console.error(err);
      window.Toast.error('Failed to load dashboard data');
    }
  },

  renderTasks(tasks) {
    const list = this.container.querySelector('#dash-tasks-list');
    
    // Sort by due date if available, just grab top 5
    const topTasks = tasks.slice(0, 5);
    
    if (topTasks.length === 0) {
      list.innerHTML = `<li class="text-center text-muted p-sm">All caught up!</li>`;
      return;
    }

    list.innerHTML = topTasks.map(task => `
      <li class="flex flex-between p-sm" style="background: rgba(255,255,255,0.05); border-radius: 8px;">
        <div class="flex gap-sm align-center">
          <input type="checkbox" class="form-checkbox task-check" data-id="${task.id}">
          <span style="font-weight: 500;">${window.Helpers.escapeHtml(task.title)}</span>
        </div>
        ${task.dueDate ? `<span class="badge badge-warning text-sm">${window.Helpers.formatDate(task.dueDate)}</span>` : ''}
      </li>
    `).join('');
  },

  renderChart(spent, estimated, total) {
    const canvas = this.container.querySelector('#budgetChart');
    if (!canvas || !window.Charts) return;

    window.Charts.bar(canvas, {
      labels: ['Spent', 'Estimated', 'Total Budget'],
      datasets: [{
        label: 'Budget Tracking',
        values: [spent, estimated, total],
        color: 'rgba(212, 175, 55, 0.8)' // Gold-ish color matching the theme
      }]
    });
  },

  handleClick(e) {
    if (e.target.closest('#btn-quick-task')) {
      // Just a quick alert since this is dashboard, full task mgmt would be on task page
      window.Modal.show({
        title: 'Quick Task',
        content: `
          <form id="quick-task-form">
            <div class="form-group mb-md">
              <label class="form-label">Task Title</label>
              <input type="text" class="form-input" id="quick-task-title" required>
            </div>
            <div class="flex" style="justify-content: flex-end;">
              <button type="submit" class="btn btn-primary">Add Task</button>
            </div>
          </form>
        `,
        onSubmit: async (modalEl) => {
          const title = modalEl.querySelector('#quick-task-title').value;
          if (!title) return false;
          
          try {
            await window.API.post('/api/tasks', { title, status: 'pending' });
            window.Toast.success('Task added!');
            await this.loadData();
            window.Modal.close();
          } catch (err) {
            window.Toast.error('Failed to add task');
          }
        }
      });
    } else if (e.target.classList.contains('task-check')) {
      const id = e.target.dataset.id;
      // In a real app we'd fetch the task and update status, here we'll just optimistically update and reload
      window.API.put('/api/tasks/' + id, { status: 'completed' })
        .then(() => {
          window.Toast.success('Task completed!');
          this.loadData();
        })
        .catch(() => window.Toast.error('Failed to update task'));
    }
  },

  cleanup() {
    if (this.container) {
      this.container.removeEventListener('click', this.boundHandleClick);
    }
  }
};

window.DashboardPage = DashboardPage;
