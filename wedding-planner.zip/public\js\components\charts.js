/* Canvas Charts — No Dependencies */
window.Charts = {
  pie(canvas, { labels, values, colors }) {
    const ctx = canvas.getContext('2d');
    const w = canvas.width = canvas.offsetWidth * 2;
    const h = canvas.height = canvas.offsetHeight * 2;
    ctx.scale(2, 2);
    const cw = w/2, ch = h/2;
    const cx = cw/2, cy = ch/2;
    const r = Math.min(cx, cy) - 10;
    const total = values.reduce((a,b) => a+b, 0);
    if (total === 0) { ctx.fillStyle = '#333'; ctx.font = '14px Inter'; ctx.textAlign = 'center'; ctx.fillText('No data', cx, cy); return; }
    let start = -Math.PI/2;
    values.forEach((v, i) => {
      const slice = (v/total) * Math.PI * 2;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, r, start, start + slice);
      ctx.fillStyle = colors[i % colors.length];
      ctx.fill();
      start += slice;
    });
    // Center hole for donut
    ctx.beginPath();
    ctx.arc(cx, cy, r * 0.55, 0, Math.PI * 2);
    ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--bg-card').trim() || '#1e2033';
    ctx.fill();
  },

  bar(canvas, { labels, datasets }) {
    const ctx = canvas.getContext('2d');
    const w = canvas.width = canvas.offsetWidth * 2;
    const h = canvas.height = canvas.offsetHeight * 2;
    ctx.scale(2, 2);
    const cw = w/2, ch = h/2;
    const pad = { top: 20, right: 20, bottom: 40, left: 60 };
    const plotW = cw - pad.left - pad.right;
    const plotH = ch - pad.top - pad.bottom;

    const allVals = datasets.flatMap(d => d.values);
    const maxVal = Math.max(...allVals, 1);

    const barGroupW = plotW / labels.length;
    const barW = Math.min(barGroupW * 0.7 / datasets.length, 30);
    const gap = (barGroupW - barW * datasets.length) / 2;

    // Grid lines
    ctx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue('--divider').trim() || 'rgba(255,255,255,0.08)';
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= 4; i++) {
      const y = pad.top + plotH - (plotH * i/4);
      ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(cw - pad.right, y); ctx.stroke();
      ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--text-muted').trim() || '#6b6880';
      ctx.font = '10px Inter';
      ctx.textAlign = 'right';
      ctx.fillText(Helpers.formatCurrency(maxVal * i/4), pad.left - 5, y + 3);
    }

    // Bars
    datasets.forEach((ds, di) => {
      ds.values.forEach((v, i) => {
        const x = pad.left + i * barGroupW + gap + di * barW;
        const barH = (v / maxVal) * plotH;
        const y = pad.top + plotH - barH;
        ctx.fillStyle = ds.color;
        ctx.beginPath();
        ctx.roundRect(x, y, barW - 2, barH, [4, 4, 0, 0]);
        ctx.fill();
      });
    });

    // Labels
    ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--text-muted').trim() || '#6b6880';
    ctx.font = '10px Inter';
    ctx.textAlign = 'center';
    labels.forEach((l, i) => {
      const x = pad.left + i * barGroupW + barGroupW/2;
      ctx.fillText(l.length > 10 ? l.slice(0,10)+'…' : l, x, ch - pad.bottom + 15);
    });
  },

  progressRing(canvas, { value, max, color, label }) {
    const ctx = canvas.getContext('2d');
    const size = Math.min(canvas.offsetWidth, canvas.offsetHeight);
    canvas.width = size * 2;
    canvas.height = size * 2;
    ctx.scale(2, 2);
    const cx = size/2, cy = size/2;
    const r = size/2 - 12;
    const lineW = 10;
    const pct = Math.min(value / (max || 1), 1);

    // Background ring
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue('--border-color').trim() || 'rgba(139,124,246,0.15)';
    ctx.lineWidth = lineW;
    ctx.lineCap = 'round';
    ctx.stroke();

    // Progress ring
    ctx.beginPath();
    ctx.arc(cx, cy, r, -Math.PI/2, -Math.PI/2 + Math.PI * 2 * pct);
    ctx.strokeStyle = color || getComputedStyle(document.documentElement).getPropertyValue('--accent').trim();
    ctx.lineWidth = lineW;
    ctx.lineCap = 'round';
    ctx.stroke();

    // Text
    ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--text-primary').trim() || '#e8e6f0';
    ctx.font = `bold ${size * 0.22}px Inter`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(Math.round(pct * 100) + '%', cx, cy - 6);

    if (label) {
      ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--text-muted').trim() || '#6b6880';
      ctx.font = `${size * 0.08}px Inter`;
      ctx.fillText(label, cx, cy + size * 0.14);
    }
  }
};
