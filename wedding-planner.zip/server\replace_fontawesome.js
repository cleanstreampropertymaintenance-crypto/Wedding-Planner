const fs = require('fs');
const path = require('path');
const dir = path.join(__dirname, '..', 'public', 'js', 'pages');

const mapping = {
  '<i class="fas fa-plus"></i>': '<i data-lucide="plus"></i>',
  '<i class="fas fa-trash"></i>': '<i data-lucide="trash-2"></i>',
  '<i class="fas fa-edit"></i>': '<i data-lucide="edit-2"></i>',
  '<i class="fas fa-upload"></i>': '<i data-lucide="upload"></i>',
  '<i class="fas fa-paper-plane"></i>': '<i data-lucide="send"></i>',
  '<i class="fas fa-times"></i>': '<i data-lucide="x"></i>',
  '<i class="fas fa-external-link-alt"></i>': '<i data-lucide="external-link"></i>',
  '<i class="fas fa-${c.type === \'email\' ? \'envelope\' : \'comment-dots\'}"></i>': '<i data-lucide="${c.type === \'email\' ? \'mail\' : \'message-square\'}"></i>'
};

let files = fs.readdirSync(dir);
for (let file of files) {
  if (file.endsWith('.js')) {
    let p = path.join(dir, file);
    let content = fs.readFileSync(p, 'utf8');
    let newContent = content;
    
    for (let [fa, lucide] of Object.entries(mapping)) {
      // Escape for regex if needed, or just use string replace in a loop
      let search = fa;
      let target = lucide;
      newContent = newContent.split(search).join(target);
    }
    
    if (content !== newContent) {
      fs.writeFileSync(p, newContent);
      console.log('Replaced FA in ' + file);
    }
  }
}
