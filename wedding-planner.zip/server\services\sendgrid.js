const sgMail = require('@sendgrid/mail');
const DataStore = require('../lib/dataStore');

class SendGridService {
  constructor() {
    this.apiKey = null;
    this.fromEmail = null;
    this.init();
  }

  async init() {
    const store = new DataStore('settings');
    let settings = (await store.load().catch(()=>null)) || {};
    if (Array.isArray(settings)) settings = {};
    this.apiKey = settings.sendgridKey || process.env.SENDGRID_API_KEY;
    this.fromEmail = settings.sendgridFrom || process.env.SENDGRID_FROM_EMAIL || 'noreply@everafter.com';
    
    if (this.apiKey) {
      sgMail.setApiKey(this.apiKey);
      console.log('SendGrid initialized successfully.');
    } else {
      console.warn('SendGrid API key not found. Emails will be mocked.');
    }
  }

  updateCredentials(key, fromEmail) {
    this.apiKey = key;
    this.fromEmail = fromEmail || 'noreply@everafter.com';
    if (key) {
      sgMail.setApiKey(key);
      console.log('SendGrid re-initialized with new credentials.');
    }
  }

  async sendEmail(to, subject, html) {
    if (!this.apiKey) {
      console.log(`[MOCK EMAIL] To: ${to} | Subject: ${subject}`);
      return { success: true, mock: true, messageId: `mock_${Date.now()}` };
    }

    try {
      const msg = {
        to,
        from: this.fromEmail,
        subject,
        html,
      };
      const info = await sgMail.send(msg);
      return { success: true, messageId: info[0].headers['x-message-id'] };
    } catch (error) {
      console.error('SendGrid Error:', error);
      throw error;
    }
  }
}

module.exports = new SendGridService();
