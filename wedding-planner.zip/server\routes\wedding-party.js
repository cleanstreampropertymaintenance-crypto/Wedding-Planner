const express = require('express');
const router = express.Router();
const DataStore = require('../lib/dataStore');
const store = new DataStore('weddingParty');

router.get('/', async (req, res) => {
  try {
    const items = await store.getAll();
    res.json(items);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch wedding party members' });
  }
});

router.post('/', async (req, res) => {
  try {
    const newItem = await store.create(req.body);
    res.status(201).json(newItem);
  } catch (err) {
    res.status(500).json({ error: 'Failed to create wedding party member' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const updated = await store.update(req.params.id, req.body);
    if (!updated) return res.status(404).json({ error: 'Member not found' });
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: 'Failed to update member' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const success = await store.delete(req.params.id);
    if (!success) return res.status(404).json({ error: 'Member not found' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete member' });
  }
});

module.exports = router;
