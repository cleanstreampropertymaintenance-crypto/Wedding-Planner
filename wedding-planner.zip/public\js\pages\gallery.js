const GalleryPage = {
  async render(container) {
    container.innerHTML = `
      <div class="flex flex-between mb-lg">
        <h2>Photo Gallery</h2>
        <button class="btn btn-primary" id="btn-upload-photo"><i data-lucide="upload"></i> Upload Photo</button>
      </div>
      <div class="grid grid-4 gap-md" id="gallery-grid">
        <div class="text-center col-span-4 text-muted">Loading...</div>
      </div>
    `;

    this.container = container;
    this.boundHandleClick = this.handleClick.bind(this);
    container.addEventListener('click', this.boundHandleClick);
    
    await this.loadData();
  },

  async loadData() {
    try {
      this.photos = await window.API.get('/api/gallery') || [];
      this.renderList();
    } catch (err) {
      window.Toast.error('Failed to load gallery');
    }
  },

  renderList() {
    const grid = this.container.querySelector('#gallery-grid');
    
    if (this.photos.length === 0) {
      grid.innerHTML = `<div class="text-center col-span-4 text-muted">No photos in the gallery.</div>`;
      return;
    }

    grid.innerHTML = this.photos.map(photo => `
      <div class="card card-glass card-hover" style="padding: 0; overflow: hidden;" data-id="${photo.id}">
        <img src="${photo.url}" alt="Gallery Photo" style="width: 100%; height: 250px; object-fit: cover; display: block; cursor: pointer;" class="gallery-img">
        <div class="p-sm flex flex-between">
          <span class="text-sm text-muted">${window.Helpers.formatDate(photo.createdAt)}</span>
          <button class="btn btn-icon btn-sm text-danger delete-photo"><i data-lucide="trash-2"></i></button>
        </div>
      </div>
    `).join('');
  },

  handleClick(e) {
    if (e.target.closest('#btn-upload-photo')) {
      this.showUploadForm();
    } else if (e.target.closest('.delete-photo')) {
      const id = e.target.closest('.card').dataset.id;
      this.deletePhoto(id);
    } else if (e.target.classList.contains('gallery-img')) {
      const src = e.target.src;
      window.Modal.show({
        title: 'View Photo',
        size: 'large',
        content: `<img src="${src}" style="width: 100%; max-height: 70vh; object-fit: contain;">`
      });
    }
  },

  showUploadForm() {
    window.Modal.show({
      title: 'Upload Photo',
      content: `
        <form id="upload-form">
          <div class="form-group mb-md">
            <label class="form-label">Image URL</label>
            <input type="url" class="form-input" id="photo-url" placeholder="https://example.com/image.jpg">
          </div>
          <div class="form-group mb-md">
            <label class="form-label">Or Upload an Image</label>
            <input type="file" class="form-input" id="photo-file" accept="image/*">
          </div>
          <div class="flex gap-sm" style="justify-content: flex-end;">
            <button type="submit" class="btn btn-primary">Add Photo</button>
          </div>
        </form>
      `,
      onSubmit: async (modalEl) => {
        let url = modalEl.querySelector('#photo-url').value.trim();
        const fileInput = modalEl.querySelector('#photo-file');
        const submitBtn = modalEl.querySelector('button[type="submit"]');
        
        if (!url && (!fileInput.files || fileInput.files.length === 0)) {
          window.Toast.warning('Please provide an image URL or upload a file');
          return false;
        }

        submitBtn.disabled = true;
        submitBtn.textContent = 'Uploading...';

        try {
          if (fileInput.files && fileInput.files.length > 0) {
            const formData = new FormData();
            formData.append('file', fileInput.files[0]);
            
            const uploadRes = await fetch('/api/uploads', {
              method: 'POST',
              body: formData
            });
            const uploadData = await uploadRes.json();
            if (uploadData.url) {
              url = uploadData.url;
            } else {
              throw new Error('Upload failed');
            }
          }

          await window.API.post('/api/gallery', { url });
          window.Toast.success('Photo added!');
          await this.loadData();
          window.Modal.close();
        } catch (err) {
          window.Toast.error('Failed to add photo');
        } finally {
          submitBtn.disabled = false;
          submitBtn.textContent = 'Add Photo';
        }
      }
    });
  },

  deletePhoto(id) {
    window.Modal.confirm({
      title: 'Delete Photo?',
      message: 'Are you sure you want to remove this photo from the gallery?',
      confirmText: 'Delete',
      confirmClass: 'btn-danger',
      onConfirm: async () => {
        try {
          await window.API.del('/api/gallery/' + id);
          window.Toast.success('Photo deleted');
          await this.loadData();
        } catch (err) {
          window.Toast.error('Failed to delete photo');
        }
      }
    });
  },

  cleanup() {
    if (this.container) {
      this.container.removeEventListener('click', this.boundHandleClick);
    }
  }
};

window.GalleryPage = GalleryPage;
