/* ═══════════════════════════════════════
   API Client — Fetch wrapper
   ═══════════════════════════════════════ */
window.API = {
  baseUrl: '',

  async _request(method, url, body) {
    const opts = {
      method,
      headers: { 'Content-Type': 'application/json' },
    };
    if (body && method !== 'GET') opts.body = JSON.stringify(body);

    const res = await fetch(this.baseUrl + url, opts);
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: res.statusText }));
      throw new Error(err.error || err.message || 'Request failed');
    }
    if (res.status === 204) return null;
    return res.json();
  },

  get(url) { return this._request('GET', url); },
  post(url, body) { return this._request('POST', url, body); },
  put(url, body) { return this._request('PUT', url, body); },
  del(url) { return this._request('DELETE', url); },

  async upload(url, formData) {
    const res = await fetch(this.baseUrl + url, { method: 'POST', body: formData });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: res.statusText }));
      throw new Error(err.error || 'Upload failed');
    }
    return res.json();
  }
};
