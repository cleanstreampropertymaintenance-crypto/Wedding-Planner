const localtunnel = require('localtunnel');

(async () => {
  try {
    const tunnel = await localtunnel({ port: 3000, subdomain: 'everafter-rsvp-tunnel' });
    console.log('Tunnel is successfully active at:', tunnel.url);

    tunnel.on('close', () => {
      console.log('Tunnel was closed by the server.');
      process.exit(1);
    });
    
    tunnel.on('error', (err) => {
      console.error('Tunnel error:', err);
      process.exit(1);
    });
  } catch (err) {
    console.error('Failed to start tunnel:', err);
  }
})();
