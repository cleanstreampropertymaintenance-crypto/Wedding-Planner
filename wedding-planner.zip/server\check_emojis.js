const fs = require('fs');
const dir = 'public/js/pages';
const regex = /[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu;
fs.readdirSync(dir).forEach(f => {
  let text = fs.readFileSync(dir + '/' + f, 'utf8');
  let match = text.match(regex);
  if (match) console.log(f + ': ' + [...new Set(match)].join(' '));
});
