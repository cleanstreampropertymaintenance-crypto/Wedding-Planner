const fs = require('fs');
const path = require('path');
const dir = path.join(__dirname, '..', 'public', 'js', 'pages');

let files = fs.readdirSync(dir);
for (let file of files) {
  if (file.endsWith('.js')) {
    let p = path.join(dir, file);
    let content = fs.readFileSync(p, 'utf8');
    let newContent = content.replace(/\\\`/g, '`').replace(/\\\$\{/g, '${');
    if (content !== newContent) {
      fs.writeFileSync(p, newContent);
      console.log('Fixed ' + file);
    }
  }
}
