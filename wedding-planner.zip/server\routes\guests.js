const express = require('express');
const router = express.Router();
const DataStore = require('../lib/dataStore');

function getStore(req) {
  const collection = req.baseUrl.includes('households') ? 'households' : 'guests';
  return new DataStore(collection);
}

// Get all items
router.get('/', async (req, res, next) => {
  try {
    const store = getStore(req);
    const items = await store.getAll();
    res.json(items);
  } catch (err) {
    next(err);
  }
});

// Get by ID
router.get('/:id', async (req, res, next) => {
  try {
    const store = getStore(req);
    const item = await store.getById(req.params.id);
    if (!item) return res.status(404).json({ error: 'Not found' });
    res.json(item);
  } catch (err) {
    next(err);
  }
});

// Create
router.post('/', async (req, res, next) => {
  try {
    const store = getStore(req);
    const newItem = await store.create(req.body);
    res.status(201).json(newItem);
  } catch (err) {
    next(err);
  }
});

// Update
router.put('/:id', async (req, res, next) => {
  try {
    const store = getStore(req);
    const updated = await store.update(req.params.id, req.body);
    if (!updated) return res.status(404).json({ error: 'Not found' });
    res.json(updated);
  } catch (err) {
    next(err);
  }
});

// Delete
router.delete('/:id', async (req, res, next) => {
  try {
    const store = getStore(req);
    const success = await store.delete(req.params.id);
    if (!success) return res.status(404).json({ error: 'Not found' });
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
