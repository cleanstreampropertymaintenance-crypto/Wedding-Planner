const express = require('express');
const router = express.Router();
const DataStore = require('../lib/dataStore');
const store = new DataStore('vendors');

router.get('/', async (req, res, next) => {
  try {
    const vendors = await store.getAll();
    res.json(vendors);
  } catch (err) {
    next(err);
  }
});

router.post('/', async (req, res, next) => {
  try {
    const vendor = await store.create(req.body);
    res.status(201).json(vendor);
  } catch (err) {
    next(err);
  }
});

router.put('/:id', async (req, res, next) => {
  try {
    const vendor = await store.update(req.params.id, req.body);
    if (!vendor) return res.status(404).json({ error: 'Vendor not found' });
    res.json(vendor);
  } catch (err) {
    next(err);
  }
});

router.delete('/:id', async (req, res, next) => {
  try {
    const success = await store.delete(req.params.id);
    if (!success) return res.status(404).json({ error: 'Vendor not found' });
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
