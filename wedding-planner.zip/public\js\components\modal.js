/* Modal System */
window.Modal = {
  _onSubmit: null,
  _onConfirm: null,

  show({ title, content, onSubmit, size, footer, onShow }) {
    const overlay = document.getElementById('modal-overlay');
    const modal = document.getElementById('modal');
    const titleEl = document.getElementById('modal-title');
    const bodyEl = document.getElementById('modal-body');
    const footerEl = document.getElementById('modal-footer');

    titleEl.textContent = title || '';
    bodyEl.innerHTML = content || '';

    modal.className = 'modal' + (size ? ` modal-${size}` : '');

    this._onSubmit = onSubmit || null;

    if (footer !== undefined) {
      footerEl.innerHTML = footer;
    } else if (onSubmit) {
      footerEl.innerHTML = `
        <button class="btn btn-ghost" id="modal-cancel-btn">Cancel</button>
        <button class="btn btn-primary" id="modal-submit-btn">Save</button>
      `;
    } else {
      footerEl.innerHTML = `<button class="btn btn-ghost" id="modal-cancel-btn">Close</button>`;
    }

    overlay.classList.add('active');

    // Event listeners
    setTimeout(() => {
      const cancelBtn = document.getElementById('modal-cancel-btn');
      const submitBtn = document.getElementById('modal-submit-btn');
      if (cancelBtn) cancelBtn.onclick = () => this.close();
      if (submitBtn) submitBtn.onclick = () => this._handleSubmit();
      const firstInput = bodyEl.querySelector('input, select, textarea');
      if (firstInput) firstInput.focus();
      if (onShow) onShow(modal);
    }, 50);
  },

  confirm({ title, message, confirmText, confirmClass, onConfirm }) {
    this._onConfirm = onConfirm;
    this.show({
      title: title || 'Confirm',
      content: `<p>${message || 'Are you sure?'}</p>`,
      footer: `
        <button class="btn btn-ghost" id="modal-cancel-btn">Cancel</button>
        <button class="btn ${confirmClass || 'btn-danger'}" id="modal-confirm-btn">${confirmText || 'Confirm'}</button>
      `
    });
    setTimeout(() => {
      const confirmBtn = document.getElementById('modal-confirm-btn');
      const cancelBtn = document.getElementById('modal-cancel-btn');
      if (confirmBtn) confirmBtn.onclick = () => { if (this._onConfirm) this._onConfirm(); this.close(); };
      if (cancelBtn) cancelBtn.onclick = () => this.close();
    }, 50);
  },

  _handleSubmit() {
    if (this._onSubmit) {
      const modal = document.getElementById('modal');
      this._onSubmit(modal);
    }
  },

  close() {
    const overlay = document.getElementById('modal-overlay');
    overlay.classList.remove('active');
    this._onSubmit = null;
    this._onConfirm = null;
  },

  init() {
    const overlay = document.getElementById('modal-overlay');
    const closeBtn = document.getElementById('modal-close');

    closeBtn.addEventListener('click', () => this.close());
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) this.close();
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && overlay.classList.contains('active')) this.close();
    });
  }
};

document.addEventListener('DOMContentLoaded', () => window.Modal.init());
