window.VendorsPage = {
  data: [],
  categories: ['Venue', 'Catering', 'Photography', 'Videography', 'Planner', 'Florist', 'Entertainment', 'Hair/Makeup', 'Officiant', 'Rentals', 'Cake', 'Transportation', 'Other'],
  statuses: ['Inquiry', 'Interviewing', 'Hired', 'Rejected'],

  async render(container) {
    this.container = container;
    await this.loadData();
    this.renderHTML();
    this.attachEvents();
  },

  async loadData() {
    try {
      this.data = await window.API.get('/api/vendors') || [];
    } catch (err) {
      window.Toast.error('Failed to load vendors');
      this.data = [];
    }
  },

  renderHTML() {
    let hiredCount = this.data.filter(v => v.status === 'Hired').length;
    let totalCost = this.data.filter(v => v.status === 'Hired').reduce((sum, v) => sum + Number(v.cost || 0), 0);

    const vendorCards = this.data.length === 0 ? 
      `<div class="empty-state p-lg text-center">
         <div class="empty-state-icon text-2xl" style="font-size: 3rem; margin-bottom: 1rem;"><i data-lucide="store"></i></div>
         <h3 class="empty-state-title">No vendors added yet</h3>
         <p class="empty-state-text text-muted">Start tracking your wedding vendors here.</p>
       </div>` 
      : 
      `<div class="grid grid-3 gap-md">` +
      this.data.map(vendor => {
        let badgeClass = 'badge-info';
        if (vendor.status === 'Hired') badgeClass = 'badge-success';
        if (vendor.status === 'Rejected') badgeClass = 'badge-danger';
        if (vendor.status === 'Interviewing') badgeClass = 'badge-warning';

        return `
          <div class="card card-hover p-md" data-id="${vendor.id}">
            <div class="flex-between mb-sm">
              <span class="text-xs text-muted" style="text-transform: uppercase; font-weight: 600;">${vendor.category}</span>
              <span class="badge ${badgeClass}">${vendor.status}</span>
            </div>
            <h3 class="mb-xs" style="margin-bottom: 0.5rem; font-size: 1.25rem;">${window.Helpers.escapeHtml(vendor.name)}</h3>
            
            <div class="text-sm mb-md" style="margin-bottom: 1rem; color: var(--text-muted);">
              ${vendor.contact ? `<div><i data-lucide="user"></i> ${window.Helpers.escapeHtml(vendor.contact)}</div>` : ''}
              ${vendor.email ? `<div><i data-lucide="mail"></i> <a href="mailto:${window.Helpers.escapeHtml(vendor.email)}" class="text-primary">${window.Helpers.escapeHtml(vendor.email)}</a></div>` : ''}
              ${vendor.phone ? `<div><i data-lucide="phone"></i> <a href="tel:${window.Helpers.escapeHtml(vendor.phone)}" class="text-primary">${window.Helpers.escapeHtml(vendor.phone)}</a></div>` : ''}
              ${vendor.cost ? `<div class="mt-xs" style="margin-top: 0.5rem; color: var(--text-primary);"><strong>Cost:</strong> ${window.Helpers.formatCurrency(vendor.cost)}</div>` : ''}
            </div>

            ${vendor.notes ? `<p class="text-sm text-muted mb-md" style="margin-bottom: 1rem; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">${window.Helpers.escapeHtml(vendor.notes)}</p>` : ''}

            <div class="flex gap-sm">
              <button class="btn btn-sm btn-secondary flex-1 edit-btn" data-id="${vendor.id}">Edit</button>
              <button class="btn btn-sm btn-danger delete-btn" data-id="${vendor.id}">Delete</button>
            </div>
          </div>
        `;
      }).join('') + `</div>`;

    this.container.innerHTML = `
      <div class="p-lg">
        <div class="flex-between mb-lg">
          <h2>Vendors</h2>
          <button class="btn btn-primary" id="add-vendor-btn">+ Add Vendor</button>
        </div>

        <div class="grid grid-4 gap-md mb-lg">
          <div class="stat-card card p-md text-center">
            <div class="stat-value" style="font-size: 2rem; font-weight: 700;">${this.data.length}</div>
            <div class="stat-label text-muted text-sm text-uppercase">Total Vendors</div>
          </div>
          <div class="stat-card card p-md text-center">
            <div class="stat-value text-success" style="font-size: 2rem; font-weight: 700;">${hiredCount}</div>
            <div class="stat-label text-muted text-sm text-uppercase">Hired Vendors</div>
          </div>
          <div class="stat-card card p-md text-center">
            <div class="stat-value" style="font-size: 2rem; font-weight: 700;">${this.data.filter(v => v.status === 'Inquiry' || v.status === 'Interviewing').length}</div>
            <div class="stat-label text-muted text-sm text-uppercase">In Progress</div>
          </div>
          <div class="stat-card card p-md text-center">
            <div class="stat-value text-primary" style="font-size: 2rem; font-weight: 700;">${window.Helpers.formatCurrency(totalCost)}</div>
            <div class="stat-label text-muted text-sm text-uppercase">Committed Cost</div>
          </div>
        </div>

        ${vendorCards}
      </div>
    `;
  },

  attachEvents() {
    this.container.addEventListener('click', async (e) => {
      if (e.target.closest('#add-vendor-btn')) {
        this.showFormModal();
        return;
      }

      const editBtn = e.target.closest('.edit-btn');
      if (editBtn) {
        const id = editBtn.dataset.id;
        const vendor = this.data.find(v => v.id === id);
        if (vendor) this.showFormModal(vendor);
        return;
      }

      const deleteBtn = e.target.closest('.delete-btn');
      if (deleteBtn) {
        const id = deleteBtn.dataset.id;
        window.Modal.confirm({
          title: 'Delete Vendor',
          message: 'Are you sure you want to remove this vendor?',
          confirmText: 'Delete',
          confirmClass: 'btn-danger',
          onConfirm: async () => {
            try {
              await window.API.del('/api/vendors/' + id);
              window.Toast.success('Vendor deleted');
              await this.render(this.container);
            } catch (err) {
              window.Toast.error('Failed to delete vendor');
            }
          }
        });
        return;
      }
    });
  },

  showFormModal(vendor = null) {
    const isEdit = !!vendor;
    
    const catOptions = this.categories.map(c => 
      `<option value="${c}" ${vendor && vendor.category === c ? 'selected' : ''}>${c}</option>`
    ).join('');

    const statusOptions = this.statuses.map(s => 
      `<option value="${s}" ${vendor && vendor.status === s ? 'selected' : ''}>${s}</option>`
    ).join('');

    window.Modal.show({
      title: isEdit ? 'Edit Vendor' : 'Add Vendor',
      content: `
        <form id="vendor-form">
          <div class="grid-2 gap-md" style="margin-bottom: 1rem;">
            <div class="form-group">
              <label class="form-label">Vendor Name *</label>
              <input type="text" name="name" class="form-input" value="${vendor ? window.Helpers.escapeHtml(vendor.name) : ''}" required>
            </div>
            <div class="form-group">
              <label class="form-label">Category</label>
              <select name="category" class="form-select" required>
                ${catOptions}
              </select>
            </div>
          </div>

          <div class="grid-2 gap-md" style="margin-bottom: 1rem;">
            <div class="form-group">
              <label class="form-label">Status</label>
              <select name="status" class="form-select" required>
                ${statusOptions}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Estimated/Quoted Cost ($)</label>
              <input type="number" step="0.01" name="cost" class="form-input" value="${vendor ? vendor.cost : ''}">
            </div>
          </div>

          <hr style="margin-bottom: 1rem; border-color: var(--border-color); opacity: 0.5;">

          <div class="form-group" style="margin-bottom: 1rem;">
            <label class="form-label">Contact Person</label>
            <input type="text" name="contact" class="form-input" value="${vendor && vendor.contact ? window.Helpers.escapeHtml(vendor.contact) : ''}">
          </div>

          <div class="grid-2 gap-md" style="margin-bottom: 1rem;">
            <div class="form-group">
              <label class="form-label">Email</label>
              <input type="email" name="email" class="form-input" value="${vendor && vendor.email ? window.Helpers.escapeHtml(vendor.email) : ''}">
            </div>
            <div class="form-group">
              <label class="form-label">Phone</label>
              <input type="tel" name="phone" class="form-input" value="${vendor && vendor.phone ? window.Helpers.escapeHtml(vendor.phone) : ''}">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Notes / Details</label>
            <textarea name="notes" class="form-textarea" rows="3">${vendor && vendor.notes ? window.Helpers.escapeHtml(vendor.notes) : ''}</textarea>
          </div>
        </form>
      `,
      onSubmit: async (modalEl) => {
        const form = modalEl.querySelector('#vendor-form');
        const formData = new FormData(form);
        const data = {
          name: formData.get('name'),
          category: formData.get('category'),
          status: formData.get('status'),
          cost: parseFloat(formData.get('cost')) || 0,
          contact: formData.get('contact'),
          email: formData.get('email'),
          phone: formData.get('phone'),
          notes: formData.get('notes')
        };

        try {
          if (isEdit) {
            await window.API.put('/api/vendors/' + vendor.id, data);
            window.Toast.success('Vendor updated');
          } else {
            await window.API.post('/api/vendors', data);
            window.Toast.success('Vendor added');
          }
          window.Modal.close();
          await this.render(this.container);
        } catch (err) {
          window.Toast.error(err.message || 'Failed to save vendor');
        }
      }
    });
  },

  cleanup() {}
};
