window.TimelinePage = {
  container: null,
  events: [],

  async render(container) {
    this.container = container;
    await this.loadData();
    this.renderUI();
    this.bindEvents();
  },

  cleanup() {
    if (this.container) {
      this.container.removeEventListener('click', this.handleActions);
    }
  },

  async loadData() {
    try {
      this.events = await window.API.get('/api/timeline');
    } catch (err) {
      window.Toast.error('Failed to load timeline');
      this.events = [];
    }
  },

  renderUI() {
    this.container.innerHTML = `
      <div class="page-header flex flex-between">
        <div>
          <h1 class="page-title">Day-of Timeline</h1>
          <p class="page-subtitle">Schedule every moment of your big day.</p>
        </div>
        <button class="btn btn-primary" id="add-event-btn">+ Add Event</button>
      </div>

      <div class="mt-lg" id="timeline-list" style="max-width: 800px; margin-left: auto; margin-right: auto;">
        ${this.renderTimeline()}
      </div>
    `;
  },

  renderTimeline() {
    if (this.events.length === 0) {
      return `
        <div class="empty-state">
          <div class="empty-state-icon"><i data-lucide="clipboard-list"></i></div>
          <h3 class="empty-state-title">No events scheduled</h3>
          <p class="empty-state-text">Start planning your day by adding the first event.</p>
          <button class="btn btn-primary mt-md" onclick="document.getElementById('add-event-btn').click()">Add First Event</button>
        </div>
      `;
    }

    let html = '<div class="timeline" style="position: relative; padding-left: 30px; border-left: 2px solid rgba(255,255,255,0.2);">';
    
    this.events.forEach((ev, i) => {
      // Format time safely (assumes 'HH:mm' from input[type="time"])
      let displayTime = ev.time;
      if (ev.time) {
        try {
          const [h, m] = ev.time.split(':');
          const hr = parseInt(h, 10);
          const ampm = hr >= 12 ? 'PM' : 'AM';
          const hr12 = hr % 12 || 12;
          displayTime = `${hr12}:${m} ${ampm}`;
        } catch(e) {}
      }

      html += `
        <div class="timeline-item mb-lg" style="position: relative;">
          <div class="timeline-dot" style="position: absolute; left: -39px; top: 0; width: 16px; height: 16px; border-radius: 50%; background: var(--primary-color); border: 2px solid var(--bg-color);"></div>
          
          <div class="card card-glass card-hover" style="margin-left: 10px;">
            <div class="flex flex-between">
              <div>
                <h3 class="text-lg" style="font-weight: 600;">${window.Helpers.escapeHtml(ev.title)}</h3>
                <p class="text-primary mt-sm" style="font-weight: 600;"><i data-lucide="clock"></i> ${displayTime || 'Time TBD'}</p>
              </div>
              <div class="dropdown">
                 <button class="btn btn-icon btn-sm action-btn" data-action="edit" data-id="${ev.id}"><i data-lucide="edit-2"></i>️</button>
                 <button class="btn btn-icon btn-sm action-btn" data-action="delete" data-id="${ev.id}"><i data-lucide="trash-2"></i>️</button>
              </div>
            </div>
            
            ${ev.location ? `<p class="text-sm mt-sm"><i data-lucide="map-pin"></i> ${window.Helpers.escapeHtml(ev.location)}</p>` : ''}
            ${ev.personInCharge ? `<p class="text-sm mt-sm text-muted"><i data-lucide="user"></i> In Charge: ${window.Helpers.escapeHtml(ev.personInCharge)}</p>` : ''}
            ${ev.notes ? `<div class="mt-md p-sm text-sm" style="background: rgba(255,255,255,0.05); border-radius: 4px;">${window.Helpers.escapeHtml(ev.notes)}</div>` : ''}
          </div>
        </div>
      `;
    });

    html += '</div>';
    return html;
  },

  bindEvents() {
    this.handleActions = this.handleActions.bind(this);
    this.container.addEventListener('click', this.handleActions);

    const addBtn = this.container.querySelector('#add-event-btn');
    if (addBtn) {
      addBtn.addEventListener('click', () => this.showEventModal());
    }
  },

  handleActions(e) {
    const btn = e.target.closest('.action-btn');
    if (!btn) return;

    const action = btn.dataset.action;
    const id = btn.dataset.id;
    const event = this.events.find(ev => ev.id === id);

    if (action === 'edit' && event) {
      this.showEventModal(event);
    } else if (action === 'delete' && event) {
      this.deleteEvent(id);
    }
  },

  showEventModal(event = null) {
    const isEdit = !!event;

    window.Modal.show({
      title: isEdit ? 'Edit Event' : 'Add Event to Timeline',
      content: `
        <form id="timeline-form">
          <div class="grid grid-2 gap-md">
            <div class="form-group" style="grid-column: 1 / -1;">
              <label class="form-label">Event Title</label>
              <input type="text" class="form-input" id="event-title" required placeholder="e.g. Ceremony starts" value="${isEdit ? window.Helpers.escapeHtml(event.title) : ''}">
            </div>
            <div class="form-group">
              <label class="form-label">Time</label>
              <input type="time" class="form-input" id="event-time" value="${isEdit && event.time ? event.time : ''}">
            </div>
            <div class="form-group">
              <label class="form-label">Location</label>
              <input type="text" class="form-input" id="event-location" placeholder="e.g. Main Hall" value="${isEdit && event.location ? window.Helpers.escapeHtml(event.location) : ''}">
            </div>
            <div class="form-group" style="grid-column: 1 / -1;">
              <label class="form-label">Person In Charge (Optional)</label>
              <input type="text" class="form-input" id="event-person" placeholder="e.g. Wedding Coordinator" value="${isEdit && event.personInCharge ? window.Helpers.escapeHtml(event.personInCharge) : ''}">
            </div>
            <div class="form-group" style="grid-column: 1 / -1;">
              <label class="form-label">Notes</label>
              <textarea class="form-textarea" id="event-notes" rows="2">${isEdit && event.notes ? window.Helpers.escapeHtml(event.notes) : ''}</textarea>
            </div>
          </div>
        </form>
      `,
      onSubmit: async (modalEl) => {
        const data = {
          title: modalEl.querySelector('#event-title').value.trim(),
          time: modalEl.querySelector('#event-time').value,
          location: modalEl.querySelector('#event-location').value.trim(),
          personInCharge: modalEl.querySelector('#event-person').value.trim(),
          notes: modalEl.querySelector('#event-notes').value.trim()
        };

        if (!data.title) {
          window.Toast.error('Title is required');
          return false;
        }

        try {
          if (isEdit) {
            await window.API.put(`/api/timeline/${event.id}`, data);
            window.Toast.success('Event updated');
          } else {
            await window.API.post('/api/timeline', data);
            window.Toast.success('Event added');
          }
          await this.loadData();
          this.renderUI();
          this.bindEvents();
          return true;
        } catch (err) {
          window.Toast.error('Failed to save event');
          return false;
        }
      }
    });
  },

  deleteEvent(id) {
    window.Modal.confirm({
      title: 'Delete Event',
      message: 'Are you sure you want to remove this event from the timeline?',
      confirmText: 'Delete',
      confirmClass: 'btn-danger',
      onConfirm: async () => {
        try {
          await window.API.del(`/api/timeline/${id}`);
          window.Toast.success('Event removed');
          await this.loadData();
          this.renderUI();
          this.bindEvents();
        } catch (err) {
          window.Toast.error('Failed to delete event');
        }
      }
    });
  }
};
