window.WeddingPartyPage = {
  container: null,
  members: [],

  async render(container) {
    this.container = container;
    await this.loadData();
    this.renderUI();
    this.bindEvents();
  },

  cleanup() {
    if (this.container) {
      this.container.removeEventListener('click', this.handleActions);
    }
  },

  async loadData() {
    try {
      this.members = await window.API.get('/api/wedding-party');
    } catch (err) {
      window.Toast.error('Failed to load wedding party');
      this.members = [];
    }
  },

  renderUI() {
    this.container.innerHTML = `
      <div class="page-header flex flex-between">
        <div>
          <h1 class="page-title">Wedding Party</h1>
          <p class="page-subtitle">Organize your closest friends and family for the big day.</p>
        </div>
        <button class="btn btn-primary" id="add-member-btn">+ Add Member</button>
      </div>

      <div class="wedding-party-grid grid grid-3 mt-lg" id="wedding-party-list">
        ${this.renderMembers()}
      </div>
    `;
  },

  renderMembers() {
    if (this.members.length === 0) {
      return `
        <div class="empty-state" style="grid-column: 1 / -1;">
          <div class="empty-state-icon"><i data-lucide="gem"></i></div>
          <h3 class="empty-state-title">No one added yet</h3>
          <p class="empty-state-text">Start building your wedding party by adding members.</p>
          <button class="btn btn-primary mt-md" onclick="document.getElementById('add-member-btn').click()">Add First Member</button>
        </div>
      `;
    }

    // Sort or group members if desired. We'll just display them as cards for now.
    return this.members.map(member => `
      <div class="card card-glass card-hover">
        <div class="flex flex-between">
          <h3 class="text-lg" style="font-weight: 600;">${window.Helpers.escapeHtml(member.name)}</h3>
          <div class="dropdown">
             <button class="btn btn-icon btn-sm action-btn" data-action="edit" data-id="${member.id}"><i data-lucide="edit-2"></i>️</button>
             <button class="btn btn-icon btn-sm action-btn" data-action="delete" data-id="${member.id}"><i data-lucide="trash-2"></i>️</button>
          </div>
        </div>
        <div class="mt-sm">
          <span class="badge badge-primary">${window.Helpers.escapeHtml(member.role)}</span>
        </div>
        ${member.email ? `<p class="text-sm text-muted mt-sm"><i data-lucide="mail"></i>️ ${window.Helpers.escapeHtml(member.email)}</p>` : ''}
        ${member.phone ? `<p class="text-sm text-muted mt-sm"><i data-lucide="smartphone"></i> ${window.Helpers.escapeHtml(member.phone)}</p>` : ''}
        ${member.notes ? `<p class="text-sm mt-md" style="font-style: italic;">"${window.Helpers.escapeHtml(member.notes)}"</p>` : ''}
      </div>
    `).join('');
  },

  bindEvents() {
    this.handleActions = this.handleActions.bind(this);
    this.container.addEventListener('click', this.handleActions);

    const addBtn = this.container.querySelector('#add-member-btn');
    if (addBtn) {
      addBtn.addEventListener('click', () => this.showMemberModal());
    }
  },

  handleActions(e) {
    const btn = e.target.closest('.action-btn');
    if (!btn) return;

    const action = btn.dataset.action;
    const id = btn.dataset.id;
    const member = this.members.find(m => m.id === id);

    if (action === 'edit' && member) {
      this.showMemberModal(member);
    } else if (action === 'delete' && member) {
      this.deleteMember(id);
    }
  },

  showMemberModal(member = null) {
    const isEdit = !!member;
    const roles = [
      'Maid of Honor', 'Best Man', 'Bridesmaid', 'Groomsman', 
      'Flower Girl', 'Ring Bearer', 'Usher', 'Officiant', 'Other'
    ];

    window.Modal.show({
      title: isEdit ? 'Edit Member' : 'Add Wedding Party Member',
      content: `
        <form id="wedding-party-form">
          <div class="form-group">
            <label class="form-label">Name</label>
            <input type="text" class="form-input" id="member-name" required value="${isEdit ? window.Helpers.escapeHtml(member.name) : ''}">
          </div>
          <div class="form-group">
            <label class="form-label">Role</label>
            <select class="form-select" id="member-role">
              ${roles.map(r => `<option value="${r}" ${isEdit && member.role === r ? 'selected' : ''}>${r}</option>`).join('')}
            </select>
          </div>
          <div class="grid grid-2 gap-md">
            <div class="form-group">
              <label class="form-label">Email</label>
              <input type="email" class="form-input" id="member-email" value="${isEdit && member.email ? window.Helpers.escapeHtml(member.email) : ''}">
            </div>
            <div class="form-group">
              <label class="form-label">Phone</label>
              <input type="tel" class="form-input" id="member-phone" value="${isEdit && member.phone ? window.Helpers.escapeHtml(member.phone) : ''}">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Notes</label>
            <textarea class="form-textarea" id="member-notes" rows="2">${isEdit && member.notes ? window.Helpers.escapeHtml(member.notes) : ''}</textarea>
          </div>
        </form>
      `,
      onSubmit: async (modalEl) => {
        const data = {
          name: modalEl.querySelector('#member-name').value.trim(),
          role: modalEl.querySelector('#member-role').value,
          email: modalEl.querySelector('#member-email').value.trim(),
          phone: modalEl.querySelector('#member-phone').value.trim(),
          notes: modalEl.querySelector('#member-notes').value.trim()
        };

        if (!data.name) {
          window.Toast.error('Name is required');
          return false;
        }

        try {
          if (isEdit) {
            await window.API.put(`/api/wedding-party/${member.id}`, data);
            window.Toast.success('Member updated');
          } else {
            await window.API.post('/api/wedding-party', data);
            window.Toast.success('Member added');
          }
          await this.loadData();
          this.renderUI();
          this.bindEvents(); // re-bind events to new DOM
          return true;
        } catch (err) {
          window.Toast.error('Failed to save member');
          return false;
        }
      }
    });
  },

  deleteMember(id) {
    window.Modal.confirm({
      title: 'Remove Member',
      message: 'Are you sure you want to remove this person from the wedding party?',
      confirmText: 'Remove',
      confirmClass: 'btn-danger',
      onConfirm: async () => {
        try {
          await window.API.del(`/api/wedding-party/${id}`);
          window.Toast.success('Member removed');
          await this.loadData();
          this.renderUI();
          this.bindEvents();
        } catch (err) {
          window.Toast.error('Failed to remove member');
        }
      }
    });
  }
};
