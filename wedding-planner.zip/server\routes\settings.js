const express = require('express');
const router = express.Router();
const DataStore = require('../lib/dataStore');
const store = new DataStore('settings');
const twilioService = require('../services/twilio');
const sendgridService = require('../services/sendgrid');

router.get('/', async (req, res) => {
    try {
        let data = await store.load();
        if (Array.isArray(data)) data = {};
        res.json(data);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/', async (req, res) => {
    try {
        await store.save(req.body);
        
        // Dynamically update integration credentials
        if (req.body.twilioSid || req.body.twilioToken || req.body.twilioPhone) {
            twilioService.updateCredentials(req.body.twilioSid, req.body.twilioToken, req.body.twilioPhone);
        }
        if (req.body.sendgridKey || req.body.sendgridFrom) {
            sendgridService.updateCredentials(req.body.sendgridKey, req.body.sendgridFrom);
        }

        res.json(req.body);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
