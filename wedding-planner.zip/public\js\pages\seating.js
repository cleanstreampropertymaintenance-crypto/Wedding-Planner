const SeatingPage = {
  container: null,
  tables: [],
  guests: [],
  activeGuestId: null,
  draggedTableId: null,
  currentFloor: 'Main Floor',
  floorSize: '4000px',
  showAttendingOnly: false,

  async render(container) {
    this.container = container;
    this.container.innerHTML = `
      <div class="page-header mb-lg">
        <h2 class="text-lg">2D Seating Chart</h2>
        <p class="text-muted">Design your floor plan. Select a guest, then click a seat to place them.</p>
      </div>
      <div class="seating-layout" id="seating-layout">
        <div class="seating-sidebar">
          <div class="seating-sidebar-header">
            <h3>Guest List</h3>
            <p class="text-sm text-muted">Unassigned guests</p>
            <label class="flex flex-center gap-xs mt-sm text-sm" style="cursor: pointer;">
              <input type="checkbox" id="toggle-attending" class="form-checkbox"> Show Attending Only
            </label>
          </div>
          <div class="seating-guest-list" id="seating-guest-list"></div>
        </div>
        <div class="seating-canvas-wrapper">
          <div class="seating-toolbar flex flex-between" style="padding: 10px; background: rgba(0,0,0,0.2); border-bottom: 1px solid rgba(255,255,255,0.05);">
            <div class="flex gap-sm">
              <button class="btn btn-sm floor-tab active" data-floor="Main Floor">Main Floor</button>
              <button class="btn btn-sm floor-tab" data-floor="Second Floor">Second Floor</button>
              <button class="btn btn-sm floor-tab" data-floor="Patio">Patio</button>
            </div>
            <div class="flex gap-sm align-center">
              <select id="floor-size-select" class="form-input" style="width: auto; padding: 4px 8px; height: 32px; font-size: 13px;">
                <option value="100%">Fit Screen</option>
                <option value="2000px">Medium Floor</option>
                <option value="4000px">Large Floor</option>
                <option value="6000px">Massive Floor</option>
              </select>
              <button class="btn btn-sm btn-ghost" id="btn-fullscreen"><i data-lucide="maximize"></i> Full Screen</button>
              <button class="btn btn-sm btn-ghost" id="btn-export-pdf"><i data-lucide="download"></i> Export PDF</button>
              <button class="btn btn-sm btn-primary" id="btn-add-table"><i data-lucide="plus"></i> Add Table</button>
            </div>
          </div>
          <div class="seating-canvas" id="seating-canvas" style="background: white;"></div>
        </div>
      </div>
    `;

    this.bindEvents();
    await this.loadData();
  },

  async loadData() {
    try {
      const [households, legacyGuests, tables] = await Promise.all([
        window.API.get('/api/households'),
        window.API.get('/api/guests'),
        window.API.get('/api/seating')
      ]);
      
      this.households = households || [];
      const standaloneGuests = legacyGuests || [];
      this.tables = tables || [];
      
      // Unpack households into a flat list of individual guests
      this.guests = [];
      this.households.forEach(hh => {
        if (hh.members) {
          hh.members.forEach(m => {
            this.guests.push({
              id: m.id,
              firstName: m.firstName,
              lastName: m.lastName,
              householdId: hh.id,
              householdName: hh.householdName,
              isAttending: m.isAttending
            });
          });
        }
      });
      

      // Ensure all tables have assignments object
      this.tables.forEach(t => {
        if (!t.assignments) t.assignments = {};
      });

      this.renderUI();
    } catch (err) {
      window.Toast.error('Failed to load data');
    }
  },

  renderUI() {
    this.renderSidebar();
    this.renderCanvas();
    if (window.lucide) window.lucide.createIcons();
  },

  getAssignedGuestIds() {
    const assigned = new Set();
    this.tables.forEach(t => {
      Object.values(t.assignments).forEach(gid => assigned.add(gid));
    });
    return assigned;
  },

  renderSidebar() {
    const list = this.container.querySelector('#seating-guest-list');
    const assignedIds = this.getAssignedGuestIds();
    
    // Group unassigned guests by household
    let unassigned = this.guests.filter(g => !assignedIds.has(g.id));
    
    if (this.showAttendingOnly) {
      unassigned = unassigned.filter(g => g.isAttending !== false);
    }
    
    if (unassigned.length === 0) {
      list.innerHTML = `<p class="text-muted text-center mt-md">All guests assigned!</p>`;
      return;
    }

    // Sort by household name, then guest name
    unassigned.sort((a, b) => {
      const hhCmp = (a.householdName || '').localeCompare(b.householdName || '');
      if (hhCmp !== 0) return hhCmp;
      return a.firstName.localeCompare(b.firstName);
    });

    list.innerHTML = unassigned.map(g => `
      <div class="seating-guest-item ${this.activeGuestId === g.id ? 'selected' : ''}" data-id="${g.id}">
        <div class="flex flex-col">
          <span class="fw-bold">${window.Helpers.escapeHtml(g.firstName)} ${window.Helpers.escapeHtml(g.lastName || '')}</span>
          <span class="text-xs" style="opacity:0.7">${window.Helpers.escapeHtml(g.householdName || 'Unknown Household')}</span>
        </div>
      </div>
    `).join('');
  },

  renderCanvas() {
    const canvas = this.container.querySelector('#seating-canvas');
    canvas.style.width = this.floorSize;
    canvas.style.height = this.floorSize;
    const floorTables = this.tables.filter(t => (t.floor || 'Main Floor') === this.currentFloor);
    canvas.innerHTML = floorTables.map(table => this.generateTableHTML(table)).join('');
  },

  generateTableHTML(table) {
    const shape = table.shape || 'circle';
    const config = table.seatConfig || { total: 8 };
    
    let width = 100;
    let height = 100;
    let borderRadius = '0';
    let seatsHTML = '';

    if (shape === 'circle') {
      const total = config.total || 8;
      width = 60 + (total * 8);
      height = width;
      borderRadius = '50%';
      
      const radius = width / 2;
      for (let i = 0; i < total; i++) {
        const angle = (i / total) * (2 * Math.PI) - (Math.PI / 2);
        const sx = radius + (radius * Math.cos(angle));
        const sy = radius + (radius * Math.sin(angle));
        seatsHTML += this.generateSeatHTML(table.id, i, sx, sy);
      }
    } else if (shape === 'rectangle') {
      const xSeats = config.seatsX || 4;
      const ySeats = config.seatsY || 2;
      width = Math.max(100, 40 + (xSeats * 40));
      height = Math.max(80, 40 + (ySeats * 40));
      borderRadius = '8px';

      // Top edge
      for(let i = 0; i < xSeats; i++) {
        let sx = (width / (xSeats + 1)) * (i + 1);
        let sy = 0;
        seatsHTML += this.generateSeatHTML(table.id, `top_${i}`, sx, sy);
      }
      // Bottom edge
      for(let i = 0; i < xSeats; i++) {
        let sx = (width / (xSeats + 1)) * (i + 1);
        let sy = height;
        seatsHTML += this.generateSeatHTML(table.id, `bot_${i}`, sx, sy);
      }
      // Left edge
      for(let i = 0; i < ySeats; i++) {
        let sx = 0;
        let sy = (height / (ySeats + 1)) * (i + 1);
        seatsHTML += this.generateSeatHTML(table.id, `left_${i}`, sx, sy);
      }
      // Right edge
      for(let i = 0; i < ySeats; i++) {
        let sx = width;
        let sy = (height / (ySeats + 1)) * (i + 1);
        seatsHTML += this.generateSeatHTML(table.id, `right_${i}`, sx, sy);
      }
    } else if (shape === 'square') {
      const sides = config.seatsX || 2;
      width = Math.max(100, 40 + (sides * 40));
      height = width;
      borderRadius = '8px';
      
      ['top', 'bot', 'left', 'right'].forEach(side => {
        for(let i = 0; i < sides; i++) {
          let sx = 0, sy = 0;
          if (side === 'top') { sx = (width / (sides + 1)) * (i + 1); sy = 0; }
          if (side === 'bot') { sx = (width / (sides + 1)) * (i + 1); sy = height; }
          if (side === 'left') { sx = 0; sy = (height / (sides + 1)) * (i + 1); }
          if (side === 'right') { sx = width; sy = (height / (sides + 1)) * (i + 1); }
          seatsHTML += this.generateSeatHTML(table.id, `${side}_${i}`, sx, sy);
        }
      });
    }

    const x = table.x || 50;
    const y = table.y || 50;

    return `
      <div class="table-element" data-id="${table.id}" style="left: ${x}%; top: ${y}%; width: ${width}px; height: ${height}px;">
        <div class="table-shape" style="width: 100%; height: 100%; border-radius: ${borderRadius};">
          <span class="table-label">${window.Helpers.escapeHtml(table.name)}</span>
        </div>
        ${seatsHTML}
      </div>
    `;
  },

  generateSeatHTML(tableId, seatIdx, x, y) {
    const table = this.tables.find(t => t.id === tableId);
    const guestId = table.assignments[seatIdx];
    const guest = guestId ? this.guests.find(g => g.id === guestId) : null;
    const isOccupied = !!guest;
    
    return `
      <div class="seat-slot ${isOccupied ? 'occupied' : ''}" 
           data-table="${tableId}" 
           data-seat="${seatIdx}" 
           style="left: ${x}px; top: ${y}px;">
        <i data-lucide="user"></i>
        ${isOccupied ? `<div class="seat-tooltip">${window.Helpers.escapeHtml(guest.firstName)} ${window.Helpers.escapeHtml(guest.lastName)}</div>` : ''}
      </div>
    `;
  },

  bindEvents() {
    this.boundHandleClick = this.handleClick.bind(this);
    this.boundHandleMouseDown = this.handleMouseDown.bind(this);
    this.boundHandleDblClick = this.handleDblClick.bind(this);
    this.container.addEventListener('click', this.boundHandleClick);
    this.container.addEventListener('mousedown', this.boundHandleMouseDown);
    this.container.addEventListener('dblclick', this.boundHandleDblClick);
    
    const toggleAtt = this.container.querySelector('#toggle-attending');
    if (toggleAtt) {
      toggleAtt.addEventListener('change', (e) => {
        this.showAttendingOnly = e.target.checked;
        this.renderSidebar();
      });
    }

    const floorSizeSel = this.container.querySelector('#floor-size-select');
    if (floorSizeSel) {
      floorSizeSel.value = this.floorSize;
      floorSizeSel.addEventListener('change', (e) => {
        this.floorSize = e.target.value;
        this.renderCanvas();
      });
    }
  },

  handleDblClick(e) {
    const tableShape = e.target.closest('.table-shape');
    if (!tableShape) return;
    const tableId = tableShape.closest('.table-element').dataset.id;
    const table = this.tables.find(t => t.id === tableId);
    if (table) {
      this.showTableConfigModal(table);
    }
  },

  handleClick(e) {
    // Add Table
    if (e.target.closest('#btn-add-table')) {
      this.showTableConfigModal();
      return;
    }
    
    if (e.target.closest('#btn-fullscreen')) {
      const wrapper = this.container.querySelector('.seating-canvas-wrapper');
      if (!document.fullscreenElement) {
        wrapper.requestFullscreen().catch(err => {
          window.Toast.error('Could not enable full screen');
        });
      } else {
        document.exitFullscreen();
      }
      return;
    }
    
    if (e.target.closest('#btn-export-pdf')) {
      this.exportToPDF();
      return;
    }

    // Floor Tabs
    if (e.target.classList.contains('floor-tab')) {
      this.container.querySelectorAll('.floor-tab').forEach(btn => {
        btn.classList.remove('active');
        btn.style.background = 'transparent';
      });
      e.target.classList.add('active');
      e.target.style.background = 'var(--primary-color)';
      this.currentFloor = e.target.dataset.floor;
      this.renderCanvas();
      return;
    }

    // Select Guest from Sidebar
    const guestItem = e.target.closest('.seating-guest-item');
    if (guestItem) {
      const id = guestItem.dataset.id;
      this.activeGuestId = (this.activeGuestId === id) ? null : id; // toggle
      this.renderSidebar();
      return;
    }

    // Click a Seat
    const seatSlot = e.target.closest('.seat-slot');
    if (seatSlot) {
      this.handleSeatClick(seatSlot);
      return;
    }
  },

  async handleSeatClick(seatEl) {
    const tableId = seatEl.dataset.table;
    const seatIdx = seatEl.dataset.seat;
    const table = this.tables.find(t => t.id === tableId);
    if (!table) return;

    const currentGuestId = table.assignments[seatIdx];

    // If occupied, clicking unassigns them
    if (currentGuestId) {
      delete table.assignments[seatIdx];
      await this.saveTable(table);
      // Re-render
      this.renderUI();
      return;
    }

    // If empty and we have an active guest, assign them
    if (this.activeGuestId) {
      table.assignments[seatIdx] = this.activeGuestId;
      this.activeGuestId = null;
      await this.saveTable(table);
      this.renderUI();
    } else {
      window.Toast.info('Select a guest from the sidebar first, then click a seat.');
    }
  },

  handleMouseDown(e) {
    const tableShape = e.target.closest('.table-shape');
    if (!tableShape) return;
    
    const tableEl = tableShape.closest('.table-element');
    const tableId = tableEl.dataset.id;
    const canvas = this.container.querySelector('#seating-canvas');
    const rect = canvas.getBoundingClientRect();
    
    this.draggedTableId = tableId;

    const moveHandler = (moveEvent) => {
      if (!this.draggedTableId) return;
      
      // Calculate % position bounded to canvas
      let x = ((moveEvent.clientX - rect.left) / rect.width) * 100;
      let y = ((moveEvent.clientY - rect.top) / rect.height) * 100;
      
      x = Math.max(0, Math.min(100, x));
      y = Math.max(0, Math.min(100, y));

      tableEl.style.left = x + '%';
      tableEl.style.top = y + '%';
    };

    const upHandler = async (upEvent) => {
      document.removeEventListener('mousemove', moveHandler);
      document.removeEventListener('mouseup', upHandler);
      
      if (this.draggedTableId) {
        const table = this.tables.find(t => t.id === this.draggedTableId);
        if (table) {
          table.x = parseFloat(tableEl.style.left);
          table.y = parseFloat(tableEl.style.top);
          await this.saveTable(table);
        }
        this.draggedTableId = null;
      }
    };

    document.addEventListener('mousemove', moveHandler);
    document.addEventListener('mouseup', upHandler);
  },

  showTableConfigModal(table = null) {
    const isEdit = !!table;
    const shape = table ? table.shape : 'circle';
    const conf = table ? (table.seatConfig || {}) : {};

    window.Modal.show({
      title: isEdit ? 'Edit Table' : 'Add Table',
      content: `
        <form id="table-config-form">
          <div class="form-group mb-md">
            <label class="form-label">Table Name</label>
            <input type="text" class="form-input" id="cfg-name" required value="${isEdit ? window.Helpers.escapeHtml(table.name) : ''}">
          </div>
          <div class="form-group mb-md">
            <label class="form-label">Shape</label>
            <select class="form-input" id="cfg-shape">
              <option value="circle" ${shape==='circle'?'selected':''}>Circle</option>
              <option value="rectangle" ${shape==='rectangle'?'selected':''}>Rectangle</option>
              <option value="square" ${shape==='square'?'selected':''}>Square</option>
            </select>
          </div>
          
          <div id="cfg-circle" style="display: ${shape==='circle'?'block':'none'};">
            <div class="form-group mb-md">
              <label class="form-label">Total Seats</label>
              <input type="number" class="form-input" id="cfg-total" min="1" max="24" value="${conf.total || 8}">
            </div>
          </div>
          
          <div id="cfg-grid" style="display: ${shape!=='circle'?'block':'none'};">
            <div class="grid grid-2 gap-md mb-md">
              <div class="form-group">
                <label class="form-label">Seats (Width)</label>
                <input type="number" class="form-input" id="cfg-x" min="0" max="12" value="${conf.seatsX || 4}">
              </div>
              <div class="form-group">
                <label class="form-label">Seats (Length)</label>
                <input type="number" class="form-input" id="cfg-y" min="0" max="12" value="${conf.seatsY || 2}">
              </div>
            </div>
            <small class="text-muted">Enter the number of seats along each edge of the table.</small>
          </div>
          
          <div class="flex gap-sm" style="justify-content: space-between; margin-top: 1rem;">
            ${isEdit ? `<button type="button" class="btn btn-danger" id="cfg-delete">Delete Table</button>` : '<div></div>'}
            <button type="submit" class="btn btn-primary">Save Table</button>
          </div>
        </form>
      `,
      onShow: (modalEl) => {
        const sel = modalEl.querySelector('#cfg-shape');
        const cCirc = modalEl.querySelector('#cfg-circle');
        const cGrid = modalEl.querySelector('#cfg-grid');
        
        sel.addEventListener('change', (e) => {
          if (e.target.value === 'circle') {
            cCirc.style.display = 'block';
            cGrid.style.display = 'none';
          } else {
            cCirc.style.display = 'none';
            cGrid.style.display = 'block';
          }
        });

        if (isEdit) {
          modalEl.querySelector('#cfg-delete').addEventListener('click', () => {
            this.deleteTable(table.id);
            window.Modal.close();
          });
        }
      },
      onSubmit: async (modalEl) => {
        const name = modalEl.querySelector('#cfg-name').value.trim();
        const selShape = modalEl.querySelector('#cfg-shape').value;
        let seatConfig = {};

        if (selShape === 'circle') {
          seatConfig.total = parseInt(modalEl.querySelector('#cfg-total').value, 10) || 8;
        } else {
          seatConfig.seatsX = parseInt(modalEl.querySelector('#cfg-x').value, 10) || 0;
          seatConfig.seatsY = parseInt(modalEl.querySelector('#cfg-y').value, 10) || 0;
        }

        const data = {
          name,
          shape: selShape,
          seatConfig,
          floor: table ? (table.floor || 'Main Floor') : this.currentFloor,
          x: table ? table.x : 50,
          y: table ? table.y : 50,
          assignments: table ? table.assignments : {}
        };

        try {
          if (isEdit) {
            await window.API.put(`/api/seating/${table.id}`, data);
            window.Toast.success('Table updated');
          } else {
            await window.API.post('/api/seating', data);
            window.Toast.success('Table created');
          }
          await this.loadData();
          window.Modal.close();
        } catch (err) {
          window.Toast.error('Failed to save table');
        }
      }
    });
  },

  async deleteTable(id) {
    try {
      await window.API.del(`/api/seating/${id}`);
      window.Toast.success('Table deleted');
      await this.loadData();
    } catch (err) {
      window.Toast.error('Failed to delete table');
    }
  },

  async saveTable(table) {
    try {
      await window.API.put(`/api/seating/${table.id}`, table);
    } catch (err) {
      window.Toast.error('Network error saving table');
    }
  },

  async exportToPDF() {
    if (!window.html2pdf) {
      window.Toast.error('PDF library is loading or failed to load.');
      return;
    }
    
    const canvas = this.container.querySelector('#seating-canvas');
    canvas.classList.add('pdf-export-mode');
    
    // Temporarily shrink canvas to fit onto PDF cleanly
    const originalWidth = canvas.style.width;
    const originalHeight = canvas.style.height;
    canvas.style.width = '1200px';
    canvas.style.height = '800px';

    const opt = {
      margin:       0.5,
      filename:     `Seating_Chart_${this.currentFloor.replace(/\s+/g, '_')}.pdf`,
      image:        { type: 'jpeg', quality: 0.98 },
      html2canvas:  { scale: 2, useCORS: true, logging: false },
      jsPDF:        { unit: 'in', format: 'letter', orientation: 'landscape' }
    };

    try {
      window.Toast.success('Generating PDF...');
      // Allow browser to repaint before capturing
      await new Promise(r => setTimeout(r, 300));
      await window.html2pdf().set(opt).from(canvas).save();
    } catch (err) {
      window.Toast.error('Failed to export PDF');
    } finally {
      canvas.classList.remove('pdf-export-mode');
      canvas.style.width = originalWidth;
      canvas.style.height = originalHeight;
    }
  },

  cleanup() {
    if (this.container) {
      this.container.removeEventListener('click', this.boundHandleClick);
      this.container.removeEventListener('mousedown', this.boundHandleMouseDown);
      this.container.removeEventListener('dblclick', this.boundHandleDblClick);
    }
  }
};

window.SeatingPage = SeatingPage;
