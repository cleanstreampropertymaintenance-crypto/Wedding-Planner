/* Sidebar Navigation Component */
window.Sidebar = {
  init() {
    const sidebar = document.getElementById('sidebar');
    const toggle = document.getElementById('sidebar-toggle');

    toggle.addEventListener('click', () => {
      sidebar.classList.toggle('collapsed');
      localStorage.setItem('sidebar-collapsed', sidebar.classList.contains('collapsed'));
    });

    // Restore state
    if (localStorage.getItem('sidebar-collapsed') === 'true') {
      sidebar.classList.add('collapsed');
    }

    this.updateCountdown();
    setInterval(() => this.updateCountdown(), 60000);
  },

  setActive(page) {
    document.querySelectorAll('.nav-link').forEach(link => {
      link.classList.toggle('active', link.dataset.page === page);
    });
  },

  async updateCountdown() {
    try {
      const settings = await window.API.get('/api/settings');
      if (settings && settings.weddingDate) {
        const days = window.Helpers.daysUntil(settings.weddingDate);
        const el = document.getElementById('sidebar-countdown');
        if (el) el.textContent = days > 0 ? `${days} days to go ✨` : days === 0 ? 'Today! 🎉' : 'Married! 💍';
      }
      if (settings && settings.coupleNames) {
        const el = document.getElementById('couple-names');
        if (el) el.textContent = settings.coupleNames;
      }
    } catch (e) { /* settings not ready */ }
  }
};
