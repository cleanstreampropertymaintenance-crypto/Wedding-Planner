const Guests = {
  households: [],
  
  async render(container) {
    this.container = container;
    this.container.innerHTML = `
      <div class="page-header flex flex-between mb-lg">
        <div>
          <h2 class="text-lg">Guest List (Households)</h2>
          <p class="text-muted">Manage your contact cards and the guests inside them.</p>
        </div>
        <button class="btn btn-primary" id="add-hh-btn">
          <span class="btn-icon"><i data-lucide="plus"></i></span> Add Household
        </button>
      </div>
      
      <div class="grid grid-4 mb-lg" id="hh-stats">
        <!-- Stats injected here -->
      </div>
      
      <div class="grid grid-3 gap-lg" id="hh-grid">
        <!-- Households injected here -->
      </div>
    `;

    // Bind events
    this.handleAddClick = this.handleAddClick.bind(this);
    this.handleGridClick = this.handleGridClick.bind(this);
    
    this.container.querySelector('#add-hh-btn').addEventListener('click', this.handleAddClick);
    this.container.querySelector('#hh-grid').addEventListener('click', this.handleGridClick);

    await this.loadData();
  },

  async loadData() {
    try {
      this.households = await window.API.get('/api/households') || [];
      // Ensure all households have a members array
      this.households.forEach(hh => {
        if (!hh.members) hh.members = [];
      });
      this.renderStats();
      this.renderGrid();
    } catch (error) {
      window.Toast.error('Failed to load households.');
      console.error(error);
    }
  },

  renderStats() {
    const totalHH = this.households.length;
    let totalGuests = 0;
    let attending = 0;
    
    this.households.forEach(hh => {
      totalGuests += (hh.members ? hh.members.length : 0);
      if (hh.status === 'Attending') attending += (hh.members ? hh.members.length : 0);
    });

    const statsContainer = this.container.querySelector('#hh-stats');
    statsContainer.innerHTML = `
      <div class="stat-card card card-glass p-md text-center">
        <div class="stat-value">${totalHH}</div>
        <div class="stat-label text-muted">Total Households</div>
      </div>
      <div class="stat-card card card-glass p-md text-center">
        <div class="stat-value">${totalGuests}</div>
        <div class="stat-label text-muted">Total Sub-contacts</div>
      </div>
      <div class="stat-card card card-glass p-md text-center">
        <div class="stat-value text-success">${attending}</div>
        <div class="stat-label text-muted">Attending Guests</div>
      </div>
      <div class="stat-card card card-glass p-md text-center">
        <div class="stat-value text-warning">${totalGuests - attending}</div>
        <div class="stat-label text-muted">Pending / Declined</div>
      </div>
    `;
  },

  renderGrid() {
    const grid = this.container.querySelector('#hh-grid');
    if (this.households.length === 0) {
      grid.innerHTML = `<div class="empty-state" style="grid-column: 1 / -1;"><p class="text-muted text-center p-lg">No households created yet. Click "Add Household" to start.</p></div>`;
      return;
    }

    grid.innerHTML = this.households.map(hh => `
      <div class="card card-hover p-lg" style="border-top: 3px solid ${hh.side === 'Partner 1' ? 'var(--primary-color)' : (hh.side === 'Partner 2' ? 'var(--accent)' : 'var(--border-color)')};">
        <div class="flex flex-between mb-sm">
          <h3 class="fw-bold text-lg">${window.Helpers.escapeHtml(hh.householdName || 'Unnamed Family')}</h3>
          <div class="dropdown">
             <button class="btn btn-icon btn-sm action-btn edit-btn" data-id="${hh.id}"><i data-lucide="edit-2"></i></button>
             <button class="btn btn-icon btn-sm action-btn delete-btn text-danger" data-id="${hh.id}"><i data-lucide="trash-2"></i></button>
          </div>
        </div>
        
        <div class="text-sm text-muted mb-md flex flex-col gap-xs">
          ${hh.email ? `<div><i data-lucide="mail" style="width:12px;height:12px;margin-right:4px;"></i> ${window.Helpers.escapeHtml(hh.email)}</div>` : ''}
          ${hh.phone ? `<div><i data-lucide="phone" style="width:12px;height:12px;margin-right:4px;"></i> ${window.Helpers.escapeHtml(hh.phone)}</div>` : ''}
          ${hh.address ? `<div><i data-lucide="map-pin" style="width:12px;height:12px;margin-right:4px;"></i> ${window.Helpers.escapeHtml(hh.address)}</div>` : ''}
        </div>
        
        <div class="mb-md">
          ${this.getStatusBadge(hh.status)} <span class="badge badge-info">${window.Helpers.escapeHtml(hh.side || 'Mutual')}</span>
        </div>

        <div style="background: rgba(255,255,255,0.03); padding: 10px; border-radius: 8px;">
          <div class="text-xs fw-bold mb-xs text-muted uppercase tracking-wider">Sub-contacts (${hh.members ? hh.members.length : 0})</div>
          ${(hh.members && hh.members.length > 0) ? hh.members.map(m => `
            <div class="flex flex-between text-sm py-xs border-bottom-subtle">
              <span class="flex flex-center gap-xs">
                ${m.isAttending === false ? '<i data-lucide="x-circle" class="text-danger" style="width:14px;height:14px;"></i>' : '<i data-lucide="check-circle-2" class="text-success" style="width:14px;height:14px;"></i>'}
                ${window.Helpers.escapeHtml(m.firstName)} ${window.Helpers.escapeHtml(m.lastName || '')}
              </span>
              <span class="text-muted text-xs">${window.Helpers.escapeHtml(m.relation || '')}</span>
            </div>
          `).join('') : '<div class="text-xs text-muted">No members added yet</div>'}
        </div>
      </div>
    `).join('');
    
    if (window.lucide) window.lucide.createIcons();
  },

  getStatusBadge(status) {
    switch (status) {
      case 'Attending': return '<span class="badge badge-success">Attending</span>';
      case 'Declined': return '<span class="badge badge-danger">Declined</span>';
      default: return '<span class="badge badge-warning">Pending</span>';
    }
  },

  handleAddClick() {
    this.openModal();
  },

  handleGridClick(e) {
    const editBtn = e.target.closest('.edit-btn');
    const deleteBtn = e.target.closest('.delete-btn');
    
    if (editBtn) {
      const id = editBtn.dataset.id;
      const hh = this.households.find(h => h.id === id);
      if (hh) this.openModal(hh);
    } else if (deleteBtn) {
      const id = deleteBtn.dataset.id;
      this.deleteHousehold(id);
    }
  },

  openModal(hh = null) {
    const isEdit = !!hh;
    // We need a local state copy of the members to manage dynamic adding/removing
    let localMembers = hh && hh.members ? [...hh.members] : [];

    const renderMembersList = () => {
      const container = document.getElementById('modal-members-list');
      if (!container) return;
      container.innerHTML = localMembers.map((m, idx) => `
        <div class="flex gap-sm mb-sm flex-center">
          <input type="text" class="form-input" placeholder="First Name" value="${window.Helpers.escapeHtml(m.firstName)}" onchange="window.updateMember(${idx}, 'firstName', this.value)">
          <input type="text" class="form-input" placeholder="Last Name" value="${window.Helpers.escapeHtml(m.lastName || '')}" onchange="window.updateMember(${idx}, 'lastName', this.value)">
          <input type="text" class="form-input" placeholder="Relation" value="${window.Helpers.escapeHtml(m.relation || '')}" onchange="window.updateMember(${idx}, 'relation', this.value)">
          <select class="form-select" onchange="window.updateMember(${idx}, 'isAttending', this.value === 'true')" style="width: 110px;">
            <option value="true" ${m.isAttending !== false ? 'selected' : ''}>Attending</option>
            <option value="false" ${m.isAttending === false ? 'selected' : ''}>Declined</option>
          </select>
          <button type="button" class="btn btn-icon btn-sm btn-ghost text-danger" onclick="window.removeMember(${idx})"><i data-lucide="x"></i></button>
        </div>
      `).join('');
      if (window.lucide) window.lucide.createIcons();
    };

    window.updateMember = (idx, field, val) => {
      localMembers[idx][field] = val;
    };
    window.removeMember = (idx) => {
      localMembers.splice(idx, 1);
      renderMembersList();
    };
    window.addMember = () => {
      // Generate a stable ID for the sub-contact so they can be tracked in the seating chart
      localMembers.push({ id: 'guest_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5), firstName: '', lastName: '', relation: '', isAttending: true });
      renderMembersList();
    };
    
    const content = `
      <form id="hh-form" class="flex flex-col gap-md">
        <div class="form-group">
          <label class="form-label">Household / Contact Card Name *</label>
          <input type="text" name="householdName" class="form-input" required placeholder="e.g. The Smith Family" value="${hh ? window.Helpers.escapeHtml(hh.householdName) : ''}">
        </div>
        
        <div class="grid grid-2 gap-md">
          <div class="form-group">
            <label class="form-label">Main Email (For Blasts)</label>
            <input type="email" name="email" class="form-input" value="${hh ? window.Helpers.escapeHtml(hh.email || '') : ''}">
          </div>
          <div class="form-group">
            <label class="form-label">Main Phone (For Texts)</label>
            <input type="text" name="phone" class="form-input" value="${hh ? window.Helpers.escapeHtml(hh.phone || '') : ''}">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Physical Mailing Address</label>
          <input type="text" name="address" class="form-input" value="${hh ? window.Helpers.escapeHtml(hh.address || '') : ''}">
        </div>

        <div class="grid grid-2 gap-md">
          <div class="form-group">
            <label class="form-label">Side</label>
            <select name="side" class="form-select">
              <option value="Partner 1" ${hh && hh.side === 'Partner 1' ? 'selected' : ''}>Partner 1</option>
              <option value="Partner 2" ${hh && hh.side === 'Partner 2' ? 'selected' : ''}>Partner 2</option>
              <option value="Mutual" ${hh && hh.side === 'Mutual' ? 'selected' : ''}>Mutual</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">RSVP Status</label>
            <select name="status" class="form-select">
              <option value="Pending" ${hh && hh.status === 'Pending' ? 'selected' : ''}>Pending</option>
              <option value="Attending" ${hh && hh.status === 'Attending' ? 'selected' : ''}>Attending</option>
              <option value="Declined" ${hh && hh.status === 'Declined' ? 'selected' : ''}>Declined</option>
            </select>
          </div>
        </div>
        
        <hr class="my-md" style="border-color: rgba(255,255,255,0.1)">
        
        <div>
          <div class="flex flex-between mb-sm">
            <label class="form-label mb-0">Sub-contacts (Guests)</label>
            <button type="button" class="btn btn-sm btn-ghost" onclick="window.addMember()">+ Add Person</button>
          </div>
          <div id="modal-members-list" style="background: rgba(0,0,0,0.2); padding: 10px; border-radius: 8px; min-height: 50px;"></div>
        </div>

        <div class="flex gap-sm mt-md" style="justify-content: flex-end;">
          <button type="button" class="btn btn-ghost" onclick="window.Modal.close()">Cancel</button>
          <button type="submit" class="btn btn-primary">${isEdit ? 'Save Household' : 'Create Household'}</button>
        </div>
      </form>
    `;

    window.Modal.show({
      title: isEdit ? 'Edit Contact Card' : 'New Contact Card',
      content: content,
      size: 'large'
    });

    renderMembersList();

    const form = document.getElementById('hh-form');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(form);
      const data = Object.fromEntries(formData.entries());
      data.members = localMembers.filter(m => m.firstName.trim() !== ''); // Clean empty ones

      try {
        if (isEdit) {
          await window.API.put(`/api/households/${hh.id}`, data);
          window.Toast.success('Household updated!');
        } else {
          await window.API.post('/api/households', data);
          window.Toast.success('Household added!');
        }
        window.Modal.close();
        await this.loadData();
      } catch (err) {
        window.Toast.error('Failed to save household.');
        console.error(err);
      }
    });
  },

  deleteHousehold(id) {
    window.Modal.confirm({
      title: 'Delete Household',
      message: 'Are you sure you want to remove this contact card? All sub-contacts inside it will be lost. This action cannot be undone.',
      confirmText: 'Delete',
      confirmClass: 'btn-danger',
      onConfirm: async () => {
        try {
          await window.API.del(`/api/households/${id}`);
          window.Toast.success('Household deleted.');
          await this.loadData();
        } catch (err) {
          window.Toast.error('Failed to delete household.');
          console.error(err);
        }
      }
    });
  },

  cleanup() {
    const addBtn = this.container.querySelector('#add-hh-btn');
    const grid = this.container.querySelector('#hh-grid');
    if (addBtn) addBtn.removeEventListener('click', this.handleAddClick);
    if (grid) grid.removeEventListener('click', this.handleGridClick);
    delete window.updateMember;
    delete window.removeMember;
    delete window.addMember;
  }
};

window.GuestsPage = Guests;
