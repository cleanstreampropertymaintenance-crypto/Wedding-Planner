const fs = require('fs');
const path = require('path');
const dir = path.join(__dirname, '..', 'public', 'js', 'pages');

const mapping = {
  '✏': '<i data-lucide="edit-2"></i>',
  '🗑': '<i data-lucide="trash-2"></i>',
  '➕': '<i data-lucide="plus"></i>',
  '👤': '<i data-lucide="user"></i>',
  '💰': '<i data-lucide="circle-dollar-sign"></i>',
  '💌': '<i data-lucide="mail"></i>',
  '🪑': '<i data-lucide="chair"></i>', // Actually lucide doesn't have chair, maybe users-round or armchair
  '📋': '<i data-lucide="clipboard-list"></i>',
  '⏰': '<i data-lucide="clock"></i>',
  '📍': '<i data-lucide="map-pin"></i>',
  '🏪': '<i data-lucide="store"></i>',
  '📧': '<i data-lucide="mail"></i>',
  '📞': '<i data-lucide="phone"></i>',
  '💍': '<i data-lucide="gem"></i>',
  '✉': '<i data-lucide="mail"></i>',
  '📱': '<i data-lucide="smartphone"></i>',
  '📂': '<i data-lucide="folder"></i>',
  '✅': '<i data-lucide="check-circle-2"></i>'
};

let files = fs.readdirSync(dir);
for (let file of files) {
  if (file.endsWith('.js')) {
    let p = path.join(dir, file);
    let content = fs.readFileSync(p, 'utf8');
    let newContent = content;
    
    // special case for chair
    newContent = newContent.replace(/🪑/g, '<i data-lucide="armchair"></i>');
    
    for (let [emoji, icon] of Object.entries(mapping)) {
      if (emoji !== '🪑') {
        const re = new RegExp(emoji, 'g');
        newContent = newContent.replace(re, icon);
      }
    }
    
    if (content !== newContent) {
      fs.writeFileSync(p, newContent);
      console.log('Replaced emojis in ' + file);
    }
  }
}
