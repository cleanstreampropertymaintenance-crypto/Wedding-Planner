const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');

// Simple file upload handler using multer if available, or just a dummy endpoint
let upload;
try {
    const multer = require('multer');
    const uploadDir = path.join(__dirname, '../../public/uploads');
    if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
    }

    const storage = multer.diskStorage({
        destination: function (req, file, cb) {
            cb(null, uploadDir)
        },
        filename: function (req, file, cb) {
            const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
            cb(null, uniqueSuffix + path.extname(file.originalname))
        }
    });
    upload = multer({ storage: storage });
} catch (e) {
    // Fallback if multer isn't installed
    console.warn('multer not installed, file uploads will not work properly');
}

if (upload) {
    router.post('/', upload.single('file'), (req, res) => {
        if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
        res.json({ url: '/uploads/' + req.file.filename });
    });
} else {
    router.post('/', (req, res) => {
        res.status(501).json({ error: 'File upload not supported (multer missing)' });
    });
}

module.exports = router;
