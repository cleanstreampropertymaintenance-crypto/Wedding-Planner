const twilio = require('twilio');
const DataStore = require('../lib/dataStore');

class TwilioService {
  constructor() {
    this.client = null;
    this.fromNumber = null;
    this.init();
  }

  async init() {
    const store = new DataStore('settings');
    let settings = (await store.load().catch(()=>null)) || {};
    if (Array.isArray(settings)) settings = {};
    this.accountSid = settings.twilioSid || process.env.TWILIO_ACCOUNT_SID;
    this.authToken = settings.twilioToken || process.env.TWILIO_AUTH_TOKEN;
    this.fromNumber = settings.twilioPhone || process.env.TWILIO_FROM_NUMBER;
    
    if (this.accountSid && this.authToken) {
      try {
        this.client = twilio(this.accountSid, this.authToken);
        console.log('Twilio initialized successfully.');
      } catch (err) {
        console.warn('Twilio failed to initialize. SMS will be mocked.', err);
        this.client = null;
      }
    } else {
      console.warn('Twilio credentials not found. SMS will be mocked.');
      this.client = null;
    }
  }

  updateCredentials(sid, token, fromPhone) {
    this.accountSid = sid;
    this.authToken = token;
    this.fromNumber = fromPhone;
    if (sid && token) {
      try {
        this.client = twilio(sid, token);
        console.log('Twilio re-initialized with new credentials.');
      } catch (err) {
        console.warn('Twilio failed to re-initialize.', err);
        this.client = null;
      }
    } else {
      this.client = null;
    }
  }

  async sendSMS(to, body) {
    if (!this.client) {
      console.log(`[MOCK SMS] To: ${to} | Body: ${body}`);
      return { success: true, mock: true, messageId: `mock_${Date.now()}` };
    }

    try {
      const message = await this.client.messages.create({
        body,
        from: this.fromNumber,
        to
      });
      return { success: true, messageId: message.sid };
    } catch (error) {
      console.error('Twilio Error:', error);
      throw error;
    }
  }
}

module.exports = new TwilioService();
