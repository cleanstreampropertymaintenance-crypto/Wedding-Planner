const RegistryPage = {
  async render(container) {
    container.innerHTML = `
      <div class="flex flex-between mb-lg">
        <h2>Gift Registry</h2>
        <button class="btn btn-primary" id="btn-add-gift"><i data-lucide="plus"></i> Add Gift</button>
      </div>
      <div class="card card-glass mb-lg">
        <div class="table-responsive">
          <table class="table table-hover">
            <thead>
              <tr>
                <th>Item Name</th>
                <th>Price</th>
                <th>Store / Link</th>
                <th>Status</th>
                <th class="text-right">Actions</th>
              </tr>
            </thead>
            <tbody id="registry-list">
              <tr><td colspan="5" class="text-center">Loading...</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    `;

    this.container = container;
    this.boundHandleClick = this.handleClick.bind(this);
    container.addEventListener('click', this.boundHandleClick);
    
    await this.loadData();
  },

  async loadData() {
    try {
      this.gifts = await window.API.get('/api/registry') || [];
      this.renderList();
    } catch (err) {
      window.Toast.error('Failed to load registry items');
    }
  },

  renderList() {
    const list = this.container.querySelector('#registry-list');
    
    if (this.gifts.length === 0) {
      list.innerHTML = `<tr><td colspan="5" class="text-center text-muted">No gifts added to the registry yet.</td></tr>`;
      return;
    }

    list.innerHTML = this.gifts.map(gift => `
      <tr data-id="${gift.id}" class="${gift.purchased ? 'text-muted' : ''}">
        <td><strong>${window.Helpers.escapeHtml(gift.name)}</strong></td>
        <td>${gift.price ? window.Helpers.formatCurrency(gift.price) : 'N/A'}</td>
        <td>
          ${gift.url ? `<a href="${window.Helpers.escapeHtml(gift.url)}" target="_blank" class="btn btn-sm btn-ghost"><i data-lucide="external-link"></i> Link</a>` : 'N/A'}
        </td>
        <td>
          <span class="badge ${gift.purchased ? 'badge-success' : 'badge-warning'}" style="cursor: pointer;" class="toggle-status">
            ${gift.purchased ? 'Purchased' : 'Available'}
          </span>
        </td>
        <td class="text-right">
          <button class="btn btn-sm btn-ghost edit-gift"><i data-lucide="edit-2"></i></button>
          <button class="btn btn-sm btn-ghost text-danger delete-gift"><i data-lucide="trash-2"></i></button>
        </td>
      </tr>
    `).join('');
  },

  handleClick(e) {
    if (e.target.closest('#btn-add-gift')) {
      this.showGiftForm();
    } else if (e.target.closest('.delete-gift')) {
      const id = e.target.closest('tr').dataset.id;
      this.deleteGift(id);
    } else if (e.target.closest('.edit-gift')) {
      const id = e.target.closest('tr').dataset.id;
      const gift = this.gifts.find(g => g.id === id);
      if (gift) this.showGiftForm(gift);
    } else if (e.target.closest('.badge')) {
      const id = e.target.closest('tr').dataset.id;
      const gift = this.gifts.find(g => g.id === id);
      if (gift) this.toggleStatus(gift);
    }
  },

  async toggleStatus(gift) {
    try {
      await window.API.put('/api/registry/' + gift.id, { ...gift, purchased: !gift.purchased });
      await this.loadData();
    } catch (err) {
      window.Toast.error('Failed to update status');
    }
  },

  showGiftForm(gift = null) {
    const isEdit = !!gift;
    window.Modal.show({
      title: isEdit ? 'Edit Gift' : 'Add Gift',
      content: `
        <form id="gift-form">
          <div class="form-group mb-md">
            <label class="form-label">Item Name</label>
            <input type="text" class="form-input" id="gift-name" required value="${gift ? window.Helpers.escapeHtml(gift.name) : ''}">
          </div>
          <div class="form-group mb-md">
            <label class="form-label">Price</label>
            <input type="number" step="0.01" class="form-input" id="gift-price" value="${gift && gift.price ? gift.price : ''}">
          </div>
          <div class="form-group mb-md">
            <label class="form-label">URL / Link</label>
            <input type="url" class="form-input" id="gift-url" value="${gift && gift.url ? window.Helpers.escapeHtml(gift.url) : ''}">
          </div>
          <div class="form-group mb-md">
            <label class="form-label">
              <input type="checkbox" id="gift-purchased" class="form-checkbox" ${gift && gift.purchased ? 'checked' : ''}>
              Mark as Purchased
            </label>
          </div>
          <div class="flex gap-sm" style="justify-content: flex-end;">
            <button type="submit" class="btn btn-primary">${isEdit ? 'Save Changes' : 'Add Gift'}</button>
          </div>
        </form>
      `,
      onSubmit: async (modalEl) => {
        const name = modalEl.querySelector('#gift-name').value.trim();
        const price = parseFloat(modalEl.querySelector('#gift-price').value) || null;
        const url = modalEl.querySelector('#gift-url').value.trim();
        const purchased = modalEl.querySelector('#gift-purchased').checked;
        
        if (!name) {
          window.Toast.warning('Please provide an item name');
          return false;
        }

        const data = { name, price, url, purchased };

        try {
          if (isEdit) {
            await window.API.put('/api/registry/' + gift.id, data);
            window.Toast.success('Gift updated!');
          } else {
            await window.API.post('/api/registry', data);
            window.Toast.success('Gift added!');
          }
          await this.loadData();
          window.Modal.close();
        } catch (err) {
          window.Toast.error('Failed to save gift');
        }
      }
    });
  },

  deleteGift(id) {
    window.Modal.confirm({
      title: 'Delete Gift?',
      message: 'Are you sure you want to remove this item from the registry?',
      confirmText: 'Delete',
      confirmClass: 'btn-danger',
      onConfirm: async () => {
        try {
          await window.API.del('/api/registry/' + id);
          window.Toast.success('Gift deleted');
          await this.loadData();
        } catch (err) {
          window.Toast.error('Failed to delete gift');
        }
      }
    });
  },

  cleanup() {
    if (this.container) {
      this.container.removeEventListener('click', this.boundHandleClick);
    }
  }
};

window.RegistryPage = RegistryPage;
