const express = require('express');
const router = express.Router();
const DataStore = require('../lib/dataStore');
const rsvpStore = new DataStore('rsvp_config');
const householdStore = new DataStore('households');

// Get RSVP form config
router.get('/config', async (req, res) => {
  try {
    const config = await rsvpStore.getById('main');
    if (!config) {
      // Return defaults if none exists
      return res.json({
        id: 'main',
        blocks: [
          { id: 'attendance', type: 'attendance', label: 'Who is attending?' },
          { id: 'dietary', type: 'text', label: 'Any dietary restrictions?' },
          { id: 'song', type: 'text', label: 'Song requests for the DJ?' },
          { id: 'plus_one', type: 'plus_one', label: 'Are you bringing a Plus One?' }
        ]
      });
    }
    res.json(config);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch RSVP config' });
  }
});

// Update RSVP form config
router.put('/config', async (req, res) => {
  try {
    const { blocks, styles, deadline } = req.body;
    let config = await rsvpStore.getById('main');
    if (!config) {
      config = await rsvpStore.create({ id: 'main', blocks, styles, deadline });
    } else {
      config = await rsvpStore.update('main', { blocks, styles, deadline });
    }
    res.json(config);
  } catch (error) {
    res.status(500).json({ error: 'Failed to save RSVP config' });
  }
});

// Get data for a specific household to fill out the form
router.get('/public/:householdId', async (req, res) => {
  try {
    let hh;
    if (req.params.householdId === 'preview') {
      hh = {
        id: 'preview',
        householdName: 'Sample Guest',
        members: [
          { id: 'm1', firstName: 'Jane', lastName: 'Doe', isAttending: true },
          { id: 'm2', firstName: 'John', lastName: 'Doe', isAttending: null }
        ],
        address: '123 Fake Street',
        email: 'sample@example.com',
        rsvpResponses: {}
      };
    } else {
      hh = await householdStore.getById(req.params.householdId);
      if (!hh) return res.status(404).json({ error: 'Household not found' });
    }
    
    const config = await rsvpStore.getById('main');
    
    res.json({
      household: hh,
      config: config || { blocks: [
        { id: 'attendance', type: 'attendance', label: 'Who is attending?' },
        { id: 'dietary', type: 'text', label: 'Any dietary restrictions?' }
      ]}
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch public RSVP data' });
  }
});

// Submit RSVP form
router.post('/public/:householdId', async (req, res) => {
  try {
    const hh = await householdStore.getById(req.params.householdId);
    if (!hh) return res.status(404).json({ error: 'Household not found' });
    
    const { members, plusOnes, responses, address, email } = req.body;
    
    // Update contact info if provided
    if (address && address.trim() !== '') hh.address = address.trim();
    if (email && email.trim() !== '') hh.email = email.trim();
    
    // Update existing members' attendance
    if (members && hh.members) {
      hh.members.forEach(m => {
        const submittedMember = members.find(sm => sm.id === m.id);
        if (submittedMember) {
          m.isAttending = submittedMember.isAttending;
        }
      });
    }
    
    // Add any plus ones
    if (plusOnes && plusOnes.length > 0) {
      if (!hh.members) hh.members = [];
      plusOnes.forEach(po => {
        if (po.firstName && po.firstName.trim() !== '') {
          hh.members.push({
            id: 'guest_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
            firstName: po.firstName,
            lastName: po.lastName || '',
            relation: po.relation || 'Plus One',
            isAttending: true
          });
        }
      });
    }
    
    // Determine overall household status
    const attendingCount = hh.members ? hh.members.filter(m => m.isAttending !== false).length : 0;
    if (attendingCount > 0) {
      hh.status = 'Attending';
    } else {
      hh.status = 'Declined';
    }
    
    // Save arbitrary answers to the household
    hh.rsvpResponses = responses || {};
    
    await householdStore.update(hh.id, hh);
    
    res.json({ success: true, household: hh });
  } catch (error) {
    res.status(500).json({ error: 'Failed to submit RSVP' });
  }
});

module.exports = router;
