/* Drag and Drop Utilities */
window.DragDrop = {
  makeSortable(container, { itemSelector, onReorder, handle }) {
    let dragged = null;
    let placeholder = null;

    container.addEventListener('dragstart', (e) => {
      const item = e.target.closest(itemSelector);
      if (!item) return;
      if (handle && !e.target.closest(handle)) { e.preventDefault(); return; }
      dragged = item;
      item.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
      setTimeout(() => item.style.opacity = '0.4', 0);
    });

    container.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      const item = e.target.closest(itemSelector);
      if (!item || item === dragged) return;
      const rect = item.getBoundingClientRect();
      const mid = rect.top + rect.height / 2;
      if (e.clientY < mid) {
        container.insertBefore(dragged, item);
      } else {
        container.insertBefore(dragged, item.nextSibling);
      }
    });

    container.addEventListener('dragend', (e) => {
      if (dragged) {
        dragged.classList.remove('dragging');
        dragged.style.opacity = '1';
        const items = [...container.querySelectorAll(itemSelector)];
        const order = items.map(el => el.dataset.id);
        if (onReorder) onReorder(order);
        dragged = null;
      }
    });

    // Make items draggable
    container.querySelectorAll(itemSelector).forEach(item => {
      item.setAttribute('draggable', 'true');
    });
  },

  makeDroppable(element, { onDrop, accepts }) {
    element.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      element.classList.add('drag-over');
    });

    element.addEventListener('dragleave', (e) => {
      if (!element.contains(e.relatedTarget)) {
        element.classList.remove('drag-over');
      }
    });

    element.addEventListener('drop', (e) => {
      e.preventDefault();
      element.classList.remove('drag-over');
      const data = e.dataTransfer.getData('text/plain');
      try {
        const parsed = JSON.parse(data);
        if (onDrop) onDrop(parsed, element, e);
      } catch {
        if (onDrop) onDrop(data, element, e);
      }
    });
  },

  makeDraggable(element, data) {
    element.setAttribute('draggable', 'true');
    element.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('text/plain', typeof data === 'object' ? JSON.stringify(data) : data);
      e.dataTransfer.effectAllowed = 'move';
      element.classList.add('dragging');
    });
    element.addEventListener('dragend', () => {
      element.classList.remove('dragging');
    });
  }
};
