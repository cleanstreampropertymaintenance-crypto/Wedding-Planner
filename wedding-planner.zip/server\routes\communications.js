const express = require('express');
const router = express.Router();
const DataStore = require('../lib/dataStore');
const store = new DataStore('communications');
const scheduler = require('../services/scheduler');

// Get all communications
router.get('/', async (req, res) => {
  try {
    const comms = await store.getAll();
    res.json(comms);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch communications' });
  }
});

// Get single communication
router.get('/:id', async (req, res) => {
  try {
    const comm = await store.getById(req.params.id);
    if (!comm) return res.status(404).json({ error: 'Communication not found' });
    res.json(comm);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch communication' });
  }
});

// Schedule a new communication
router.post('/', async (req, res) => {
  try {
    const { type, to, subject, body, scheduledFor } = req.body;
    
    if (!type || !to || !body) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const job = await store.create({
      type,
      to,
      subject,
      body,
      status: 'pending',
      scheduledFor: scheduledFor || new Date().toISOString(),
      recipients: req.body.recipients || null
    });

    scheduler.scheduleJob(job);
    res.status(201).json(job);
  } catch (error) {
    res.status(500).json({ error: 'Failed to schedule communication' });
  }
});

// Update a scheduled communication
router.put('/:id', async (req, res) => {
  try {
    const existing = await store.getById(req.params.id);
    if (!existing) return res.status(404).json({ error: 'Communication not found' });
    
    // Allow updating status to 'cancelled' or similar
    const updated = await store.update(req.params.id, req.body);
    
    if (updated.status === 'cancelled') {
      await scheduler.cancelJob(req.params.id);
    } else if (updated.status === 'pending') {
      scheduler.scheduleJob(updated);
    }
    
    res.json(updated);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update communication' });
  }
});

// Delete/cancel a communication
router.delete('/:id', async (req, res) => {
  try {
    const existing = await store.getById(req.params.id);
    if (!existing) return res.status(404).json({ error: 'Communication not found' });
    
    await scheduler.cancelJob(req.params.id);
    await store.delete(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete communication' });
  }
});

module.exports = router;
