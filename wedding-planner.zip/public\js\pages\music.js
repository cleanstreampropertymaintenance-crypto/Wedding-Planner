const MusicPage = {
  async render(container) {
    container.innerHTML = `
      <div class="flex flex-between mb-lg">
        <h2>Music & Playlists</h2>
        <button class="btn btn-primary" id="btn-add-song"><i data-lucide="plus"></i> Add Song</button>
      </div>
      <div class="card card-glass mb-lg">
        <div class="tabs mb-md">
          <button class="tab-btn active" data-tab="must-play">Must Play</button>
          <button class="tab-btn" data-tab="do-not-play">Do Not Play</button>
          <button class="tab-btn" data-tab="general">General Playlist</button>
        </div>
        <div class="table-responsive">
          <table class="table table-hover">
            <thead>
              <tr>
                <th>Song Title</th>
                <th>Artist</th>
                <th>Category</th>
                <th class="text-right">Actions</th>
              </tr>
            </thead>
            <tbody id="music-list">
              <tr><td colspan="4" class="text-center">Loading...</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    `;

    this.container = container;
    this.currentTab = 'must-play';
    this.boundHandleClick = this.handleClick.bind(this);
    container.addEventListener('click', this.boundHandleClick);
    
    await this.loadData();
  },

  async loadData() {
    try {
      this.songs = await window.API.get('/api/music') || [];
      this.renderList();
    } catch (err) {
      window.Toast.error('Failed to load music');
    }
  },

  renderList() {
    const list = this.container.querySelector('#music-list');
    const filteredSongs = this.songs.filter(s => s.category === this.currentTab);
    
    if (filteredSongs.length === 0) {
      list.innerHTML = `<tr><td colspan="4" class="text-center text-muted">No songs in this category yet.</td></tr>`;
      return;
    }

    list.innerHTML = filteredSongs.map(song => `
      <tr data-id="${song.id}">
        <td><strong>${window.Helpers.escapeHtml(song.title)}</strong></td>
        <td>${window.Helpers.escapeHtml(song.artist)}</td>
        <td><span class="badge badge-primary">${song.category}</span></td>
        <td class="text-right">
          <button class="btn btn-sm btn-ghost edit-song"><i data-lucide="edit-2"></i></button>
          <button class="btn btn-sm btn-ghost text-danger delete-song"><i data-lucide="trash-2"></i></button>
        </td>
      </tr>
    `).join('');
  },

  handleClick(e) {
    if (e.target.closest('#btn-add-song')) {
      this.showSongForm();
    } else if (e.target.closest('.tab-btn')) {
      const tabBtn = e.target.closest('.tab-btn');
      this.container.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
      tabBtn.classList.add('active');
      this.currentTab = tabBtn.dataset.tab;
      this.renderList();
    } else if (e.target.closest('.delete-song')) {
      const id = e.target.closest('tr').dataset.id;
      this.deleteSong(id);
    } else if (e.target.closest('.edit-song')) {
      const id = e.target.closest('tr').dataset.id;
      const song = this.songs.find(s => s.id === id);
      if (song) this.showSongForm(song);
    }
  },

  showSongForm(song = null) {
    const isEdit = !!song;
    window.Modal.show({
      title: isEdit ? 'Edit Song' : 'Add Song',
      content: `
        <form id="song-form">
          <div class="form-group mb-md">
            <label class="form-label">Song Title</label>
            <input type="text" class="form-input" id="song-title" required value="${song ? window.Helpers.escapeHtml(song.title) : ''}">
          </div>
          <div class="form-group mb-md">
            <label class="form-label">Artist</label>
            <input type="text" class="form-input" id="song-artist" required value="${song ? window.Helpers.escapeHtml(song.artist) : ''}">
          </div>
          <div class="form-group mb-md">
            <label class="form-label">Category</label>
            <select class="form-select" id="song-category">
              <option value="must-play" ${song?.category === 'must-play' ? 'selected' : ''}>Must Play</option>
              <option value="do-not-play" ${song?.category === 'do-not-play' ? 'selected' : ''}>Do Not Play</option>
              <option value="general" ${song?.category === 'general' ? 'selected' : ''}>General Playlist</option>
            </select>
          </div>
          <div class="flex gap-sm" style="justify-content: flex-end;">
            <button type="submit" class="btn btn-primary">${isEdit ? 'Save Changes' : 'Add Song'}</button>
          </div>
        </form>
      `,
      onSubmit: async (modalEl) => {
        const title = modalEl.querySelector('#song-title').value.trim();
        const artist = modalEl.querySelector('#song-artist').value.trim();
        const category = modalEl.querySelector('#song-category').value;
        
        if (!title || !artist) {
          window.Toast.warning('Please fill in all fields');
          return false;
        }

        const data = { title, artist, category };

        try {
          if (isEdit) {
            await window.API.put('/api/music/' + song.id, data);
            window.Toast.success('Song updated!');
          } else {
            await window.API.post('/api/music', data);
            window.Toast.success('Song added!');
          }
          await this.loadData();
          window.Modal.close();
        } catch (err) {
          window.Toast.error('Failed to save song');
        }
      }
    });
  },

  deleteSong(id) {
    window.Modal.confirm({
      title: 'Delete Song?',
      message: 'Are you sure you want to remove this song from the list?',
      confirmText: 'Delete',
      confirmClass: 'btn-danger',
      onConfirm: async () => {
        try {
          await window.API.del('/api/music/' + id);
          window.Toast.success('Song deleted');
          await this.loadData();
        } catch (err) {
          window.Toast.error('Failed to delete song');
        }
      }
    });
  },

  cleanup() {
    if (this.container) {
      this.container.removeEventListener('click', this.boundHandleClick);
    }
  }
};

window.MusicPage = MusicPage;
