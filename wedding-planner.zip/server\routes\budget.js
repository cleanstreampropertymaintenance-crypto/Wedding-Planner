const express = require('express');
const router = express.Router();
const DataStore = require('../lib/dataStore');
const store = new DataStore('budget');

router.get('/', async (req, res, next) => {
  try {
    const items = await store.getAll();
    res.json(items);
  } catch (err) {
    next(err);
  }
});

router.post('/', async (req, res, next) => {
  try {
    const item = await store.create(req.body);
    res.status(201).json(item);
  } catch (err) {
    next(err);
  }
});

router.put('/:id', async (req, res, next) => {
  try {
    const item = await store.update(req.params.id, req.body);
    if (!item) return res.status(404).json({ error: 'Item not found' });
    res.json(item);
  } catch (err) {
    next(err);
  }
});

router.delete('/:id', async (req, res, next) => {
  try {
    const success = await store.delete(req.params.id);
    if (!success) return res.status(404).json({ error: 'Item not found' });
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
