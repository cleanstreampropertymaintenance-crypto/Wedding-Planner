const GuestChecklist = {
  households: [],

  async render(container) {
    this.container = container;
    this.container.innerHTML = `
      <div class="page-header mb-lg">
        <h2 class="text-lg">Guest Checklist</h2>
        <p class="text-muted">Track your progress on guest-related tasks (managed by Household).</p>
      </div>
      
      <div class="grid grid-2 gap-lg" id="checklist-container">
        <!-- Checklist items injected here -->
      </div>
    `;

    // Event delegation
    this.handleActionClick = this.handleActionClick.bind(this);
    this.container.querySelector('#checklist-container').addEventListener('click', this.handleActionClick);

    await this.loadData();
  },

  async loadData() {
    try {
      this.households = await window.API.get('/api/households') || [];
      this.renderChecklist();
    } catch (error) {
      window.Toast.error('Failed to load households data.');
      console.error(error);
    }
  },

  renderChecklist() {
    const container = this.container.querySelector('#checklist-container');
    const total = this.households.length;

    // Derived stats
    const withEmail = this.households.filter(h => h.email && h.email.trim() !== '').length;
    const saveTheDateSent = this.households.filter(h => h.saveTheDateSent).length;
    const inviteSent = this.households.filter(h => h.inviteSent).length;
    const responded = this.households.filter(h => h.status === 'Attending' || h.status === 'Declined').length;

    // Helper for progress ring or bar
    const getPercent = (count, max) => max === 0 ? 0 : Math.round((count / max) * 100);

    const checklistItems = [
      {
        id: 'add-guests',
        title: 'Build Guest List',
        desc: 'Add all your potential households.',
        count: total,
        max: total > 0 ? total : 100, // arbitrary goal if 0
        actionText: 'Manage Guests',
        actionHash: '#guests',
        color: 'var(--primary-color)'
      },
      {
        id: 'collect-emails',
        title: 'Collect Email Addresses',
        desc: 'Ensure every household has a main contact email.',
        count: withEmail,
        max: total,
        actionText: 'Missing Emails',
        actionId: 'view-missing-emails',
        color: '#f59e0b' // warning color
      },
      {
        id: 'save-the-dates',
        title: 'Send Save-the-Dates',
        desc: 'Mark which households have received a save-the-date.',
        count: saveTheDateSent,
        max: total,
        actionText: 'Manage Save-the-Dates',
        actionId: 'manage-std',
        color: '#3b82f6' // info color
      },
      {
        id: 'invitations',
        title: 'Send Invitations',
        desc: 'Send out formal wedding invitations.',
        count: inviteSent,
        max: total,
        actionText: 'Manage Invitations',
        actionId: 'manage-invites',
        color: '#8b5cf6' // purple
      },
      {
        id: 'rsvps',
        title: 'Track RSVPs',
        desc: 'Collect Attending/Declined responses.',
        count: responded,
        max: total,
        actionText: 'Update RSVPs',
        actionHash: '#guests',
        color: 'var(--success-color)'
      }
    ];

    container.innerHTML = checklistItems.map(item => {
      const pct = getPercent(item.count, item.max);
      const isComplete = pct === 100 && item.max > 0;
      
      return `
        <div class="card card-glass p-lg flex gap-md">
          <div class="progress-ring-container" style="width: 80px; height: 80px; flex-shrink: 0; position: relative;">
            <svg viewBox="0 0 36 36" style="width: 100%; height: 100%;">
              <path
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="#e5e7eb"
                stroke-width="3"
              />
              <path
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="${item.color}"
                stroke-width="3"
                stroke-dasharray="${pct}, 100"
                style="transition: stroke-dasharray 0.5s ease;"
              />
            </svg>
            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-weight: bold; font-size: 0.9em;">
              ${pct}%
            </div>
          </div>
          
          <div class="flex-grow flex flex-col flex-between">
            <div>
              <h3 class="mb-xs flex flex-center gap-sm">
                ${item.title}
                ${isComplete ? '<span class="text-success text-sm"><i data-lucide="check-circle-2"></i> Done</span>' : ''}
              </h3>
              <p class="text-muted text-sm">${item.desc}</p>
              <div class="text-sm fw-bold mt-sm">${item.count} / ${item.max}</div>
            </div>
            
            <div class="mt-md">
              ${item.actionHash ? 
                `<a href="${item.actionHash}" class="btn btn-sm btn-ghost" style="border: 1px solid var(--border-color)">${item.actionText}</a>` :
                `<button class="btn btn-sm btn-ghost action-btn" data-action="${item.actionId}" style="border: 1px solid var(--border-color)">${item.actionText}</button>`
              }
            </div>
          </div>
        </div>
      `;
    }).join('');
  },

  handleActionClick(e) {
    const btn = e.target.closest('.action-btn');
    if (!btn) return;

    const action = btn.dataset.action;
    
    if (action === 'view-missing-emails') {
      this.showMissingEmailsModal();
    } else if (action === 'manage-std') {
      this.showBatchUpdateModal('saveTheDateSent', 'Save-the-Dates');
    } else if (action === 'manage-invites') {
      this.showBatchUpdateModal('inviteSent', 'Invitations');
    }
  },

  showMissingEmailsModal() {
    const missing = this.households.filter(h => !h.email || h.email.trim() === '');
    
    const content = `
      <div style="max-height: 400px; overflow-y: auto;" class="p-sm">
        ${missing.length === 0 ? '<p class="text-success">All households have email addresses!</p>' : ''}
        ${missing.map(h => `
          <div class="card p-sm mb-sm flex flex-between">
            <div>${window.Helpers.escapeHtml(h.householdName || 'Unnamed Family')}</div>
            <button class="btn btn-sm btn-primary update-email-btn" data-id="${h.id}">Add Email</button>
          </div>
        `).join('')}
      </div>
    `;

    window.Modal.show({
      title: 'Missing Email Addresses',
      content: content,
      size: 'medium'
    });

    // Handle inline email updates
    const modalBody = document.getElementById('modal-body');
    modalBody.addEventListener('click', (e) => {
      if (e.target.classList.contains('update-email-btn')) {
        const id = e.target.dataset.id;
        const hh = this.households.find(h => h.id === id);
        this.promptForEmail(hh);
      }
    });
  },

  promptForEmail(hh) {
    const email = prompt(`Enter email for ${hh.householdName || 'Household'}:`);
    if (email !== null) {
      this.updateHousehold(hh.id, { email: email.trim() }).then(() => {
        window.Modal.close(); // refresh
        this.showMissingEmailsModal(); // reopen to see updated list
      });
    }
  },

  showBatchUpdateModal(field, label) {
    // Show a list of all households with checkboxes to mark the field as true/false
    const content = `
      <div style="max-height: 400px; overflow-y: auto;" class="p-sm">
        <table class="table table-striped w-100">
          <thead>
            <tr>
              <th>Household Name</th>
              <th class="text-center">${label} Sent?</th>
            </tr>
          </thead>
          <tbody>
            ${this.households.map(h => `
              <tr>
                <td>${window.Helpers.escapeHtml(h.householdName || 'Unnamed Family')}</td>
                <td class="text-center">
                  <input type="checkbox" class="form-checkbox batch-checkbox" data-id="${h.id}" ${h[field] ? 'checked' : ''}>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
      <div class="flex gap-sm mt-md" style="justify-content: flex-end;">
        <button class="btn btn-ghost" onclick="window.Modal.close()">Close</button>
      </div>
    `;

    window.Modal.show({
      title: `Manage ${label}`,
      content: content,
      size: 'medium'
    });

    const checkboxes = document.querySelectorAll('.batch-checkbox');
    checkboxes.forEach(cb => {
      cb.addEventListener('change', async (e) => {
        const id = e.target.dataset.id;
        const val = e.target.checked;
        await this.updateHousehold(id, { [field]: val });
      });
    });
  },

  async updateHousehold(id, data) {
    try {
      await window.API.put(`/api/households/${id}`, data);
      window.Toast.success('Updated successfully.');
      // Update local state without full reload for speed
      const idx = this.households.findIndex(h => h.id === id);
      if (idx !== -1) {
        this.households[idx] = { ...this.households[idx], ...data };
      }
      this.renderChecklist();
    } catch (err) {
      window.Toast.error('Failed to update.');
      console.error(err);
    }
  },

  cleanup() {
    const container = this.container.querySelector('#checklist-container');
    if (container) container.removeEventListener('click', this.handleActionClick);
  }
};

window.GuestChecklistPage = GuestChecklist;
