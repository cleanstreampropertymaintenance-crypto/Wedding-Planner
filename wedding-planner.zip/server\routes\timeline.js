const express = require('express');
const router = express.Router();
const DataStore = require('../lib/dataStore');
const store = new DataStore('timeline');

router.get('/', async (req, res) => {
  try {
    const items = await store.getAll();
    // Sort by time
    items.sort((a, b) => {
      if (!a.time) return 1;
      if (!b.time) return -1;
      return a.time.localeCompare(b.time);
    });
    res.json(items);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch timeline events' });
  }
});

router.post('/', async (req, res) => {
  try {
    const newItem = await store.create(req.body);
    res.status(201).json(newItem);
  } catch (err) {
    res.status(500).json({ error: 'Failed to create timeline event' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const updated = await store.update(req.params.id, req.body);
    if (!updated) return res.status(404).json({ error: 'Event not found' });
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: 'Failed to update event' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const success = await store.delete(req.params.id);
    if (!success) return res.status(404).json({ error: 'Event not found' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete event' });
  }
});

module.exports = router;
