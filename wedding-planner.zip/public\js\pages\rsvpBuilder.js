const RsvpBuilder = {
  config: { blocks: [] },

  async render(container) {
    this.container = container;
    this.container.innerHTML = `
      <div class="page-header flex flex-between mb-lg">
        <div>
          <h2 class="text-lg">RSVP Form Builder</h2>
          <p class="text-muted">Design the public RSVP form your guests will see.</p>
        </div>
        <div class="flex gap-sm">
          <button class="btn btn-ghost" id="preview-rsvp-btn">
            <i data-lucide="eye"></i> Preview Form
          </button>
          <button class="btn btn-primary" id="save-rsvp-btn">
            <i data-lucide="save"></i> Save Form
          </button>
        </div>
      </div>

      <div class="grid grid-3 gap-lg">
        <div class="card card-glass p-lg" style="grid-column: span 1;">
          <h3 class="mb-md">Form Styling</h3>
          <div class="flex flex-col gap-sm mb-lg pb-md" style="border-bottom: 1px solid rgba(255,255,255,0.1);">
            <div class="form-group">
              <label class="form-label text-xs">Background Color</label>
              <input type="color" id="style-bg" class="form-input" style="padding: 2px; height: 36px;" value="#ffffff">
            </div>
            <div class="form-group">
              <label class="form-label text-xs">Text Color</label>
              <input type="color" id="style-text" class="form-input" style="padding: 2px; height: 36px;" value="#000000">
            </div>
            <div class="form-group">
              <label class="form-label text-xs">Input Box Color</label>
              <input type="color" id="style-input" class="form-input" style="padding: 2px; height: 36px;" value="#f3f4f6">
            </div>
            <div class="form-group">
              <label class="form-label text-xs">Font Family</label>
              <select id="style-font" class="form-select">
                <option value="'Inter', sans-serif">Inter (Modern)</option>
                <option value="'Cormorant Garamond', serif">Cormorant Garamond (Elegant)</option>
                <option value="'Playfair Display', serif">Playfair Display (Classic)</option>
                <option value="'Montserrat', sans-serif">Montserrat (Clean)</option>
              </select>
            </div>
            <div class="form-group mt-sm">
              <label class="form-label text-xs fw-bold text-danger">RSVP Deadline Date</label>
              <input type="date" id="rsvp-deadline" class="form-input" style="padding: 4px;">
            </div>
            <div class="form-group">
              <label class="form-label text-xs">Background Image (optional)</label>
              <div class="flex gap-xs">
                <input type="text" id="style-bg-image" class="form-input flex-grow" placeholder="https://..." style="padding: 4px;">
                <label class="btn btn-sm btn-ghost" style="cursor: pointer; padding: 4px;" title="Upload Image">
                  <i data-lucide="upload"></i>
                  <input type="file" style="display:none" accept="image/*" onchange="window.RsvpBuilderPage.uploadImage(this, 'style-bg-image')">
                </label>
              </div>
            </div>
          </div>

          <h3 class="mb-md">Available Blocks</h3>
          <p class="text-sm text-muted mb-md">Click a block to add it to your form.</p>
          
          <div class="flex flex-col gap-sm" id="available-blocks">
            <button class="btn btn-ghost text-left flex gap-sm" data-type="attendance">
              <i data-lucide="users"></i> Attendance (Auto-updates household)
            </button>
            <button class="btn btn-ghost text-left flex gap-sm" data-type="plus_one">
              <i data-lucide="user-plus"></i> Plus One (Adds new sub-contact)
            </button>
            <button class="btn btn-ghost text-left flex gap-sm" data-type="address">
              <i data-lucide="map-pin"></i> Address (Updates household)
            </button>
            <button class="btn btn-ghost text-left flex gap-sm" data-type="email">
              <i data-lucide="mail"></i> Email Address (Updates household)
            </button>
            <button class="btn btn-ghost text-left flex gap-sm" data-type="text">
              <i data-lucide="type"></i> Text Answer (Dietary, Songs, etc)
            </button>
            <button class="btn btn-ghost text-left flex gap-sm" data-type="radio">
              <i data-lucide="check-circle"></i> Multiple Choice
            </button>
            <button class="btn btn-ghost text-left flex gap-sm" data-type="header">
              <i data-lucide="heading"></i> Header Text
            </button>
            <button class="btn btn-ghost text-left flex gap-sm" data-type="paragraph">
              <i data-lucide="align-left"></i> Description / Paragraph
            </button>
            <button class="btn btn-ghost text-left flex gap-sm" data-type="image">
              <i data-lucide="image"></i> Image
            </button>
          </div>
        </div>

        <div class="card p-lg" style="grid-column: span 2; min-height: 400px; background: rgba(0,0,0,0.2);">
          <h3 class="mb-md">Your Form (Drag to reorder)</h3>
          <div id="form-canvas" class="flex flex-col gap-sm" style="min-height: 200px;">
            <!-- Blocks injected here -->
          </div>
        </div>
      </div>
    `;

    this.bindEvents();
    await this.loadData();
  },

  async loadData() {
    try {
      this.config = await window.API.get('/api/rsvp/config') || { blocks: [], styles: {} };
      if (!this.config.styles) {
        this.config.styles = {
          bgColor: 'var(--surface-color)',
          textColor: 'var(--text-primary)',
          inputColor: 'rgba(0,0,0,0.05)',
          font: "'Inter', sans-serif"
        };
      }
      
      this.container.querySelector('#style-bg').value = this.config.styles.bgColor || '#ffffff';
      this.container.querySelector('#style-text').value = this.config.styles.textColor || '#000000';
      this.container.querySelector('#style-input').value = this.config.styles.inputColor || '#f3f4f6';
      this.container.querySelector('#style-font').value = this.config.styles.font || "'Inter', sans-serif";
      this.container.querySelector('#style-bg-image').value = this.config.styles.bgImage || '';
      this.container.querySelector('#rsvp-deadline').value = this.config.deadline || '';
      
      this.renderCanvas();
    } catch (err) {
      window.Toast.error('Failed to load RSVP config');
    }
  },

  renderCanvas() {
    const canvas = this.container.querySelector('#form-canvas');
    if (this.config.blocks.length === 0) {
      canvas.innerHTML = '<div class="text-center text-muted p-lg">Form is empty. Add blocks from the left.</div>';
      return;
    }

    canvas.innerHTML = this.config.blocks.map((b, idx) => `
      <div class="card p-md rsvp-block flex flex-between" draggable="true" data-index="${idx}" style="cursor: grab; border: 1px solid rgba(255,255,255,0.1);">
        <div class="flex-grow">
          <div class="flex gap-sm mb-xs">
            <i data-lucide="grip-vertical" class="text-muted" style="cursor: grab;"></i>
            <span class="badge badge-info uppercase" style="font-size: 10px;">${b.type}</span>
          </div>
          ${b.type === 'paragraph' ? `
            <textarea class="form-input mt-sm" placeholder="Enter paragraph text..." onchange="window.updateRsvpBlock(${idx}, 'label', this.value)" rows="3">${window.Helpers.escapeHtml(b.label || '')}</textarea>
          ` : b.type === 'image' ? `
            <div class="flex gap-xs mt-sm">
              <input type="text" class="form-input flex-grow" value="${window.Helpers.escapeHtml(b.label || '')}" placeholder="Image URL" onchange="window.updateRsvpBlock(${idx}, 'label', this.value)">
              <label class="btn btn-sm btn-ghost" style="cursor: pointer; padding: 4px;" title="Upload Image">
                <i data-lucide="upload"></i>
                <input type="file" style="display:none" accept="image/*" onchange="window.RsvpBuilderPage.uploadBlockImage(this, ${idx})">
              </label>
            </div>
          ` : `
            <input type="text" class="form-input mt-sm" value="${window.Helpers.escapeHtml(b.label || '')}" placeholder="${b.type === 'header' ? 'Header Text' : 'Question Label'}" onchange="window.updateRsvpBlock(${idx}, 'label', this.value)">
          `}
          
          ${b.type === 'radio' ? `
            <input type="text" class="form-input mt-xs" style="font-size: 12px;" value="${window.Helpers.escapeHtml(b.options ? b.options.join(', ') : '')}" placeholder="Options (comma separated)" onchange="window.updateRsvpBlock(${idx}, 'options', this.value.split(','))">
          ` : ''}
        </div>
        <button class="btn btn-icon btn-sm btn-ghost text-danger ml-md" onclick="window.removeRsvpBlock(${idx})"><i data-lucide="trash-2"></i></button>
      </div>
    `).join('');
    
    if (window.lucide) window.lucide.createIcons();
    this.initDragAndDrop();
  },

  bindEvents() {
    window.updateRsvpBlock = (idx, field, val) => {
      if (field === 'options') {
        this.config.blocks[idx][field] = val.map(v => v.trim());
      } else {
        this.config.blocks[idx][field] = val;
      }
    };
    
    window.removeRsvpBlock = (idx) => {
      this.config.blocks.splice(idx, 1);
      this.renderCanvas();
    };

    this.container.querySelector('#available-blocks').addEventListener('click', (e) => {
      const btn = e.target.closest('button');
      if (!btn) return;
      const type = btn.dataset.type;
      
      let label = 'New Question';
      if (type === 'attendance') label = 'Who is attending?';
      else if (type === 'plus_one') label = 'Are you bringing a Plus One?';
      else if (type === 'address') label = 'Mailing Address';
      else if (type === 'email') label = 'Email Address';
      else if (type === 'header') label = 'Section Header';
      else if (type === 'paragraph') label = 'Add some descriptive text here...';
      else if (type === 'image') label = 'https://...';
      
      this.config.blocks.push({
        id: 'block_' + Date.now(),
        type: type,
        label: label
      });
      this.renderCanvas();
    });

    this.container.querySelector('#preview-rsvp-btn').addEventListener('click', async () => {
      // Open the window synchronously to bypass browser popup blockers
      const popup = window.open('about:blank', '_blank');
      try {
        await this._saveForm(false); // pass false to avoid showing toast
        popup.location.href = '/#/rsvp?id=preview';
      } catch(err) {
        popup.close();
        window.Toast.error('Failed to save before preview');
      }
    });

    this.container.querySelector('#save-rsvp-btn').addEventListener('click', async () => {
      await this._saveForm(true);
    });
  },

  async _saveForm(showToast = true) {
    // Gather styles
    this.config.styles = {
      bgColor: this.container.querySelector('#style-bg').value,
      textColor: this.container.querySelector('#style-text').value,
      inputColor: this.container.querySelector('#style-input').value,
      font: this.container.querySelector('#style-font').value,
      bgImage: this.container.querySelector('#style-bg-image').value
    };
    this.config.deadline = this.container.querySelector('#rsvp-deadline').value;

    try {
      await window.API.put('/api/rsvp/config', this.config);
      if (showToast) window.Toast.success('RSVP Form saved successfully!');
    } catch (err) {
      if (showToast) window.Toast.error('Failed to save RSVP form');
      throw err;
    }
  },

  initDragAndDrop() {
    const canvas = this.container.querySelector('#form-canvas');
    let draggedIdx = null;

    canvas.querySelectorAll('.rsvp-block').forEach(block => {
      block.addEventListener('dragstart', (e) => {
        draggedIdx = parseInt(block.dataset.index);
        e.dataTransfer.effectAllowed = 'move';
        block.style.opacity = '0.5';
      });

      block.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        block.style.borderTop = '2px solid var(--primary-color)';
      });

      block.addEventListener('dragleave', () => {
        block.style.borderTop = '1px solid rgba(255,255,255,0.1)';
      });

      block.addEventListener('drop', (e) => {
        e.preventDefault();
        block.style.borderTop = '1px solid rgba(255,255,255,0.1)';
        const targetIdx = parseInt(block.dataset.index);
        
        if (draggedIdx !== null && draggedIdx !== targetIdx) {
          const item = this.config.blocks.splice(draggedIdx, 1)[0];
          this.config.blocks.splice(targetIdx, 0, item);
          this.renderCanvas();
        }
      });

      block.addEventListener('dragend', () => {
        block.style.opacity = '1';
        draggedIdx = null;
        canvas.querySelectorAll('.rsvp-block').forEach(b => b.style.borderTop = '1px solid rgba(255,255,255,0.1)');
      });
    });
  },

  async uploadImage(inputEl, targetId) {
    if (!inputEl.files || !inputEl.files[0]) return;
    const file = inputEl.files[0];
    const formData = new FormData();
    formData.append('file', file);
    try {
      window.Toast.success('Uploading image...');
      const res = await fetch('/api/uploads', { method: 'POST', body: formData });
      const data = await res.json();
      if (data.url) {
        document.getElementById(targetId).value = data.url;
        window.Toast.success('Upload complete!');
      } else {
        throw new Error(data.error || 'Upload failed');
      }
    } catch (err) {
      window.Toast.error(err.message);
    }
  },

  async uploadBlockImage(inputEl, idx) {
    if (!inputEl.files || !inputEl.files[0]) return;
    const file = inputEl.files[0];
    const formData = new FormData();
    formData.append('file', file);
    try {
      window.Toast.success('Uploading image...');
      const res = await fetch('/api/uploads', { method: 'POST', body: formData });
      const data = await res.json();
      if (data.url) {
        window.updateRsvpBlock(idx, 'label', data.url);
        window.Toast.success('Upload complete!');
        this.renderCanvas(); // Show updated URL and rebind everything
      } else {
        throw new Error(data.error || 'Upload failed');
      }
    } catch (err) {
      window.Toast.error(err.message);
    }
  },

  cleanup() {
    delete window.updateRsvpBlock;
    delete window.removeRsvpBlock;
  }
};

window.RsvpBuilderPage = RsvpBuilder;
