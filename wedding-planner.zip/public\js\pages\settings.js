const SettingsPage = {
  async render(container) {
    const themes = window.ThemeEngine.getThemes();
    const fonts = window.ThemeEngine.getFonts();
    
    const themeOptions = themes.map(t => `<option value="${t.id}">${t.name}</option>`).join('');
    const displayFontOptions = fonts.display.map(f => `<option value="${f.replace(/"/g, '&quot;')}">${f.split(',')[0].replace(/['"]/g, '')}</option>`).join('');
    const bodyFontOptions = fonts.body.map(f => `<option value="${f.replace(/"/g, '&quot;')}">${f.split(',')[0].replace(/['"]/g, '')}</option>`).join('');

    container.innerHTML = `
      <div class="flex flex-between mb-lg">
        <h2>App Settings & Design</h2>
      </div>
      
      <div class="grid" style="grid-template-columns: 1fr 1fr; gap: 2rem;">
        <!-- General Settings -->
        <div class="card card-glass">
          <h3 class="mb-md">Wedding Details</h3>
          <form id="settings-details-form">
            <div class="form-group mb-md">
              <label class="form-label">Couple's Names</label>
              <input type="text" class="form-input" id="setting-names" placeholder="e.g. Alex & Sam" required>
            </div>
            <div class="form-group mb-md">
              <label class="form-label">Wedding Date</label>
              <input type="date" class="form-input" id="setting-date" required>
            </div>
            <div class="form-group mb-md">
              <label class="form-label">Venue Name</label>
              <input type="text" class="form-input" id="setting-venue-name" placeholder="e.g. The Grand Hotel">
            </div>
            <div class="form-group mb-md">
              <label class="form-label">Total Budget Estimate ($)</label>
              <input type="number" class="form-input" id="setting-budget" placeholder="e.g. 25000">
            </div>
          </form>
        </div>

        <!-- Design & Appearance Settings -->
        <div class="card card-glass">
          <h3 class="mb-md">Design & Appearance</h3>
          <form id="settings-design-form">
            <div class="form-group mb-md">
              <label class="form-label">Color Theme</label>
              <select class="form-input" id="setting-theme">
                ${themeOptions}
              </select>
            </div>
            <div class="form-group mb-md">
              <label class="form-label">Background Image URL</label>
              <input type="url" class="form-input" id="setting-bg" placeholder="e.g. https://images.unsplash.com/photo-...">
              <small class="text-muted mt-sm" style="display:block">Leave blank for solid color. Use a high-res image link.</small>
            </div>
            <div class="form-group mb-md">
              <label class="form-label">Background Darkness (Overlay)</label>
              <input type="range" class="form-input" id="setting-bg-opacity" min="0" max="1" step="0.05" value="0.85">
            </div>
            <div class="form-group mb-md">
              <label class="form-label">Heading Font</label>
              <select class="form-input" id="setting-font-display">
                ${displayFontOptions}
              </select>
            </div>
            <div class="form-group mb-md">
              <label class="form-label">Body Text Font</label>
              <select class="form-input" id="setting-font-body">
                ${bodyFontOptions}
              </select>
            </div>
          </form>
        </div>
        <!-- API Integrations Settings -->
        <div class="card card-glass" style="grid-column: 1 / -1;">
          <h3 class="mb-md">API Integrations</h3>
          <p class="text-sm text-muted mb-md">Enter your Twilio and SendGrid credentials to enable blast messaging and emails. These keys are stored securely.</p>
          <form id="settings-integrations-form">
            <div class="grid grid-2 gap-lg">
              <div>
                <div class="form-group mb-md">
                  <label class="form-label">Twilio Account SID</label>
                  <input type="password" class="form-input" id="setting-twilio-sid" placeholder="AC...">
                </div>
                <div class="form-group mb-md">
                  <label class="form-label">Twilio Auth Token</label>
                  <input type="password" class="form-input" id="setting-twilio-token" placeholder="••••••••••••••••">
                </div>
                <div class="form-group mb-md">
                  <label class="form-label">Twilio Phone Number</label>
                  <input type="text" class="form-input" id="setting-twilio-phone" placeholder="+1234567890">
                </div>
              </div>
              <div>
                <div class="form-group mb-md">
                  <label class="form-label">SendGrid API Key (Optional)</label>
                  <input type="password" class="form-input" id="setting-sendgrid-key" placeholder="SG...">
                </div>
                <div class="form-group mb-md">
                  <label class="form-label">SendGrid Verified Sender Email</label>
                  <input type="email" class="form-input" id="setting-sendgrid-from" placeholder="you@yourdomain.com">
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    `;

    this.container = container;
    
    this.detailsForm = container.querySelector('#settings-details-form');
    this.designForm = container.querySelector('#settings-design-form');
    this.integrationsForm = container.querySelector('#settings-integrations-form');
    
    // Live auto-save handler
    const saveAll = async () => {
      try {
        const current = await window.API.get('/api/settings') || {};
        
        // details
        current.names = this.container.querySelector('#setting-names').value;
        current.date = this.container.querySelector('#setting-date').value;
        current.venueName = this.container.querySelector('#setting-venue-name').value;
        current.budget = parseFloat(this.container.querySelector('#setting-budget').value) || null;
        
        // design
        const theme = this.container.querySelector('#setting-theme').value;
        const bg = this.container.querySelector('#setting-bg').value;
        const opacity = this.container.querySelector('#setting-bg-opacity').value;
        const fontDisplay = this.container.querySelector('#setting-font-display').value;
        const fontBody = this.container.querySelector('#setting-font-body').value;

        current.theme = theme;
        current.backgroundImage = bg;
        current.backgroundOpacity = opacity;
        current.fontDisplay = fontDisplay;
        current.fontBody = fontBody;

        // integrations
        current.twilioSid = this.container.querySelector('#setting-twilio-sid').value;
        current.twilioToken = this.container.querySelector('#setting-twilio-token').value;
        current.twilioPhone = this.container.querySelector('#setting-twilio-phone').value;
        current.sendgridKey = this.container.querySelector('#setting-sendgrid-key').value;
        current.sendgridFrom = this.container.querySelector('#setting-sendgrid-from').value;

        await window.API.post('/api/settings', current);
        
        // Live updates
        window.Sidebar.updateCountdown();
        window.ThemeEngine.apply(theme, null, false);
        window.ThemeEngine.setBackground(bg, opacity);
        window.ThemeEngine.setFont('display', fontDisplay);
        window.ThemeEngine.setFont('body', fontBody);
      } catch (err) {
        console.error('Auto-save failed:', err);
      }
    };

    let debounceTimer;
    this.container.querySelectorAll('.form-input').forEach(input => {
      input.addEventListener('input', (e) => {
        // Immediate visual updates for design
        if (e.target.id === 'setting-bg' || e.target.id === 'setting-bg-opacity') {
          const bg = this.container.querySelector('#setting-bg').value;
          const op = this.container.querySelector('#setting-bg-opacity').value;
          window.ThemeEngine.setBackground(bg, op);
        } else if (e.target.id === 'setting-theme') {
          window.ThemeEngine.apply(e.target.value, null, false);
        } else if (e.target.id === 'setting-font-display') {
          window.ThemeEngine.setFont('display', e.target.value);
        } else if (e.target.id === 'setting-font-body') {
          window.ThemeEngine.setFont('body', e.target.value);
        }

        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(saveAll, 800);
      });
    });
    
    this.container.querySelectorAll('form').forEach(f => f.addEventListener('submit', e => e.preventDefault()));
    
    await this.loadData();
  },

  async loadData() {
    try {
      this.settings = await window.API.get('/api/settings') || {};
      
      // Load details
      if (this.settings.names) this.container.querySelector('#setting-names').value = this.settings.names;
      if (this.settings.date) this.container.querySelector('#setting-date').value = this.settings.date;
      if (this.settings.venueName) this.container.querySelector('#setting-venue-name').value = this.settings.venueName;
      if (this.settings.budget) this.container.querySelector('#setting-budget').value = this.settings.budget;
      
      // Load design
      if (this.settings.theme) this.container.querySelector('#setting-theme').value = this.settings.theme;
      if (this.settings.backgroundImage) this.container.querySelector('#setting-bg').value = this.settings.backgroundImage;
      if (this.settings.backgroundOpacity != null) this.container.querySelector('#setting-bg-opacity').value = this.settings.backgroundOpacity;
      if (this.settings.fontDisplay) this.container.querySelector('#setting-font-display').value = this.settings.fontDisplay;
      if (this.settings.fontBody) this.container.querySelector('#setting-font-body').value = this.settings.fontBody;

      // Load integrations
      if (this.settings.twilioSid) this.container.querySelector('#setting-twilio-sid').value = this.settings.twilioSid;
      if (this.settings.twilioToken) this.container.querySelector('#setting-twilio-token').value = this.settings.twilioToken;
      if (this.settings.twilioPhone) this.container.querySelector('#setting-twilio-phone').value = this.settings.twilioPhone;
      if (this.settings.sendgridKey) this.container.querySelector('#setting-sendgrid-key').value = this.settings.sendgridKey;
      if (this.settings.sendgridFrom) this.container.querySelector('#setting-sendgrid-from').value = this.settings.sendgridFrom;
      
    } catch (err) {
      window.Toast.error('Failed to load settings');
    }
  },

  cleanup() {
    // Event listeners are automatically removed when DOM nodes are replaced
  }
};

window.SettingsPage = SettingsPage;
