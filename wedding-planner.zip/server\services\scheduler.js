const DataStore = require('../lib/dataStore');
const twilio = require('./twilio');
const sendgrid = require('./sendgrid');

const store = new DataStore('communications');

class SchedulerService {
  constructor() {
    this.timers = {};
  }

  async loadPendingJobs() {
    try {
      const comms = await store.getAll();
      const pending = comms.filter(c => c.status === 'pending');
      
      pending.forEach(job => {
        this.scheduleJob(job);
      });
      console.log(`Scheduler loaded ${pending.length} pending jobs.`);
    } catch (err) {
      console.error('Failed to load pending jobs:', err);
    }
  }

  scheduleJob(job) {
    if (this.timers[job.id]) {
      clearTimeout(this.timers[job.id]);
    }

    const now = Date.now();
    const scheduledTime = new Date(job.scheduledFor).getTime();
    const delay = scheduledTime - now;

    if (delay <= 0) {
      // Execute immediately
      this.executeJob(job.id);
    } else {
      // Schedule for future
      this.timers[job.id] = setTimeout(() => {
        this.executeJob(job.id);
      }, delay);
    }
  }

  async cancelJob(jobId) {
    if (this.timers[jobId]) {
      clearTimeout(this.timers[jobId]);
      delete this.timers[jobId];
    }
    
    const job = await store.getById(jobId);
    if (job && job.status === 'pending') {
      await store.update(jobId, { status: 'cancelled' });
    }
  }

  async executeJob(jobId) {
    const job = await store.getById(jobId);
    if (!job || job.status !== 'pending') return;

    try {
      // Support array of recipients for bulk blasts
      const targets = Array.isArray(job.recipients) ? job.recipients : [job.to];
      const householdStore = new DataStore('households');
      const hhs = await householdStore.getAll();
      
      for (const target of targets) {
        if (!target) continue;
        
        let finalBody = job.body;
        // If message contains @RSVP, inject the unique link
        if (finalBody.includes('@RSVP')) {
          const hh = hhs.find(h => h.email === target || h.phone === target);
          if (hh) {
            // Replace @RSVP with dynamic link using public tunnel URL
            const rsvpLink = `https://d15b0c7122b1fd.lhr.life/#rsvp?id=${hh.id}`;
            finalBody = finalBody.replace(/@RSVP/g, rsvpLink);
          }
        }
        
        if (job.type === 'sms') {
          await twilio.sendSMS(target, finalBody);
        } else if (job.type === 'email') {
          await sendgrid.sendEmail(target, job.subject, finalBody);
        }
      }
      
      await store.update(jobId, { status: 'sent', sentAt: new Date().toISOString() });
    } catch (error) {
      console.error(`Failed to execute job ${jobId}:`, error);
      await store.update(jobId, { status: 'failed', error: error.message });
    } finally {
      delete this.timers[jobId];
    }
  }
}

module.exports = new SchedulerService();
