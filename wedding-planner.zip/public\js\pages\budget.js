window.BudgetPage = {
  data: [],
  categories: ['Venue', 'Catering', 'Attire', 'Photography', 'Flowers', 'Entertainment', 'Miscellaneous'],

  async render(container) {
    this.container = container;
    await this.loadData();
    this.renderHTML();
    this.attachEvents();
  },

  async loadData() {
    try {
      this.data = await window.API.get('/api/budget') || [];
    } catch (err) {
      window.Toast.error('Failed to load budget');
      this.data = [];
    }
  },

  renderHTML() {
    let totalEstimated = 0;
    let totalActual = 0;
    let totalPaid = 0;
    
    this.data.forEach(item => {
      totalEstimated += Number(item.estimated || 0);
      totalActual += Number(item.actual || 0);
      if (item.paid) {
        totalPaid += Number(item.actual || 0);
      }
    });

    // Group by category
    const categorized = {};
    this.categories.forEach(c => categorized[c] = []);
    this.data.forEach(item => {
      if (!categorized[item.category]) categorized[item.category] = [];
      categorized[item.category].push(item);
    });

    const categoryHtml = this.categories.map(cat => {
      const items = categorized[cat];
      const catEst = items.reduce((sum, item) => sum + Number(item.estimated || 0), 0);
      const catAct = items.reduce((sum, item) => sum + Number(item.actual || 0), 0);
      
      const itemsHtml = items.map(item => `
        <div class="expense-row" data-id="${item.id}">
          <div class="expense-desc">
            <strong>${window.Helpers.escapeHtml(item.name || '')}</strong>
            ${item.notes ? `<br><small class="text-muted">${window.Helpers.escapeHtml(item.notes)}</small>` : ''}
          </div>
          <div class="expense-amount">
            Est: ${window.Helpers.formatCurrency(item.estimated)}<br>
            Act: ${window.Helpers.formatCurrency(item.actual)}
          </div>
          <div class="expense-status">
            <span class="badge ${item.paid ? 'badge-success' : 'badge-warning'}">${item.paid ? 'Paid' : 'Unpaid'}</span>
          </div>
          <div class="expense-actions">
            <button class="btn btn-icon btn-sm edit-btn" data-id="${item.id}" title="Edit"><i data-lucide="edit-2"></i>️</button>
            <button class="btn btn-icon btn-sm delete-btn" data-id="${item.id}" title="Delete"><i data-lucide="trash-2"></i>️</button>
          </div>
        </div>
      `).join('');

      return `
        <div class="category-card">
          <div class="category-header" data-category="${cat}">
            <div class="category-name">
              <span><i data-lucide="folder"></i></span> ${cat} <span class="badge">${items.length} items</span>
            </div>
            <div class="category-amount">
              ${window.Helpers.formatCurrency(catAct)} / ${window.Helpers.formatCurrency(catEst)}
            </div>
          </div>
          <div class="category-items ${items.length > 0 ? 'expanded' : ''}" id="cat-items-${cat.replace(/\s+/g, '-')}">
            ${itemsHtml || '<div class="p-md text-center text-muted">No items in this category.</div>'}
            <div class="p-sm text-center">
              <button class="btn btn-sm btn-secondary add-item-btn" data-category="${cat}">+ Add Item</button>
            </div>
          </div>
        </div>
      `;
    }).join('');

    this.container.innerHTML = `
      <div class="p-lg">
        <div class="flex-between mb-lg">
          <h2>Budget Planner</h2>
          <button class="btn btn-primary" id="add-budget-btn">+ Add Expense</button>
        </div>

        <div class="budget-overview">
          <div class="budget-total-card">
            <h3>Budget Overview</h3>
            <div class="budget-summary">
              <div class="budget-summary-item">
                <div class="budget-summary-value">${window.Helpers.formatCurrency(totalEstimated)}</div>
                <div class="budget-summary-label">Estimated</div>
              </div>
              <div class="budget-summary-item">
                <div class="budget-summary-value text-primary">${window.Helpers.formatCurrency(totalActual)}</div>
                <div class="budget-summary-label">Actual</div>
              </div>
              <div class="budget-summary-item">
                <div class="budget-summary-value ${totalActual > totalEstimated ? 'text-danger' : 'text-success'}">
                  ${window.Helpers.formatCurrency(totalEstimated - totalActual)}
                </div>
                <div class="budget-summary-label">Remaining</div>
              </div>
              <div class="budget-summary-item">
                <div class="budget-summary-value">${window.Helpers.formatCurrency(totalPaid)}</div>
                <div class="budget-summary-label">Paid</div>
              </div>
            </div>
          </div>
          <div class="budget-chart-card">
            <canvas id="budget-chart"></canvas>
          </div>
        </div>

        <div class="budget-categories">
          ${categoryHtml}
        </div>
      </div>
    `;

    // Render chart
    const canvas = document.getElementById('budget-chart');
    const chartLabels = [];
    const chartValues = [];
    this.categories.forEach(cat => {
      const act = categorized[cat].reduce((sum, item) => sum + Number(item.actual || 0), 0);
      if (act > 0) {
        chartLabels.push(cat);
        chartValues.push(act);
      }
    });

    if (chartValues.length > 0 && window.Charts && window.Charts.pie) {
      window.Charts.pie(canvas, {
        labels: chartLabels,
        values: chartValues,
        colors: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40', '#E7E9ED']
      });
    } else if (canvas) {
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#666';
      ctx.textAlign = 'center';
      ctx.fillText('No actual expenses yet', canvas.width/2, canvas.height/2);
    }
  },

  attachEvents() {
    this.container.addEventListener('click', async (e) => {
      const addBtn = e.target.closest('#add-budget-btn') || e.target.closest('.add-item-btn');
      if (addBtn) {
        const cat = addBtn.dataset.category || this.categories[0];
        this.showFormModal(null, cat);
        return;
      }

      const editBtn = e.target.closest('.edit-btn');
      if (editBtn) {
        const id = editBtn.dataset.id;
        const item = this.data.find(d => d.id === id);
        if (item) this.showFormModal(item, item.category);
        return;
      }

      const deleteBtn = e.target.closest('.delete-btn');
      if (deleteBtn) {
        const id = deleteBtn.dataset.id;
        window.Modal.confirm({
          title: 'Delete Expense',
          message: 'Are you sure you want to delete this expense?',
          confirmText: 'Delete',
          confirmClass: 'btn-danger',
          onConfirm: async () => {
            try {
              await window.API.del('/api/budget/' + id);
              window.Toast.success('Expense deleted');
              await this.render(this.container);
            } catch (err) {
              window.Toast.error('Failed to delete expense');
            }
          }
        });
        return;
      }

      const catHeader = e.target.closest('.category-header');
      if (catHeader) {
        const cat = catHeader.dataset.category;
        const itemsContainer = document.getElementById('cat-items-' + cat.replace(/\\s+/g, '-'));
        if (itemsContainer) {
          itemsContainer.classList.toggle('expanded');
        }
      }
    });
  },

  showFormModal(item = null, defaultCategory = '') {
    const isEdit = !!item;
    const catOptions = this.categories.map(c => 
      `<option value="${c}" ${((item && item.category === c) || (!item && c === defaultCategory)) ? 'selected' : ''}>${c}</option>`
    ).join('');

    window.Modal.show({
      title: isEdit ? 'Edit Expense' : 'Add Expense',
      content: `
        <form id="budget-form">
          <div class="form-group">
            <label class="form-label">Category</label>
            <select name="category" class="form-select" required>
              ${catOptions}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Expense Name</label>
            <input type="text" name="name" class="form-input" value="${item ? window.Helpers.escapeHtml(item.name) : ''}" required>
          </div>
          <div class="grid-2 gap-md">
            <div class="form-group">
              <label class="form-label">Estimated Amount ($)</label>
              <input type="number" step="0.01" name="estimated" class="form-input" value="${item ? item.estimated : ''}" required>
            </div>
            <div class="form-group">
              <label class="form-label">Actual Amount ($)</label>
              <input type="number" step="0.01" name="actual" class="form-input" value="${item ? item.actual : '0'}">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">
              <input type="checkbox" name="paid" class="form-checkbox" ${item && item.paid ? 'checked' : ''}>
              Mark as Paid
            </label>
          </div>
          <div class="form-group">
            <label class="form-label">Notes</label>
            <textarea name="notes" class="form-textarea" rows="2">${item && item.notes ? window.Helpers.escapeHtml(item.notes) : ''}</textarea>
          </div>
        </form>
      `,
      onSubmit: async (modalEl) => {
        const form = modalEl.querySelector('#budget-form');
        const formData = new FormData(form);
        const data = {
          category: formData.get('category'),
          name: formData.get('name'),
          estimated: parseFloat(formData.get('estimated')) || 0,
          actual: parseFloat(formData.get('actual')) || 0,
          paid: formData.get('paid') === 'on',
          notes: formData.get('notes')
        };

        try {
          if (isEdit) {
            await window.API.put('/api/budget/' + item.id, data);
            window.Toast.success('Expense updated');
          } else {
            await window.API.post('/api/budget', data);
            window.Toast.success('Expense added');
          }
          window.Modal.close();
          await this.render(this.container);
        } catch (err) {
          window.Toast.error(err.message || 'Failed to save expense');
        }
      }
    });
  },

  cleanup() {
    // Handled by event delegation
  }
};
